let projectName = process.argv[2]
let port = process.argv[3]

let fs = require('fs')

fs.writeFileSync('./config/project.js', `exports.name = '${projectName}',exports.port = '${port}'`)

let exec = require('child_process').execSync;
exec('npm run serve', {stdio: 'inherit'}, {stdio: 'inherit'});
