const api = {
    /**
     * 系统相关
     */

    login:'/v0/login',                       //登录
    logout:'/logout',                        //退出
    mainNav:'/v0/index',                     //导航列表
    uploadFile:'/v0/common/sysFile/uploadFile', //上传文件
    downloadFile:'/v0/common/sysFile/downloadFile',//文件下载

    /**
    * 首页
    * */

    listCity:'/v0/report/testSalesDict/listCity',      //获取地域销售
    listChannel:'/v0/report/testSalesDict/listChannel',//获取经营方式销售
    listType:'/v0/report/testSalesDict/listType',      //获取彩票类型销售
    listMonth:'/v0/report/testSalesMonth/list',        //获取累计销售

    /**
     * 业务管理
     */

    billingList:'/v0/product/list',                           //即开票列表
    billingSave:'/v0/product/',                               //新增save  修改 update
    billingInfo:'/v0/product/edit/',                          //即开票详情 id
    billingExportExcel:'/v0/product/exportExcel',             //即开票导出模板
    billingImprotExcel:'/v0/product/importExcel',             //即开票导入模板
    faceValueList:'/v0/product/classify/faceValue/list',      //面值
    awardGroup:'/v0/product/classify/awardGroup/list',        //奖组
    unitList:'/v0/product/classify/unit/list',                //单位下拉

    batchRemove:'/v0/product/batchRemove',                    //即开票耗材删除
    unitSave:'/v0/product/classify/unit/save',                //即开票耗材新增单位分类
    faeValueSave:'/v0/product/classify/faceValue/save',       //即开票新增面值
    verifyProdCode:'/v0/product/verifyProdCode',              //校验-即开票与耗材code

    consumableList:'/v0/prodConsumable/list',                 //耗材列表
    consumableSave:'/v0/prodConsumable/',                     //新增save 修改 update
    consumableInfo:'/v0/prodConsumable/edit/',                //耗材详情  id
    consumableExportExcel:'/v0/prodConsumable/exportExcel',   //耗材导出模板
    consumableImprotExcel:'/v0/prodConsumable/importExcel',   //耗材导入模板

    /**
     * 物料订单  配货
     */
    cityBillingList:'/v0/materialOrder/cityManage/openList',     //即开票物料订单
    cityMaterialList:'/v0/materialOrder/cityManage/materialsList',//耗材物料订单
    cityManageBatchUpdate:'/v0/materialOrder/cityManage/batchUpdate', //批量配货

    /**
     * 资讯
     */

    notifyList:'/v0/oa/notify/list',                          //资讯列表
    notifySave:'/v0/oa/notify/',                              //新增资讯save  修改update
    notifyEdit:'/v0/oa/notify/edit/',                         //资讯详情 id
    sysFileUpload:'/v0/common/sysFile/upload',                //图片上传接口
    notifyStick:'/v0/oa/notify/stick',                        //设为置顶1  取消置顶0
    notifyRemove:'/v0/oa/notify/batchRemove',                 //资讯删除
    notifyDictList:'/v0/oa/notify/dictPullList',              //资讯类型列表

    putAway:'/v0/prodConsumable/putaway',                     //即开票、耗材上架
    soldOut:'/v0/prodConsumable/soldOut',                     //即开票、耗材下架
    productSoldOut:'/v0/product/soldOut',                     //即开票停售

    /**
     * 开奖结果 playType 1-双色球 2-福彩3D 3-七乐彩
     */

    lotteryList:'/v0/lottery/list',                        //开奖结果列表
    lotterySave:'/v0/lottery/',                            //开奖结果新增save修改 update
    lotteryInfo:'/v0/lottery/edit/',                       //开奖结果详情  id
    lotteryExportExcel:'/v0/lottery/exportExcel',          //开奖结果导出模板
    doubleBallExportExcel:'/v0/lottery/doubleBall/exportExcel',  //双色球导出模板
    doubleBallImportExcel:'/v0/lottery/doubleBall/importExcel',  //双色球导入模板
    welfareExportExcel:'/v0/lottery/welfare/exportExcel',        //福彩导出
    welfareImportExcel:'/v0/lottery/welfare/importExcel',        //福彩导入
    sevenExportExcel:'/v0/lottery/seven/exportExcel',            //七乐彩导出
    sevenImportExcel:'/v0/lottery/seven/importExcel',            //七乐彩导入
    lotteryBatchRemove:'/v0/lottery/batchRemove',                //开奖结果删除
    verifyCycle:'/v0/lottery/verifyCycle',                       //期号唯一校验
    lotteryWinningTask:'/v0/lottery/winningTask/run',            //开奖结果-新增 成功---执行匹配中奖任务



    /**
     * 玩法介绍
     */

    lottoList:'/v0/play/lottoList',                        //乐透列表
    lottoSelect:'/v0/play/lottoDictList',                  //乐透玩法
    openList:'/v0/play/openList',                          //即开列表
    openSelect:'/v0/play/openDictList',                    //即开玩法
    videoList:'/v0/play/videoList',                        //视频列表
    videoSelect:'/v0/play/videoDictList',                  //视频玩法
    ginoList:'/v0/play/ginoList',                          //基诺列表
    ginoSelect:'/v0/play/ginoDictList',                    //基诺玩法
    playRemove:'/v0/play/batchRemove',                     //删除玩法
    playSave:'/v0/play/',                                  //玩法新增save  编辑update
    playInfo:'/v0/play/edit/',                             //玩法详情
    playAdd:'/v0/play/addClassify',                        //新增玩法分类
    playOpenSave:'/v0/product/savePlayOpen',               //即开票新增
    verifyPlayName:'/v0/play/verifyPlayName',              //校验即开票名称是否已完善规则
    playSoldOut:'/v0/play/soldOut',                        //停售
    playNameList:'/v0/play/playName/list',                    //玩法名称列表 type乐透型，视频型，基诺型
    playNameInfo:'/v0/play/playName/',                        //玩法详情 id
    playNameSave:'/v0/play/playName/',                        //玩法名称新增save 修改update
    playNameRemove:'/v0/play/playName/batchRemove',           //玩法名称删除

    /**
     * 投注站基础信息
     */

    agentList:'/v0/agent/list',                            //投注站列表
    agentSave:'/v0/agent/',                                //投注站新增save  修改update
    agentExportExcel:'/v0/agent/exportExcel',              //投注站导出模板
    agentImprotExcel:'/v0/agent/importExcel',              //投注站导入模板
    agentOwnerUserList:'/v0/agent/ownerUser/list',         //业主下拉列表
    agentManagerList:'/v0/agent/manager/list',             //专管员下拉列表
    agentGeoList:'/v0/common/district/geoList',            //省市区下拉列表
    equipmentList:'/v0/equipment/equipmentList',           //设备编号下拉
    equipmentInfo:'/v0/equipment/edit/',                   //设备详情 id
    agentInfo:'/v0/agent/edit/',                           //投注站详情 id
    closeAgent:'/v0/agent/close/',                         //关闭投注站 id
    agentBatchRemove:'/v0/agent/batchRemove',              //投注站删除
    verifyAgentCode:'/v0/agent/verifyAgentCode',           //投注站编号验证
    agentRebate:'/v0/agent/rebate/info',                   //投注站规则返利
    agentRebateUpdate:'/v0/agent/rebate/update',           //投注站规则返利编辑

    ownerUserList:'/v0/user/ownerUserList',                //业主列表
    ownerUserSave:'/v0/user/',                             //业主新增 save 修改update
    ownerUserBatchRemove:'/v0/user/batchRemove',           //业主删除
    ownerUserInfo:'/v0/user/edit/',                        //业主详情
    ownerExportExcel:'/v0/user/exportExcel',               //业主导出模板
    ownerImportExcel:'/v0/user/importExcel',               //业主导入模板
    verifyOwnerUserIdCard:'/v0/user/verifyOwnerUserIdCard',//业主身份证号校验


    mallOrderList:'/v0/mallOrder/list',                    //投注站     即开票、耗材订单
    mallOrderInfo:'/v0/mallOrder/edit/',                   //投注站     即开票、耗材订单详情
    repairList:'/v0/mallOrder/serviceEquipment/list',      //投注站     故障报修订单
    commentList:'/v0/order/comment/list',                  //评价投注站列表
    complainList:'/v0/order/complain/list',                //投诉投注站列表

    comAssessList:'/v0/materialOrder/manager/comment/list',    //专管员评价列表
    comComplainList:'/v0/materialOrder/manager/complaint/list',//专管员投诉列表

    /**
     * 系统设置
     */

    roleList:'/v0/sys/role/list',                             //角色列表
    roleSave:'/v0/sys/role/',                                 //角色新增Save  修改update
    roleInfo:'/v0/sys/role/edit/',                            //角色详情id
    roleBatchRemove:'/v0/sys/role/batchRemove',               //角色删除
    menuList:'/v0/sys/role/allMenu',                          //获取所有菜单列表
    menuSave:'/v0/sys/menu/',                                 //菜单新增save  编辑update
    menuInfo:'/v0/sys/menu/edit/',                            //菜单详情
    partMenu:'/v0/sys/menu/partMenu',                         //获取上级菜单
    menuRemove:'/v0/sys/menu/remove',                         //菜单删除


    /**
     * 字典接口
     */
    dictList:'/v0/common/dict/dictList',                      //字典列表  type: prod_unit面值  transfer_reason委托服务订单转移原因  user_reason委托服务订单取消原因  material_reason 即开票、耗材订单取消原因  notify_type资讯
    dictSave:'/v0/common/dict/',                              //字典新增save update
    dictInfo:'/v0/common/dict/edit/',                         //字典详情
    dictBatchRemove:'/v0/common/dict/batchRemove',            //字典删除
    verifyDictName:'/v0/common/dict/verifyDictName',          //检验名称唯一性

    /**
     * 操作日志
     */
    logList:'/v0/common/log/list',                            //操作日志列表

    /**
     * 用户管理
     */
    deptTree:'/v0/sys/user/deptTree',                         //部门
    userList:'/v0/sys/user/list',                             //内部用户
    userSave:'/v0/sys/user/',                                 //内部用户新增save 修改update
    userInfo:'/v0/sys/user/edit/',                            //内部用户详情
    verifyUserName:'/v0/sys/user/verifyUserName',             //内部用户校验账号唯一性
    roleSelectList:'/v0/sys/role/roleList',                   //角色下拉
    deptList:'/v0/system/sysDept/deptList',                   //部门下拉
    agentUserList:'/v0/sys/agent/user/list',                  //投注站用户
    agentUserInfo:'/v0/sys/agent/user/edit/',                 //投注站用户详情
    agentUserUpdate:'/v0/sys/agent/user/update',              //投注站用户编辑
    resetPassWord:'/v0/sys/user/getNewPwd',                   //重置密码
    lotteryUserList:'/v0/sys/lottery/user/list',              //彩民用户列表
    lotteryUserInfo:'/v0/sys/lottery/user/edit/',             //彩民详情
    lotteryUserUpdate:'/v0/sys/lottery/user/update',          //彩民编辑


    baseConfigInfo:'/v0/sys/baseConfig/getInfo',              //委托服务默认时间
    baseConfigUpdate:'/v0/sys/baseConfig/update',             //委托服务时间修改
    sysCycleList:'/v0/sys/cycle/list',                        //彩票休市列表
    sysCycleSave:'/v0/sys/cycle/',                            //新增彩票休市时间save  修改update
    sysCycleInfo:'/v0/sys/cycle/edit/',                       //彩票休市时间详情
    sysCycleRemove:'/v0/sys/cycle/remove',                    //彩票休市时间删除

    orderList:'/v0/orders/list',                              //彩民委托服务列表
    orderInfo:'/v0/orders/edit/',                             //彩民委托服务详情

    productFaceValueList:'/v0/product/faceValue/list',        //面值管理列表
    productFaceValueInfo:'/v0/product/faceValue/',            //面值管理详情
    productFaceValueSave:'/v0/product/faceValue/',            //面值管理新增save  修改update
    productFaceValueRemove:'/v0/product/faceValue/batchRemove', //面值管理删除


    /**
     * 渠道
     */

    channelList:'/v0/channel/list',                            //渠道列表
    channelType:'/v0/channel/types',                           //渠道类型
    channelUsers:'/v0/channel/users',                          //渠道用户
    channelSave:'/v0/channel/',                                //新增渠道save  修改update
    channelInfo:'/v0/channel/edit/',                           //渠道详情
    channelRemove:'/v0/channel/batchRemove',                   //渠道删除
    verifyChannelName:'/v0/channel/verifyChannelName',         //校验渠道名称唯一性
    verifyContractNo:'/v0/channel/verifyContractNo',           //校验合同编号唯一性
    verifyChannelUser:'/v0/channel/verifyChannelUser',         //校验是否更换渠道执行人
    verifyMobile:'/v0/sys/user/verifyMobile',                  //校验手机号唯一性

    channelUserList:'/v0/user/channelUser/list',               //渠道用户列表
    channelUserInfo:'/v0/user/channelUser/edit/',              //渠道用户详情
    channelUserSave:'/v0/user/channelUser/',                   //新增渠道执行人 save  修改update
    stopChannel:'/v0/channel/cancelStatus/',                   //终止合作 id

    channelMallOrderList:'/v0/channel/mallOrder/list',        //渠道-即开票订单列表
    channelMallOrderInfo:'/v0/channel/mallOrder/edit/',       //渠道-即开票订单详情

    channelMallOrderComment:'/v0/channel/mallOrder/comment/list', //渠道评价列表
    channelMallOrderComplaint:'/v0/channel/mallOrder/complaint/list',//渠道投诉列表


    /**
     * 渠道商-订购即开票
     */

    channelOrderInfo:'/v0/order/userInfo',              //渠道商-订购即开票-个人信息  投注站账号
    channelOrderList:'/v0/order/list',                  //渠道商-订购即开票列表
    getQueryParams:'/v0/order/getQueryParams',          //销量时间参数
    channelBuyerCar:'/v0/order/buyerCar',               //渠道商-提交/编辑/删除-商品
    channelOrderCarList:'/v0/order/buyerCarList',       //渠道商-购物车列表接口
    submitOrder:'/v0/order/submitOrder',                //提交订单


    channelMallOrder :'/v0/channel/mallOrder/channelList',      //渠道商订单查询列表
    channelCommentList:'/v0/channel/mallOrder/channelComment/list', //渠道商评价列表
    channelComplaint:'/v0/channel/mallOrder/channelComplaint/list',  //渠道商投诉列表

    /**
     * 地理信息
     */

    districtList:'/v0/common/district/list',                     //地理信息列表
    districtInfo:'/v0/common/district/edit/',                    //地理信息详情
    districtSave:'/v0/common/district/',                         //地理信息新增save  编辑update
    districtRemove:'/v0/common/district/batchRemove',            //地理信息删除
    districtDictList:'/v0/common/district/dictList',             //地理-下拉列表-一级地理标识






};

 export default {api}
