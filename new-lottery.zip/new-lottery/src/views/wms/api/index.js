const api = {
    /**
     * 系统相关
     */

    login:'/v0/login',                       //登录
    logout:'/logout',                        //退出
    mainNav:'/v0/index',                     //导航列表
    uploadFile:'/v0/common/sysFile/uploadFile', //上传文件
    downloadFile:'/v0/common/sysFile/downloadFile',//文件下载
    sysFileUpload:'/v0/common/sysFile/upload',                //图片上传接口

    /**
     * 系统设置
     */

    roleList:'/v0/sys/role/list',                             //角色列表
    roleSave:'/v0/sys/role/',                                 //角色新增Save  修改update
    roleInfo:'/v0/sys/role/edit/',                            //角色详情id
    roleBatchRemove:'/v0/sys/role/batchRemove',               //角色删除
    menuList:'/v0/sys/role/allMenu',                          //获取所有菜单列表
    menuSave:'/v0/sys/menu/',                                 //菜单新增save  编辑update
    menuInfo:'/v0/sys/menu/edit/',                            //菜单详情
    partMenu:'/v0/sys/menu/partMenu',                         //获取上级菜单
    menuRemove:'/v0/sys/menu/remove',                         //菜单删除

    /**
     * 即开票
     */

    billingList:'/v0/product/list',                           //即开票列表
    billingSave:'/v0/product/',                               //新增save  修改 update
    billingInfo:'/v0/product/edit/',                          //即开票详情 id
    billingExportExcel:'/v0/product/exportExcel',             //即开票导出模板
    billingImprotExcel:'/v0/product/importExcel',             //即开票导入模板
    faceValueList:'/v0/product/classify/faceValue/list',      //面值
    awardGroup:'/v0/product/classify/awardGroup/list',        //奖组
    unitList:'/v0/product/classify/unit/list',                //单位下拉
    verifyProdCode:'/v0/product/verifyProdCode',              //校验-即开票与耗材code
    verifyProdBarcode:'/v0/product/verifyProdBarcode',        //校验-即开票条形码barcode

    batchRemove:'/v0/product/batchRemove',                    //即开票耗材删除
    unitSave:'/v0/product/classify/unit/save',                //即开票耗材新增单位分类
    faeValueSave:'/v0/product/classify/faceValue/save',       //即开票新增面值

    putAway:'/v0/prodConsumable/putaway',                     //即开票、耗材上架
    soldOut:'/v0/prodConsumable/soldOut',                     //即开票、耗材下架
    productSoldOut:'/v0/product/soldOut',                     //即开票停售

    productFaceValueList:'/v0/product/faceValue/list',        //面值管理列表
    productFaceValueInfo:'/v0/product/faceValue/',            //面值管理详情
    productFaceValueSave:'/v0/product/faceValue/',            //面值管理新增save  修改update
    productFaceValueRemove:'/v0/product/faceValue/batchRemove', //面值管理删除

    /**
     * 玩法
     */

    openList:'/v0/play/openList',                          //即开列表
    openSelect:'/v0/play/openDictList',                    //即开玩法
    playOpenSave:'/v0/product/savePlayOpen',               //玩法即开票新增
    playRemove:'/v0/play/batchRemove',                     //删除玩法
    playSave:'/v0/play/',                                  //玩法新增save  编辑update
    playInfo:'/v0/play/edit/',                             //玩法详情
    playAdd:'/v0/play/addClassify',                        //新增玩法分类
    verifyPlayName:'/v0/play/verifyPlayName',              //校验即开票名称是否已完善规则

    /**
     * 字典接口
     */
    dictList:'/v0/common/dict/dictList',                      //字典列表  type: prod_unit面值  transfer_reason委托服务订单转移原因  user_reason委托服务订单取消原因  material_reason 即开票、耗材订单取消原因  notify_type资讯
    dictSave:'/v0/common/dict/',                              //字典新增save update
    dictInfo:'/v0/common/dict/edit/',                         //字典详情
    dictBatchRemove:'/v0/common/dict/batchRemove',            //字典删除
    verifyDictName:'/v0/common/dict/verifyDictName',          //检验名称唯一性

    /**
     * 入库接口
     */
    putStorageList:'/v0/inv/putStorange/list',                //入库列表
    putStorageInfo:'/v0/inv/putStorange/edit/',               //入库详情
    putStorageSave:'/v0/inv/putStorange/save',                //入库提交
    productInfo:'/v0/product/info',                           //通过条形码查询即开票接口
    currentUser:'/v0/sys/user/currentUser',                   //当前登录-用户信息

    /**
     * 库存状况
     */
    normalList :'/v0/inv/prod/normal/list',                  //库存状况正常品列表
    normalInfo:'/v0/inv/prod/normal/invInfo',                //库存-正常品-库存数量详情


    putStorageLog:'/v0/inv/putStorangeLog/list',             //入库日志-列表

    /**
     * 即开票订单列表
     */

    mallOrderList:'/v0/mallOrder/list',                     //列表
    mallOrderInfo:'/v0/mallOrder/edit/',                    //详情
    updateOrderState:'/v0/mallOrder/updateOrderState',      //修改订单状态
    verifyOrderNo:'/v0/mallOrder/verifyOrderNo',            //校验-订单编号


};

 export default {api}
