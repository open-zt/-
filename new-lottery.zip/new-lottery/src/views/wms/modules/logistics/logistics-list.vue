<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" plain>物流交接</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="交接时间">
                <el-date-picker
                        v-model="dataForm.allotStartTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="订单编号">
                <el-input v-model="dataForm.orderNo" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="交接时间 ">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="交接订单数量(单)">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="订单包含省份数目">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="物流揽收人员">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="发货交接人员">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" >详情</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    export default {
        name: "take-goods-list",
        data(){
            return{
                dataForm:{
                    state:'',

                },
                dataList:[],
            }
        },
        methods:{
            getDataList(){

            },

        }
    }
</script>

<style scoped>

</style>