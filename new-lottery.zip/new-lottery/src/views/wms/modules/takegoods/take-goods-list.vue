<template>
    <div class="table-con">
        <el-form :model="dataForm">
            <el-form-item label="出库单状态：">
                <el-radio v-model="dataForm.orderState" label="forOutBound" @change="getDataList">待出库</el-radio>
                <el-radio v-model="dataForm.orderState" label="deliveryVerify" @change="getDataList">待提货</el-radio>
                <el-radio v-model="dataForm.orderState" label="haveOutbound" @change="getDataList">已提货</el-radio>
            </el-form-item>
        </el-form>
<!--        <el-form :model="dataForm" :inline="true">-->
<!--            <el-form-item label="发起时间">-->
<!--                <el-date-picker-->
<!--                        v-model="dataForm.allotStartTime"-->
<!--                        type="daterange"-->
<!--                        value-format="yyyy-MM-dd"-->
<!--                        start-placeholder="开始时间"-->
<!--                        end-placeholder="结束时间">-->
<!--                </el-date-picker>-->
<!--            </el-form-item>-->
<!--            <el-form-item label="出库人员">-->
<!--                <el-input v-model="dataForm.orderNo" placeholder="请输入" clearable></el-input>-->
<!--            </el-form-item>-->
<!--            <el-form-item>-->
<!--                <el-button type="text" @click="clear()">清空条件</el-button>-->
<!--                <el-button type="primary" @click="getDataList()">查询</el-button>-->
<!--            </el-form-item>-->
<!--        </el-form>-->
        <el-table
                border
                style="width:100%"
                :data="dataList">
<!--            <el-table-column-->
<!--                    prop="orderCreateTime"-->
<!--                    header-align="center"-->
<!--                    align="center"-->
<!--                    label="发起时间">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="orderNo"-->
<!--                    header-align="center"-->
<!--                    align="center"-->
<!--                    label="出库单编号">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="state"-->
<!--                    header-align="center"-->
<!--                    align="center"-->
<!--                    label="出库单状态">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="orderNum"-->
<!--                    header-align="center"-->
<!--                    align="center"-->
<!--                    label="订单数目(单)">-->
<!--            </el-table-column>-->
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    label="订单编号">
            </el-table-column>
            <el-table-column
                    prop="prodNum"
                    header-align="center"
                    align="center"
                    label="合计种类（种）">
            </el-table-column>
            <el-table-column
                    prop="num"
                    header-align="center"
                    align="center"
                    label="合计数量（本）">
            </el-table-column>
            <el-table-column
                    prop="amount"
                    header-align="center"
                    align="center"
                    label="合计金额（元）">
            </el-table-column>
            <el-table-column
                    prop="outBoundUser"
                    header-align="center"
                    align="center"
                    label="出库人员">
            </el-table-column>
            <el-table-column
                    prop="sellUser"
                    header-align="center"
                    align="center"
                    label="销售人员">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" v-if="scope.row.orderStateCode == 'forOutBound' || scope.row.orderStateCode == 'haveOutbound' || scope.row.orderStateCode == 'haveOrder'" @click="detailsHandle(scope.row.id)">详情</el-button>
                    <el-button type="text" size="small" v-if="scope.row.orderStateCode == 'deliveryVerify'" @click="detailsHandle(scope.row.id)">确认提货</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <details-handle ref="DetailsHandle" @refreshDataList="getDataList"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api';
    import DetailsHandle from './details-handle'
    export default {
        components: {DetailsHandle},
        data(){
            return{
                dataForm:{
                    orderState:'forOutBound',
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            detailsHandle(id){
                this.$nextTick(() => {
                    this.$refs.DetailsHandle.init(id);
                })
            },
            getDataList(){
                let request = {
                    'orderState':this.dataForm.orderState,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };

                this.$get(apiPage.api.mallOrderList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>