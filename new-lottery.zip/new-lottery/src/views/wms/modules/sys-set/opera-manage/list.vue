<template>
    <div>
       <div :style="{marginBottom:20 + 'px'}">
           <el-button-group>
               <el-button type="primary" plain>运营省份</el-button>
               <el-button type="primary" plain>待审核身份</el-button>
           </el-button-group>
       </div>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="createdTime"
                    header-align="center"
                    align="center"
                    label="省份(自治区、直辖市)">
            </el-table-column>
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="运营时间">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small">同意</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                dataList:[]
            }
        },
        methods:{

        }
    }
</script>

<style scoped>

</style>