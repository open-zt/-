<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.id?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="submitFormData()" label-width="100px">
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="角色名称" prop="roleName">
                            <el-input v-model="dataForm.roleName" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="备注" prop="remark">
                            <el-input v-model="dataForm.remark" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="角色状态" prop="status">
                            <el-select v-model="dataForm.status" placeholder="请选择"  style="width:100%">
                                <el-option value="0" label="无效"></el-option>
                                <el-option value="1" label="有效"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="功能权限" prop="menuIds">
                            <el-input placeholder="请输入菜单名称" prefix-icon="el-icon-search" v-model="filterText" clearable></el-input>
                            <el-tree
                                    :data="menuList"
                                    :props="menuListTreeProps"
                                    node-key="menuId"
                                    ref="menuListTree"
                                    :filter-node-method="filterNode"
                                    :default-checked-keys="checkedKeys"
                                    show-checkbox>
                            </el-tree>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        data(){
            return{
                filterText:'',
                visible:false,
                checkedKeys: [],
                menuList:[],
                menuListTreeProps:{
                    children: 'list',
                    label: 'name'
                },
                dataForm:{
                    roleId:'',
                    roleName:'',
                    remark:'',
                    status:'1',
                    menuIds:[]
                },
                dataRule:{
                    roleName:[{required: true, message: '角色名称必填', trigger: 'blur'}],
                    status:[{required: true, message: '角色状态必填', trigger: 'blur'}],
                }
            }
        },
        watch: {
            filterText(val) {
                this.$refs.menuListTree.filter(val);
            }
        },
        methods:{
            filterNode(value, data) {
                if (!value) return true;
                return data.name.indexOf(value) !== -1;
            },
            init(id){
                this.visible = true;
                this.dataForm.roleId = id;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.$refs.menuListTree.setCheckedKeys([])
                });
                this.$get(apiPage.api.menuList).then((data) => {
                    if(data.code == 0){
                        this.menuList = data.menuList;
                    }
                });
                if(this.dataForm.roleId){
                    this.$get(apiPage.api.roleInfo + this.dataForm.roleId).then((data) => {
                        if(data.code == 0){
                            this.dataForm = data.role;
                            this.dataForm.status = data.role.status.toString();
                            this.$refs.menuListTree.setCheckedKeys(data.role.menuIds)
                        }
                    })
                }
            },
            // diguiquchu(datas, arr, v, i, needdelarr) {
            //     //递归找出半选中的数据
            //     arr.map((item, index) => {
            //         if (item.id == v && item.child) {
            //             // datas.splice(i, 1);//因为每次截取会改变原数组，所以不能这样
            //             needdelarr.push(v);
            //             this.diguiquchu(datas, item.child, v, i, needdelarr);
            //         } else if (item.id != v && item.child) {
            //             this.diguiquchu(datas, item.child, v, i, needdelarr);
            //         }
            //     });
            // },
            submitFormData(){
                console.log(this.dataForm.menuId);
                let request = {
                    'roleId': this.dataForm.roleId ,
                    'roleName': this.dataForm.roleName,
                    'remark': this.dataForm.remark,
                    'status':this.dataForm.status,
                    'menuIds': [].concat(this.$refs.menuListTree.getCheckedKeys(),this.$refs.menuListTree.getHalfCheckedKeys())
                };
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.$post(apiPage.api.roleSave + `${!this.dataForm.roleId ? 'save' : 'update'}`,request).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 1500,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                })
                            } else {
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            }
        }
    }
</script>

<style>
    .el-tree-node__content>.el-checkbox{
        margin-right: 8px!important;
    }
</style>