<template>
    <el-dialog
            class="dialog-con-width"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            title="出库"
            width="70%"
            :visible.sync="visible" >

        <el-steps :active="active" finish-status="success">
            <el-step title="接单"></el-step>
            <el-step title="扫描即开票二维码"></el-step>
            <el-step title="自动打印订单"></el-step>
        </el-steps>

        <div class="start-left">
            <el-row>
                <el-col :span="8">
                    <div class="order-content">
                        <p><i></i>出库单信息</p>
                        <ul>
                            <li>订单编号：<span>{{infoForm.orderNo}}</span></li>
                            <li>发起时间：<span>{{infoForm.createTime}}</span></li>
<!--                            <li>发起人：<span>{{infoForm.sysName}}</span></li>-->
                            <li>销售人员：<span>{{infoForm.sellUser}}</span></li>
                        </ul>
                        <ul>
                            <li>合计种类(种)：<span>{{infoForm.prodNum}}</span></li>
                            <li>合计数量(本)：<span>{{infoForm.totalNum}}</span></li>
                            <li>合计金额(元)：<span>¥ {{infoForm.amount}}</span></li>
                        </ul>
                        <p><i></i>订单操作记录</p>
                        <ul>
                            <li>出库人员：<span>王松</span></li>
                            <li>操作：<span>接单 → 扫码出库</span></li>
<!--                            <li>开始时间：<span>2019-09-12 10:02:03</span></li>-->
                        </ul>
                    </div>
                </el-col>
                <el-col :span="16">
                    <el-table  border style="width:100%" :data="dataList" highlight-current-row @current-change="handleCurrentChange">
                        <el-table-column
                                type="index"
                                header-align="center"
                                align="center"
                                label="种类"
                                width="60">
                        </el-table-column>
                        <el-table-column
                                prop="product"
                                header-align="center"
                                label="即开票">
                            <template slot-scope="scope">
                                <div>{{scope.row.prodName}}</div>
                                <div>{{scope.row.faceValue}}</div>
                            </template>
                        </el-table-column>
                        <el-table-column
                                prop="price"
                                header-align="center"
                                align="center"
                                label="价格(元/本)">
                        </el-table-column>
                        <el-table-column
                                prop="num"
                                header-align="center"
                                align="center"
                                label="采购数量(本) ">
                        </el-table-column>
                        <el-table-column
                                prop="num"
                                header-align="center"
                                align="center"
                                label="出库数量(本)">
                        </el-table-column>
                        <el-table-column
                                prop="state"
                                header-align="center"
                                align="center"
                                label="状态">
                        </el-table-column>
                    </el-table>
                    <div class="stock-total">
                        <div>
                            <el-row>
                                <el-col :span="5">
                                    <span class="ml10">发货合计</span>
                                </el-col>
                                <el-col :span="5">
                                    <span>合计种类(种)：{{infoForm.prodNum}}</span>
                                </el-col>
                                <el-col :span="6">
                                    <span>合计数量(本)：{{infoForm.totalNum}}</span>
                                </el-col>
                                <el-col :span="8">
                                    <span>合计金额(元)：{{infoForm.amount}}</span>
                                </el-col>
                            </el-row>
                        </div>
                    </div>
                </el-col>
            </el-row>
        </div>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="submitFormData" v-if="infoForm.orderStateCode == 'forOutBound' || infoForm.orderStateCode == 'haveOrder'">接单</el-button>
            <el-button type="primary" v-if="infoForm.orderStateCode != 'forOutBound' && infoForm.orderStateCode != 'haveOrder'">打印单据</el-button>
        </span>

        <order-taking ref="orderTaking" v-bind="$attrs" v-on="$listeners"></order-taking>
    </el-dialog>
</template>

<script>
    import axios from 'axios'
    import apiPage from '@/api';
    import OrderTaking from './order-taking'
    export default {
        name: "start-processing",
        data(){
            return{
                visible:false,
                active: 0,
                dataList:[],
                currentRow: null,
                infoForm:{
                    id:''
                },
                mallOrderLogList:[],
            }
        },
        components:{
            OrderTaking
        },
        methods:{
            handleCurrentChange(val) {
                this.currentRow = val;
            },
            init(id){
                this.visible = true;
                this.infoForm.id = id;
                this.infoForm = {};
                this.dataList = [];
                this.mallOrderLogList = [];

                this.$get(apiPage.api.mallOrderInfo + id).then((data) => {
                    if(data.code == 0){
                        if(data.orderInfo.mallOrderInfo !=null) {
                            this.infoForm = data.orderInfo.mallOrderInfo;
                        }
                        this.dataList = data.orderInfo.mallOrderItemList;
                        this.num = 0;
                        this.dataList.forEach((i) => {
                            this.num += parseInt(i.num);
                        });
                        this.mallOrderLogList = data.orderInfo.mallOrderLogList;
                    }
                })
            },
            submitFormData(){
                let request = {
                    "orderNo":this.infoForm.orderNo,
                    "orderState":"actionForOutBound"
                };
                this.$post(apiPage.api.updateOrderState,request).then((data) => {
                    if(data.code == 0){
                        this.$message({
                            message: '操作成功',
                            type: 'success',
                            duration: 800,
                            onClose: () => {
                                this.visible = false;
                                this.$nextTick(() => {
                                    this.$refs.orderTaking.init(this.infoForm.orderId);
                                })
                            }
                        });
                    };
                })
            },
        }
    }
</script>

<style scoped>
    .dialog-con-width{
        min-width:1000px;
    }
    ul li {
        list-style: none;
    }
    .stock-total span.ml10{
        margin-left:10px
    }

    .start-left{
        height:670px;
        width:100%;
        border:1px solid #EBEEF5;
    }
    .order-content p{
        font-size: 18px;
        color:#000;
    }
    .order-content p i{
        width:6px;
        height:6px;
        display:inline-block;
        background:#000;
        border-radius: 50%;
        margin-right:6px;
    }
    .order-content ul{
        padding-left:0;
    }
    .order-content li{
        margin-bottom: 10px;
    }
    .order-content li span{
        color:#000
    }
    .order-content{
        padding-left:20px;
    }
    .stock-total{
        height:50px;
        line-height:50px;
        border:1px solid #EBEEF5;
        border-top:none;
        border-right:none;
    }
    .stock-total span{
        margin-right:40px;
    }
</style>