<template>
    <div>
        <el-form :model="dataForm">
            <el-form-item label="出库单状态：">
                <el-radio v-model="dataForm.orderState" label="forOutBound" @change="getDataList">待出库</el-radio>
                <el-radio v-model="dataForm.orderState" label="deliveryVerify" @change="getDataList">出库待确认</el-radio>
                <el-radio v-model="dataForm.orderState" label="haveOutbound" @change="getDataList">已出库</el-radio>
            </el-form-item>
        </el-form>
<!--        <el-form :model="dataForm" :inline="true">-->
<!--            <el-form-item label="销售编号">-->
<!--                <el-input v-model="dataForm.code" placeholder="请输入" clearable></el-input>-->
<!--            </el-form-item>-->
<!--            <el-form-item label="发起时间">-->
<!--                <el-date-picker-->
<!--                        v-model="dataForm.startTime"-->
<!--                        type="daterange"-->
<!--                        value-format="yyyy-MM-dd"-->
<!--                        start-placeholder="开始时间"-->
<!--                        end-placeholder="结束时间">-->
<!--                </el-date-picker>-->
<!--            </el-form-item>-->
<!--            <el-form-item>-->
<!--                <el-button type="text" @click="clear()">清空条件</el-button>-->
<!--                <el-button type="primary" @click="getDataList()">查询</el-button>-->
<!--            </el-form-item>-->
<!--        </el-form>-->
        <el-table
                border
                style="width:100%"
                :data="dataList">
<!--            <el-table-column-->
<!--                    prop="createdTime"-->
<!--                    header-align="center"-->
<!--                    align="center"-->
<!--                    label="发起时间">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="code"-->
<!--                    header-align="center"-->
<!--                    align="center"-->
<!--                    label="出库单编号">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="state"-->
<!--                    header-align="center"-->
<!--                    align="center"-->
<!--                    label="出库单状态">-->
<!--            </el-table-column>-->
<!--            <el-table-column-->
<!--                    prop="orderNum"-->
<!--                    header-align="center"-->
<!--                    align="center"-->
<!--                    label="订单数目(单)">-->
<!--            </el-table-column>-->
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    label="订单编号">
            </el-table-column>
            <el-table-column
                    prop="prodNum"
                    header-align="center"
                    align="center"
                    label="合计种类（种）">
            </el-table-column>
            <el-table-column
                    prop="num"
                    header-align="center"
                    align="center"
                    label="合计数量（本）">
            </el-table-column>
            <el-table-column
                    prop="amount"
                    header-align="center"
                    align="center"
                    label="合计金额（元）">
            </el-table-column>
            <el-table-column
                    prop="outBoundUser"
                    header-align="center"
                    align="center"
                    label="出库人员">
            </el-table-column>
            <el-table-column
                    prop="sellUser"
                    header-align="center"
                    align="center"
                    label="销售人员">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" v-if="scope.row.orderStateCode == 'haveOrder' || scope.row.orderStateCode == 'forOutBound'" @click="startPro(scope.row.id)">开始处理</el-button>
                    <el-button type="text" size="small" v-if="scope.row.orderStateCode != 'haveOrder' && scope.row.orderStateCode != 'forOutBound'"@click="startPro(scope.row.id)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <start-processing ref="startPro" @refreshDataList="getDataList"></start-processing>
    </div>
</template>

<script>
    import apiPage from '@/api';
    import StartProcessing from './start-processing'
    export default {
        components: {StartProcessing},
        data(){
            return{
                dataForm:{
                    orderState:'forOutBound',
                    code:'',
                    startTime:'',
                    endTime:''
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            clear(){
                this.dataForm= {
                    orderState:'forOutBound',
                    code:'',
                    startTime:'',
                    endTime:''
                };
                this.getDataList();
            },
            startPro(id){
                this.$nextTick(() => {
                    this.$refs.startPro.init(id);
                })
            },
            getDataList(){
                // axios.get('/mock/out-normal-product-list.json').then((data) => {
                //     if(data){
                //         this.dataList = data.list;
                //         this.totalPage = data.total;
                //     }
                // })
                let request = {
                    'orderState':this.dataForm.orderState,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };

                this.$get(apiPage.api.mallOrderList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>