<template>
    <div>
        <p class="red"><i class="el-icon-info"></i>只有异常品仓库中的即开票才可以进行异常品出库</p>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="结束时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary"  plain>异常品出库</el-button>
        </div>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="异常品出库编号">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="合计种类（种）">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="合计数量（本）">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="合计金额（元）">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="操作人">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="结束时间">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" >详情</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>


<script>
    export default {
        data(){
            return{
                dataForm:{
                    startTime:'',
                    endTime:''
                },
                dataList:[],

            }
        },
        methods:{
            clear(){

            },
            getDataList(){

            },

        },
        created() {

        }
    }
</script>
<style scoped>
    .red{
        color:red;
    }
</style>