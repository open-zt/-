<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary"  plain>盘点</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="结束时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="盘点编号">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="操作人">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="结束时间">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="备注">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" >详情</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    export default {
        name: "normal-list",
        data(){
            return{
                dataForm:{
                    startTime:'',
                    endTime:''
                },
                dataList:[],

            }
        },
        methods:{
            clear(){

            },
            getDataList(){

            },

        },
        created() {

        }
    }
</script>

<style scoped>

</style>