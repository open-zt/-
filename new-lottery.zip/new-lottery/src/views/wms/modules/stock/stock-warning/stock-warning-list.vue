<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="名称">
                <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="面值">
                <el-select v-model="dataForm.faceValue" placeholder="请选择" clearable>
                    <el-option v-for="item in faceValueList" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="编号">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="面值">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="价格(元/本)">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="单位">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="预警规则">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="预警库存">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" >设置预警规则</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>

</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "stock-warning-list",
        data(){
            return{
                dataForm:{
                    name:'',
                    faceValue:''
                },
                faceValueList:[],
                dataList:[],

            }
        },
        methods:{
            clear(){

            },
            getDataList(){

            },
            getFaceValueList(){
                this.$get(apiPage.api.faceValueList).then((data) => {
                    if(data.code == 0){
                        this.faceValueList = data.list;
                    }
                })
            },
        },
        created() {
            this.getFaceValueList();
        }
    }
</script>

<style scoped>

</style>