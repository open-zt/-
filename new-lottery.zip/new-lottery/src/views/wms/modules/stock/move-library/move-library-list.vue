<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary"  plain>移库申请</el-button>
        </div>
        <el-form :model="dataForm">
            <el-form-item label="审批状态：">
                <el-radio v-model="dataForm.state" label="全部" @change="getDataList">全部</el-radio>
                <el-radio v-model="dataForm.state" label="审批中" @change="getDataList">待付款</el-radio>
                <el-radio v-model="dataForm.state" label="审批完成" @change="getDataList">已付款</el-radio>
                <el-radio v-model="dataForm.state" label="已撤销" @change="getDataList">待取货</el-radio>
            </el-form-item>
        </el-form>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="移库类型">
                <el-select v-model="dataForm.type" placeholder="请选择" clearable>
                    <el-option value="0" label="即开票不可销售"></el-option>
                    <el-option value="1" label="即开票恢复销售"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="发起时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="申请编号">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="移库类型">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="摘要">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="原因">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="发起人">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="发起时间">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="审批状态">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" >详情</el-button>
                    <el-button type="text" size="small" >打印单据</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    export default {
        name: "move-library-list",
        data(){
            return{
                dataForm:{
                    state:'全部',
                    type:'',
                    startTime:'',
                    endTime:''
                },
                dataList:[],

            }
        },
        methods:{
            clear(){

            },
            getDataList(){

            },

        },
        created() {

        }
    }
</script>

<style scoped>

</style>