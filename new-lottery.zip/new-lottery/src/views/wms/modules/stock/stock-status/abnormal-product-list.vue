<template>
    <div>
        <div class="stock-total">
            <span>异常品库存统计：</span>
            <span>库存种类(种)   40</span>
            <span>库存数量(本)   40,000 </span>
            <span>库存总金额(元)   ¥ 240,000,000</span>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="名称">
                <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="编号">
                <el-input v-model="dataForm.code" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="面值">
                <el-select v-model="dataForm.faceValue" placeholder="请选择" clearable>
                    <el-option v-for="item in faceValueList" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="编号">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="面值">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="价格(元/本)">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="单位">
            </el-table-column>
            <el-table-column label="异常品库存"   header-align="center">
                <el-table-column
                        prop="faceValue"
                        header-align="center"
                        align="center"
                        label="库存">
                </el-table-column>
                <el-table-column
                        prop="faceValue"
                        header-align="center"
                        align="center"
                        label="金额（元）">
                </el-table-column>
            </el-table-column>
        </el-table>
    </div>

</template>

<script>
    import apiPage from '@/api'
    export default {
        data(){
            return{
                dataForm:{
                    name:'',
                    code:'',
                    faceValue:''
                },
                faceValueList:[],
                dataList:[],

            }
        },
        methods:{
            clear(){

            },
            getDataList(){

            },
            getFaceValueList(){
                this.$get(apiPage.api.faceValueList).then((data) => {
                    if(data.code == 0){
                        this.faceValueList = data.list;
                    }
                })
            },
        },
        created() {
            this.getFaceValueList();
        }
    }
</script>

<style scoped>
    .stock-total{
        width:100%;
        height:40px;
        box-shadow:  4px 6px 20px -1px #ccc;
        margin-bottom:20px;
        line-height: 40px;
        padding-left:20px;
    }
    .stock-total span{
        margin-right:50px;
    }
</style>