<template>
    <div>
<!--        库存明细-->
        <el-dialog
                class="dialog-con"
                :title='this.prodName'
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :inline="true">
                <el-form-item label="二维条形码">
                    <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="text" @click="clear()">清空条件</el-button>
                    <el-button type="primary" @click="getDataList()">查询</el-button>
                </el-form-item>
            </el-form>
            <el-table
                    border
                    style="width:100%"
                    :data="dataList">
                <el-table-column
                        type="index"
                        header-align="center"
                        align="center"
                        width="60"
                        label="序号">
                </el-table-column>
                <el-table-column
                        prop="prodName"
                        header-align="center"
                        align="center"
                        label="二维条形码">
                </el-table-column>
                <el-table-column
                        prop="prodName"
                        header-align="center"
                        align="center"
                        label="入库时间">
                </el-table-column>
            </el-table>
            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page.sync="pageIndex"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalPage"
                    v-if="this.dataList !=''">
            </el-pagination>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "inventory-details",
        data(){
            return{
                visible:false,
                prodName:"",
                dataForm:{
                    name:''
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,

            }
        },
        methods:{
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            init(id,prodName){
                this.visible = true;
                this.prodName = '库存明细-' + prodName;
            },
            getDataList(){

            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        }
    }
</script>

<style scoped>

</style>