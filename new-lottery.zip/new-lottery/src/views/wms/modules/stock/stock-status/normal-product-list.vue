<template>
    <div>
        <div class="stock-total">
            <span>正常品库存统计</span>
            <span>库存种类(种):   {{prodInfo.prodTotal}}</span>
            <span>库存数量(本):   {{prodInfo.prodInvTotal}}</span>
            <span>库存总金额(元): {{prodInfo.totalAmount}}</span>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="名称">
                <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="编号">
                <el-input v-model="dataForm.code" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="面值">
                <el-select v-model="dataForm.faceValue" placeholder="请选择" clearable>
                    <el-option v-for="item in faceValueList" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="prodName"
                    header-align="center"
                    align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="prodCode"
                    header-align="center"
                    align="center"
                    label="编号">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="面值">
            </el-table-column>
            <el-table-column
                    prop="saleAmount"
                    header-align="center"
                    align="center"
                    label="价格(元/本)">
            </el-table-column>
            <el-table-column
                    prop="unitDict"
                    header-align="center"
                    align="center"
                    label="单位">
            </el-table-column>
            <el-table-column label="库存"   header-align="center">
                <el-table-column
                        prop="canBuy"
                        header-align="center"
                        align="center"
                        label="可订数量">
                </el-table-column>
                <el-table-column
                        prop="alreadyBuy"
                        header-align="center"
                        align="center"
                        label="已订数量">
                </el-table-column>
                <el-table-column
                        prop="prodInv"
                        header-align="center"
                        align="center"
                        label="库存">
                    <template slot-scope="scope">
                        <a href="javascript:;"><p @click="inventoryDetails(scope.row.prodId,scope.row.prodName)" style="cursor: pointer">{{scope.row.prodInv}}</p></a>
                    </template>
                </el-table-column>
                <el-table-column
                        header-align="center"
                        align="center"
                        label="金额（元）">
                    <template slot-scope="scope">
                        <div >{{scope.row.saleAmount*scope.row.prodInv}}</div>
                    </template>
                </el-table-column>
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="各省存量总计">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="库存状态"
                    width="100">
<!--                <template slot-scope="scope">-->
<!--                    <el-button type="text" size="small" >补货</el-button>-->
<!--                </template>-->
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <inventory-details ref="detailsHandle"></inventory-details>
    </div>

</template>

<script>
    import apiPage from '@/api'
    import InventoryDetails from './inventory-details'
    export default {
        data(){
            return{
                dataForm:{
                    name:'',
                    code:'',
                    faceValue:''
                },
                faceValueList:[],
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
                amount:'',
                prodInfo:{
                    totalAmount:'',
                    prodInvTotal:'',
                    prodTotal:'',
                },
            }
        },
        components:{
            InventoryDetails
        },
        methods:{
            inventoryDetails(id,prodName){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.init(id,prodName);
                })
            },
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'name':this.dataForm.name,
                    'code':this.dataForm.code,
                    'faceValue':this.dataForm.faceValue,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.normalList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                    }
                })
            },
            getInfo(){
                this.$get(apiPage.api.normalInfo).then((data) => {
                    if(data.code == 0){
                        this.prodInfo = data.invInfo;
                    }else{
                    }
                })
            },
            getFaceValueList(){
                this.$get(apiPage.api.faceValueList).then((data) => {
                    if(data.code == 0){
                        this.faceValueList = data.list;
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getFaceValueList();
            this.getDataList();
            this.getInfo();
        }
    }
</script>

<style scoped>
    .stock-total{
        width:100%;
        height:40px;
        box-shadow:  4px 6px 20px -1px #ccc;
        margin-bottom:20px;
        line-height: 40px;
        padding-left:20px;
    }
    .stock-total span{
        margin-right:50px;
    }
</style>