<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary"  plain @click="putHandle">入库</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="结束时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="putStorangeNo"
                    header-align="center"
                    align="center"
                    label="入库单号">
            </el-table-column>
            <el-table-column
                    prop="totalTypeNumber"
                    header-align="center"
                    align="center"
                    label="合计种类（种）">
            </el-table-column>
            <el-table-column
                    prop="totalUnitNumber"
                    header-align="center"
                    align="center"
                    label="合计数量（本）">
            </el-table-column>
            <el-table-column
                    prop="totalAmount"
                    header-align="center"
                    align="center"
                    label="合计金额（元）">
            </el-table-column>
            <el-table-column
                    prop="createUserName"
                    header-align="center"
                    align="center"
                    label="操作人">
                <template slot-scope="scope">
                    <span>{{scope.row.createUserAccount}}-{{scope.row.createUserName}}</span>
                </template>
            </el-table-column>
            <el-table-column
                    prop="submitEndDate"
                    header-align="center"
                    align="center"
                    label="结束时间">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="detailHandle(scope.row.id)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <put-handle ref="putHandle" @refreshDataList="getDataList"></put-handle>
        <details-handle ref="detailsHandle"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api';
    import PutHandle from './put-handle'
    import DetailsHandle from './detail-handle'
    export default {
        name: "normal-list",
        components: {PutHandle,DetailsHandle},
        data(){
            return{
                dataForm:{
                    startTime:'',
                    endTime:''
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            clear(){
                this.dataForm = {
                    startTime:'',
                    endTime:''
                };
                this.getDataList();
            },
            putHandle(){
                this.$nextTick(() => {
                    this.$refs.putHandle.init();
                })
            },
            detailHandle(id){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.init(id);
                })
            },
            getDataList(){
                let request = {
                    'submitStartTime':this.dataForm.startTime[0],
                    'submitEndTime':this.dataForm.startTime[1],
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.putStorageList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },

        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>