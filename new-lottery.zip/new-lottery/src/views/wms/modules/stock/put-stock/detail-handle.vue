<template>
    <el-dialog
            class="dialog-con"
            title="详情"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            width="65%"
            :visible.sync="visible">
        <div>
            <div class="stock-title">
                <div>操作人：<span>{{putStorage.createUserAccount}}-{{putStorage.createUserName}}</span></div>
                <div>入库原因：<span>生产入库</span></div>
                <div>入库单号：<span>{{putStorage.putStorangeNo}}</span></div>
                <div>开始时间：<span>{{putStorage.submitStartDate}}</span></div>
                <div>结束时间：<span>{{putStorage.submitEndDate}}</span></div>
                <div>时长(秒)：<span>{{putStorage.timeTotal}}</span></div>
            </div>
            <div class="stock-alert">
                <span>入库明细</span>
            </div>

            <el-table
                    border
                    style="width:100%"
                    :data="dataList">
                <el-table-column
                        type="index"
                        header-align="center"
                        align="center"
                        width="60"
                        label="序号">
                </el-table-column>
                <el-table-column
                        prop="prodName"
                        header-align="center"
                        align="center"
                        label="名称">
                </el-table-column>
                <el-table-column
                        prop="barcode"
                        header-align="center"
                        align="center"
                        width="180"
                        label="条形码">
                </el-table-column>
                <el-table-column
                        prop="qrCode"
                        header-align="center"
                        align="center"
                        width="180"
                        label="二维码">
                </el-table-column>
                <el-table-column
                        prop="prodCode"
                        header-align="center"
                        align="center"
                        label="编号">
                </el-table-column>
                <el-table-column
                        prop="faceValue"
                        header-align="center"
                        align="center"
                        label="面值">
                </el-table-column>
                <el-table-column
                        prop="price"
                        header-align="center"
                        align="center"
                        width="180"
                        label="价格(元/本)">
                </el-table-column>
                <el-table-column
                        prop="unit"
                        header-align="center"
                        align="center"
                        label="单位">
                </el-table-column>
                <el-table-column
                        prop="number"
                        header-align="center"
                        align="center"
                        label="数量">
                    <template slot-scope="scope">
                        {{1}}
                    </template>
                </el-table-column>
            </el-table>
            <div class="stock-total">
                <span>合计种类(种)：{{this.putStorage.totalTypeNumber}}</span>
                <span>合计数量(本)：{{this.putStorage.totalUnitNumber}}</span>
                <span>合计金额(元)：{{this.putStorage.totalAmount}}</span>
            </div>
        </div>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary">打印单据</el-button>
        </span>
    </el-dialog>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "detail-handle",
        data(){
            return{
                visible:false,
                dataList:[],
                putStorage:{
                    createUserAccount:'',
                    createUserName:'',
                    putStorangeNo:'',
                    submitStartDate:'',
                    submitEndDate:'',
                    timeTotal:'',
                    totalTypeNumber:'',
                    totalUnitNumber:'',
                    totalAmount:''
                },
                id:'',
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.id = id;
                this.getDetails();
            },
            getDetails(){
                this.$get(apiPage.api.putStorageInfo + this.id).then((data) => {
                    if(data.code == 0){
                        this.putStorage = data.putStorange;
                        this.dataList = data.putStorange.itemList;
                    }
                })
            }
        }
    }
</script>

<style scoped>
    .stock-title div{
        display: inline-block;
        font-size: 16px;
        margin-right:30px;
        height:40px;
    }
    .stock-title div span{
        color:#000;
    }
    .stock-alert{
        height:40px;
    }
    .stock-alert{
        color:#000;
        font-size: 16px;
    }
    .stock-alert span{
        margin-right:30px;
    }
    .stock-total{
        height:50px;
        line-height: 50px;
        border:1px solid #EBEEF5;
        border-top:none;
        text-align: right;
        color:#000;
        font-size:16px;
    }
    .stock-total span{
        margin-left:80px;
        margin-right:20px;
    }
</style>