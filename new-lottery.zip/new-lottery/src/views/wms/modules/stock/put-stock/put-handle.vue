<template>
<div>
    <el-dialog
            class="dialog-con"
            title="入库"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            width="65%"
            :visible.sync="visible">

        <div>
            <div class="stock-title">
                <div>操作人：<span>{{this.dataForm.createUserAccount}}-{{this.dataForm.createUserName}}</span></div>
                <div>入库原因：<span>生产入库</span></div>
                <div>开始时间：<span>{{startTime}}</span></div>
            </div>
            <div class="stock-alert">
                <span>入库明细</span>
                <span class="red"><i class="el-icon-info"></i>请扫描即开票非游戏面的条形码以及游戏面的二维码开始入库</span>
            </div>

            <div class="table">
                <el-form :model="dataForm" :rules="rules" ref="dataForm">
                    <el-table
                            border
                            style="width:100%"
                            :data="dataForm.dataList">
                        <el-table-column
                                type="index"
                                header-align="center"
                                align="center"
                                width="60"
                                label="序号">
                        </el-table-column>
                        <el-table-column
                                prop="name"
                                header-align="center"
                                align="center"
                                label="名称">
                        </el-table-column>
                        <el-table-column
                                prop="barcode"
                                header-align="center"
                                align="center"
                                width="180"
                                label="条形码">
                            <template slot-scope="scope">
                                <el-form-item :prop="`dataList.${scope.$index}.barcode`"  :rules="rules.barcode" class="ml0">
                                    <el-input v-model="scope.row.barcode" placeholder="扫码或输入" @change="handleChange(scope.row.barcode,scope.$index+1)"></el-input>
                                </el-form-item>
                            </template>
                        </el-table-column>
                        <el-table-column
                                prop="qrCode"
                                header-align="center"
                                align="center"
                                width="180"
                                label="二维码">
                            <template slot-scope="scope">
                                <el-form-item :prop="`dataList.${scope.$index}.qrcode`"  :rules="rules.qrcode" class="ml0">
                                    <el-input v-model="scope.row.qrcode" placeholder="扫码或输入" @change="handleQrcode(scope.row.qrcode)" ref="input"></el-input>
                                </el-form-item>
                            </template>
                        </el-table-column>
                        <el-table-column
                                prop="code"
                                header-align="center"
                                align="center"
                                label="编号">
                        </el-table-column>
                        <el-table-column
                                prop="faceValue"
                                header-align="center"
                                align="center"
                                label="面值">
                        </el-table-column>
                        <el-table-column
                                prop="saleAmount"
                                header-align="center"
                                align="center"
                                width="180"
                                label="价格(元/本)">
                        </el-table-column>
                        <el-table-column
                                prop="unitDict"
                                header-align="center"
                                align="center"
                                label="单位">
                        </el-table-column>
                        <el-table-column
                                prop="number"
                                header-align="center"
                                align="center"
                                label="数量">
                        </el-table-column>
                    </el-table>
                </el-form>

            </div>
            <div class="stock-total">
                <span>合计种类(种)：{{this.dataForm.totalTypeNumber}}</span>
                <span>合计数量(本)：{{this.dataForm.totalUnitNumber}}</span>
                <span>合计金额(元)：{{this.dataForm.totalAmount}}</span>
            </div>
        </div>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="submitFormData()" >入库并打印</el-button>
        </span>
    </el-dialog>
</div>
</template>

<script>
    import apiPage from '@/api';

    export default {
        name: "put-handle",
        data(){
            const barCodeRule = (rule,value,callback) => {
                this.$get(apiPage.api.productInfo+'?'+'barcode='+ value).then((data) =>{
                    if(data.code == 500){
                        callback(data.msg);
                    }else{
                        callback();
                    }
                }).catch(() => {
                    callback(new Error('服务异常'));
                })
            };
            return{
                visible:false,
                startTime:'',
                endTime:'',
                dataForm:{
                    createUserId:sessionStorage.getItem('userId'),
                    createUserName:sessionStorage.getItem('name'),
                    createUserAccount:sessionStorage.getItem('account'),
                    type:1,
                    totalTypeNumber:'',
                    totalUnitNumber:'',
                    totalAmount:'',
                    dataList:[
                        {
                            barcode:'',
                            qrcode:'',
                        }
                    ],
                },
                rules:{
                    barcode: [{required: true, message: '条形码必填',trigger: 'blur'}, {validator:barCodeRule, trigger: 'blur'}],
                    qrcode: [{required: true, message: '二维码必填',trigger: 'blur'}],
                },
            }
        },
        methods:{
            handleChange(value,key){
                var price = 0;
                if(value){
                    // this.$nextTick(() => {
                    //     console.log(this.$refs['input']);
                    //     this.$refs['input'].$el.querySelector('input').focus();
                    // });

                    this.$get(apiPage.api.productInfo +'?'+'barcode='+ value).then((data) => {
                        if(data.code == 0){
                            let _t = this.dataForm.dataList.findIndex(function(item){
                                return item.barcode === value;
                            });
                            if(this.dataForm.dataList.length <= 0){
                                this.dataForm.dataList.pop();
                                this.dataForm.dataList.push(data.product)
                            } else if(_t >= 0){
                                if(key != this.dataForm.dataList.length){
                                    this.dataForm.dataList.splice(_t,1,data.product);
                                }else{
                                    this.dataForm.dataList.pop();
                                    this.dataForm.dataList.push(data.product)
                                }
                            }

                            let hash ={};
                            const temp = this.dataForm.dataList.reduce((perVal,curVal) => {
                                hash[curVal.id] ? '' :hash[curVal.id] = true && perVal.push(curVal);
                                return perVal;
                            },[]);
                            this.dataForm.totalTypeNumber = temp.length;

                            this.dataForm.totalUnitNumber = this.dataForm.dataList.length;
                            for(var i = 0;i < this.dataForm.dataList.length;i++){
                                price += Number(this.dataForm.dataList[i].saleAmount);
                            }
                            this.dataForm.totalAmount = price.toFixed(2);

                        }
                    });
                }
            },
            handleQrcode(value){
              if(value){
                  let _t = this.dataForm.dataList.findIndex(function(item){
                          return item.barcode === '' ;
                  });
                  if(_t < 0){
                      this.dataForm.dataList.push({barcode:'',qrcode:''});
                  }
              }
            },
            appendzero(obj) {
                if(obj<10) return "0" +""+ obj;
                else return obj;
            },
            getTime(){
                var now = new Date();
                var year = now.getFullYear();
                var month = now.getMonth() +1;
                var date = now.getDate();
                var hour = now.getHours();
                var minute = now.getMinutes();
                var seconds = now.getSeconds();

                this.startTime = year + "年" + this.appendzero(month)  + "月" + this.appendzero(date) + "日 " + this.appendzero(hour) + ':' + this.appendzero(minute) + ":" + this.appendzero(seconds);
            },
            getEndTime(){
                var now = new Date();
                var year = now.getFullYear();
                var month = now.getMonth() +1;
                var date = now.getDate();
                var hour = now.getHours();
                var minute = now.getMinutes();
                var seconds = now.getSeconds();

                this.endTime = year + "年" + this.appendzero(month)  + "月" + this.appendzero(date) + "日 " + this.appendzero(hour) + ':' + this.appendzero(minute) + ":" + this.appendzero(seconds);
            },
            init(){
                this.visible = true;
                this.getTime();
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.dataForm = {
                        createUserId:sessionStorage.getItem('userId'),
                        createUserName:sessionStorage.getItem('name'),
                        createUserAccount:sessionStorage.getItem('account'),
                        type:1,
                        totalTypeNumber:'',
                        totalUnitNumber:'',
                        totalAmount:'',
                        dataList:[{
                            barcode:'',
                            qrcode:'',
                        }]
                    }
                })
            },
            submitFormData(){
                this.getEndTime();
                let itemList = this.dataForm.dataList.slice(0,this.dataForm.dataList.length-1);
                let request = {
                    'createUserId':this.dataForm.createUserId,
                    'createUserName':this.dataForm.createUserName,
                    'createUserAccount':this.dataForm.createUserAccount,
                    'type':1,
                    'submitStartDate':this.startTime,
                    'submitEndDate':this.endTime,
                    'totalTypeNumber':this.dataForm.totalTypeNumber,
                    'totalUnitNumber':this.dataForm.totalUnitNumber,
                    'totalAmount':this.dataForm.totalAmount,
                    'prodItemList':itemList
                };

                if(this.dataForm.dataList.length > 1){
                    this.$refs['dataForm'].clearValidate();
                    this.$confirm(`入库后，即开票库存数量将会增加您确认要进行入库吗？`, '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        center: true
                    }).then(() => {
                        this.$post(apiPage.api.putStorageSave,request).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 800,
                                    onClose: () => {
                                        this.$emit('refreshDataList');
                                        this.visible = false;
                                    }
                                });
                            }else {
                                this.$message.error(data.msg);
                            }
                        })
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消入库'
                        });
                    })
                }else{
                    this.$refs['dataForm'].validate((valid) =>{
                        if(valid){
                            this.$confirm(`入库后，即开票库存数量将会增加您确认要进行入库吗？`, '提示', {
                                confirmButtonText: '确定',
                                cancelButtonText: '取消',
                                center: true
                            }).then(() => {
                                this.$post(apiPage.api.putStorageSave,request).then((data) => {
                                    if(data.code == 0){
                                        this.$message({
                                            message: '操作成功',
                                            type: 'success',
                                            duration: 800,
                                            onClose: () => {
                                                this.$emit('refreshDataList');
                                                this.visible = false;
                                            }
                                        });
                                    }else {
                                        this.$message.error(data.msg);
                                    }
                                })
                            }).catch(() => {
                                this.$message({
                                    type: 'info',
                                    message: '已取消入库'
                                });
                            })
                        }
                    })
                }


            }
        },
        created() {
        }
    }
</script>
<style>
    .table .el-table .el-form-item.ml0{
        margin-bottom:0!important;
        height: 60px;
    }
</style>
<style scoped>

    .stock-title div{
        display: inline-block;
        font-size: 16px;
        margin-right:30px;
        height:40px;
    }
    .stock-title div span{
        color:#000;
    }
    .stock-alert{
        height:40px;
    }
    .stock-alert{
        color:#000;
        font-size: 16px;
    }
    .stock-alert span{
        margin-right:30px;
    }
    .table .el-table{
        height:454px;
        overflow-y: overlay;
    }
    .table .el-table .el-form-item{
        margin-bottom:16px;
    }
    .stock-total{
        height:50px;
        line-height: 50px;
        border:1px solid #EBEEF5;
        border-top:none;
        text-align: right;
        color:#000;
        font-size:16px;
    }
    .stock-total span{
        margin-left:80px;
        margin-right:20px;
    }
</style>