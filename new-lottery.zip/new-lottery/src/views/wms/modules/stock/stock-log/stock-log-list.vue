<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="名称">
                <el-input v-model="dataForm.prodName" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="面值">
                <el-select v-model="dataForm.faceValue" placeholder="请选择" clearable>
                    <el-option v-for="item in faceValueList" :key="item.id" :value="item.name" :label="item.name"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="变化数量">
                <el-input v-model="dataForm.addNum" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="变化后数量">
                <el-input v-model="dataForm.finalNum" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="prodName"
                    header-align="center"
                    align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="prodCode"
                    header-align="center"
                    align="center"
                    label="编号">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="面值">
            </el-table-column>
            <el-table-column
                    prop="price"
                    header-align="center"
                    align="center"
                    label="价格(元/本)">
            </el-table-column>
            <el-table-column
                    prop="unit"
                    header-align="center"
                    align="center"
                    label="单位">
            </el-table-column>
            <el-table-column label="变更"   header-align="center">
                <el-table-column
                        prop="typeName"
                        header-align="center"
                        align="center"
                        label="原因">
                </el-table-column>
                <el-table-column
                        prop="addNum"
                        header-align="center"
                        align="center"
                        label="变化数量">
                </el-table-column>
                <el-table-column
                        prop="finalNum"
                        header-align="center"
                        align="center"
                        label="变化后数量">
                </el-table-column>
            </el-table-column>
            <el-table-column
                    prop="createUserName"
                    header-align="center"
                    align="center"
                    label="操作人">
            </el-table-column>
            <el-table-column
                    prop="createDate"
                    header-align="center"
                    align="center"
                    label="变更时间">
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

    </div>

</template>

<script>
    import apiPage from '@/api'
    export default {
        data(){
            return{
                dataForm:{
                    prodName:'',
                    addNum:'',
                    finalNum:'',
                    faceValue:''
                },
                faceValueList:[],
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            inventoryDetails(id,prodName){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.init(id,prodName);
                })
            },
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'prodName':this.dataForm.prodName,
                    'addNum':this.dataForm.addNum,
                    'finalNum':this.dataForm.finalNum,
                    'faceValue':this.dataForm.faceValue,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.putStorageLog,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                    }
                })
            },
            getFaceValueList(){
                this.$get(apiPage.api.faceValueList).then((data) => {
                    if(data.code == 0){
                        this.faceValueList = data.list;
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getFaceValueList();
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>