<template>
    <el-dialog
            class="dialog-con"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            title="发货"
            :visible.sync="visible" >
        <div class="send-content">
            <img src="../../../../assets/images/sweep-code.png"/>
            <div class="tips">请先扫描您要处理订单的
                <span class="black">订单编号</span>
                <p class="red">{{message}}</p>
            </div>
            <el-form :model="dataForm"  :rules="rules" ref="dataForm"  @submit.native.prevent>
                <el-row>
                    <el-col :span="5">

                    </el-col>
                    <el-col :span="13">
                        <el-form-item prop="orderNum">
                            <el-input v-model="dataForm.orderNum" placeholder="您也可以在此手动输入 订单编号" @keyup.enter.native="dataFormSubmit()">
                                <el-button slot="append" icon="el-icon-right" @click="dataFormSubmit()" ></el-button>
                            </el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
        </div>
        <details-handle ref="detailsHandle" v-bind="$attrs" v-on="$listeners"></details-handle>
    </el-dialog>
</template>

<script>
    import apiPage from '@/api';
    import DetailsHandle from './details-handle'
    export default {
        name: "send-handle",
        data(){
            return{
                visible:false,
                dataForm:{
                    orderNum:'',
                    id:''
                },
                message:'',
                rules:{
                    orderNum: [{required: true, message: '订单编号必填',trigger: 'blur'}],
                },
            }
        },
        components:{
            DetailsHandle
        },
        inheritAttrs: false,
        methods:{
            dataFormSubmit(){
                let request = {
                    'orderNo':this.dataForm.orderNum
                };
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.$post(apiPage.api.verifyOrderNo,request).then((data) =>{
                            if(data.code == 0){
                                this.dataForm.id = data.orderId;
                                this.visible = false;
                                this.$nextTick(() => {
                                    this.$refs.detailsHandle.init(this.dataForm.id);
                                })
                                this.$emit('refreshDataList');
                            }else if(data.code == 500){
                                this.message = data.msg;
                            }
                        })
                    }
                })
            },
            init(){
                this.visible = true;
            }
        }
    }
</script>

<style scoped>
    .send-content{
        text-align: center;
    }
    .send-content .el-form{
        margin-left:35%;
    }
    .tips{
        font-size:18px;
        margin:40px 0 200px;
    }
</style>