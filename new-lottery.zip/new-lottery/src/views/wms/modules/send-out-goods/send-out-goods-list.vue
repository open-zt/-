<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" plain @click="sendGood">发货</el-button>
        </div>
<!--        <el-form :model="dataForm" :inline="true">-->
<!--            <el-form-item label="发起时间">-->
<!--                <el-date-picker-->
<!--                        v-model="dataForm.allotStartTime"-->
<!--                        type="daterange"-->
<!--                        value-format="yyyy-MM-dd"-->
<!--                        start-placeholder="开始时间"-->
<!--                        end-placeholder="结束时间">-->
<!--                </el-date-picker>-->
<!--            </el-form-item>-->
<!--            <el-form-item label="下单时间">-->
<!--                <el-date-picker-->
<!--                        v-model="dataForm.allotStartTime"-->
<!--                        type="daterange"-->
<!--                        value-format="yyyy-MM-dd"-->
<!--                        start-placeholder="开始时间"-->
<!--                        end-placeholder="结束时间">-->
<!--                </el-date-picker>-->
<!--            </el-form-item>-->
<!--            <el-form-item label="订单编号">-->
<!--                <el-input v-model="dataForm.orderNo" placeholder="请输入" clearable></el-input>-->
<!--            </el-form-item>-->
<!--            <el-form-item>-->
<!--                <el-button type="text" @click="clear()">清空条件</el-button>-->
<!--                <el-button type="primary" @click="getDataList()">查询</el-button>-->
<!--            </el-form-item>-->
<!--        </el-form>-->
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    label="下单时间 ">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="销售时间">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="发货时间">
            </el-table-column>
            <el-table-column
                    prop="orderNo"
                    width="180"
                    header-align="center"
                    align="center"
                    label="订单编号">
            </el-table-column>
            <el-table-column
                    prop="prodNum"
                    header-align="center"
                    align="center"
                    label="合计种类（种）">
            </el-table-column>
            <el-table-column
                    prop="num"
                    header-align="center"
                    align="center"
                    label="合计数量（本）">
            </el-table-column>
            <el-table-column
                    prop="amount"
                    header-align="center"
                    align="center"
                    label="合计金额（元）">
            </el-table-column>
            <el-table-column
                    prop="geoAddress"
                    header-align="center"
                    align="center"
                    label="地区">
            </el-table-column>
            <el-table-column
                    prop="terminalType"
                    header-align="center"
                    align="center"
                    label="终端类型">
                <template slot-scope="scope">
                    <p v-if="scope.row.terminalType == 1">投注站</p>
                    <p v-if="scope.row.terminalType == 2">渠道</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="terminalName"
                    header-align="center"
                    align="center"
                    label="终端">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="detailsHandle(scope.row.id)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <send-handle ref="sendHandle" @refreshDataList="getDataList"></send-handle>
        <detail-handle ref="detailsHandle" @refreshDataList="getDataList"></detail-handle>
    </div>
</template>

<script>
    import apiPage from '@/api';
    import SendHandle from './send-handle'
    import DetailHandle from "./details-handle";
    export default {
        name: "take-goods-list",
        data(){
            return{
                dataForm:{
                    orderState:'finishToSend',
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        components:{
            DetailHandle,
            SendHandle
        },
        methods:{
            sendGood(){
                this.$nextTick(() => {
                    this.$refs.sendHandle.init();
                })
            },
            detailsHandle(id){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.init(id);
                })
            },
            getDataList(){
                let request = {
                    'orderState':this.dataForm.orderState,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };

                this.$get(apiPage.api.mallOrderList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>