<template>
    <div class="home">
        <el-row :gutter="20">
            <el-col :span="3" v-for="(item,index) in cardList"  :key="item.id">
                <el-card shadow="always" >
                    <div>{{item.title}}</div>
                    <p>{{item.price}}</p>
                    <p>上月:{{item.lastMonth}}</p>
                    <p>增长:{{item.buildUp}}</p>
                    <p>增长%:{{item.buildUpPercentage}}</p>
                </el-card>
            </el-col>
        </el-row>

        <div>
            <el-tabs v-model="activeName">
                <el-tab-pane :label="cityLabel" name="first">
                    <el-row style="height:30px;line-height: 30px;">
                        <el-col>
                            <el-breadcrumb separator-class="el-icon-arrow-right">
                                <el-breadcrumb-item><a href="javascript:;" @click="cityClick">{{cityLabel}}</a></el-breadcrumb-item>
                                <el-breadcrumb-item v-if="this.isLabel !='' && this.isLabel !=null"><a href="javascript:;" @click="typeClick" >{{isLabel}}</a></el-breadcrumb-item>
                                <el-breadcrumb-item v-if="this.secondLabel != '' && this.secondLabel != null"><a href="javascript:;" >{{secondLabel}}</a></el-breadcrumb-item>
                            </el-breadcrumb>
                        </el-col>
                    </el-row>
                    单位：亿元
                    <el-table :data="cityList"
                              v-if="cityListVisible"
                              style="width:100%;margin-top:10px;"
                              row-key="id"
                              :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}"
                              :summary-method="getSummaries"
                              show-summary>
                        <el-table-column header-align="center" align="center" label="地域" prop="name" width="150">
                            <template slot-scope="scope">
                                <el-popover
                                        placement="right"
                                        trigger="click">
                                    <div>
                                        <p class="pointer" @click="handleClick(scope.row.name,scope.row.id,2)">各类型彩票销售情况</p>
                                        <p class="pointer" @click="handleClick2(scope.row.name,scope.row.id,2)">各种经营方式销售情况</p>
                                    </div>
                                    <div slot="reference" class="pointer">{{scope.row.name}}</div>
                                </el-popover>
                            </template>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本月销售">
                            <el-table-column prop="month" header-align="center" align="center" label="本月"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本年累计销售">
                            <el-table-column prop="total" header-align="center" align="center" label="累计"></el-table-column>
                            <el-table-column prop="totalAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalAmount > 0" :style="{color:'red'}">{{scope.row.totalAmount}}</p>
                                    <p v-if="scope.row.totalAmount < 0" :style="{color:'green'}">{{scope.row.totalAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="totalRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalRate > 0" :style="{color:'red'}">{{scope.row.totalRateView}}</p>
                                    <p v-if="scope.row.totalRate < 0" :style="{color:'green'}">{{scope.row.totalRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                    <el-table :data="getCityTypeList"
                              v-if="getCityTypeListVisible"
                              style="width:100%;margin-top:10px;"
                              row-key="id"
                              :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}"
                              :summary-method="getSummaries"
                              show-summary>
                        <el-table-column header-align="center" align="center" :label="isLabel" prop="name" width="150">
                            <template slot-scope="scope">
                                <el-popover
                                        placement="right"
                                        trigger="click">
                                    <div>
                                        <p class="pointer" @click="secondClick(scope.row.name,scope.row.id,1)">各种经营方式销售情况</p>
                                    </div>
                                    <div slot="reference" class="pointer">{{scope.row.name}}</div>
                                </el-popover>
                            </template>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本月销售">
                            <el-table-column prop="month" header-align="center" align="center" label="本月"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本年累计销售">
                            <el-table-column prop="total" header-align="center" align="center" label="累计"></el-table-column>
                            <el-table-column prop="totalAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalAmount > 0" :style="{color:'red'}">{{scope.row.totalAmount}}</p>
                                    <p v-if="scope.row.totalAmount < 0" :style="{color:'green'}">{{scope.row.totalAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="totalRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalRate > 0" :style="{color:'red'}">{{scope.row.totalRateView}}</p>
                                    <p v-if="scope.row.totalRate < 0" :style="{color:'green'}">{{scope.row.totalRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                    <el-table :data="getCityChanList"
                              v-if="getCityChanListVisible"
                              style="width:100%;margin-top:10px;"
                              row-key="id"
                              :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}"
                              :summary-method="getSummaries"
                              show-summary>
                        <el-table-column header-align="center" align="center" :label="isLabel" prop="name" width="150">
                            <template slot-scope="scope">
                                <el-popover
                                        placement="right"
                                        trigger="click">
                                    <div>
                                        <p class="pointer" @click="secondClick(scope.row.name,scope.row.id,3)">各类型彩票销售情况</p>
                                    </div>
                                    <div slot="reference" class="pointer">{{scope.row.name}}</div>
                                </el-popover>
                            </template>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本月销售">
                            <el-table-column prop="month" header-align="center" align="center" label="本月"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本年累计销售">
                            <el-table-column prop="total" header-align="center" align="center" label="累计"></el-table-column>
                            <el-table-column prop="totalAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalAmount > 0" :style="{color:'red'}">{{scope.row.totalAmount}}</p>
                                    <p v-if="scope.row.totalAmount < 0" :style="{color:'green'}">{{scope.row.totalAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="totalRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalRate > 0" :style="{color:'red'}">{{scope.row.totalRateView}}</p>
                                    <p v-if="scope.row.totalRate < 0" :style="{color:'green'}">{{scope.row.totalRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                    <el-table :data="secondList"
                              v-if="secondListVisible"
                              style="width:100%;margin-top:10px;"
                              row-key="id"
                              :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}"
                              :summary-method="getSummaries"
                              show-summary>
                        <el-table-column header-align="center" align="center" :label="secondLabel" prop="name" width="150">
                            <template slot-scope="scope">
                                {{scope.row.name}}
                            </template>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本月销售">
                            <el-table-column prop="month" header-align="center" align="center" label="本月"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本年累计销售">
                            <el-table-column prop="total" header-align="center" align="center" label="累计"></el-table-column>
                            <el-table-column prop="totalAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalAmount > 0" :style="{color:'red'}">{{scope.row.totalAmount}}</p>
                                    <p v-if="scope.row.totalAmount < 0" :style="{color:'green'}">{{scope.row.totalAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="totalRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalRate > 0" :style="{color:'red'}">{{scope.row.totalRateView}}</p>
                                    <p v-if="scope.row.totalRate < 0" :style="{color:'green'}">{{scope.row.totalRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                </el-tab-pane>
                <el-tab-pane label="各类型彩票销售情况" name="second">
                    单位：亿元
                    <el-table :data="typeList"
                              style="width:100%;margin-top:10px;"
                              row-key="id"
                              :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}"
                              :summary-method="getSummaries"
                              show-summary>
                        <el-table-column header-align="center" align="center" label="彩票类型" prop="name" width="150"></el-table-column>
                        <el-table-column header-align="center" align="center" label="本月销售">
                            <el-table-column prop="month" header-align="center" align="center" label="本月"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率%" >
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本年累计销售">
                            <el-table-column prop="total" header-align="center" align="center" label="累计"></el-table-column>
                            <el-table-column prop="totalAmount" header-align="center" align="center" label="环比增长额">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalAmount > 0" :style="{color:'red'}">{{scope.row.totalAmount}}</p>
                                    <p v-if="scope.row.totalAmount < 0" :style="{color:'green'}">{{scope.row.totalAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="totalRate" header-align="center" align="center" label="环比增长率%">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalRate > 0" :style="{color:'red'}">{{scope.row.totalRateView}}</p>
                                    <p v-if="scope.row.totalRate < 0" :style="{color:'green'}">{{scope.row.totalRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                </el-tab-pane>
                <el-tab-pane label="各种经营方式销售情况" name="third">
                    单位：亿元
                    <el-table :data="channelList"
                              style="width:100%;margin-top:10px;"
                              row-key="id"
                              :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}"
                              :summary-method="getSummaries"
                              show-summary>
                        <el-table-column header-align="center" align="center" label="经营方式" prop="name"></el-table-column>
                        <el-table-column header-align="center" align="center" label="本月销售">
                            <el-table-column prop="month" header-align="center" align="center" label="本月" width="120"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年" width="120"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比" width="120"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比" width="120"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率%" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率%" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本年累计销售">
                            <el-table-column prop="total" header-align="center" align="center" label="累计" width="120"></el-table-column>
                            <el-table-column prop="totalAmount" header-align="center" align="center" label="环比增长额" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalAmount > 0" :style="{color:'red'}">{{scope.row.totalAmount}}</p>
                                    <p v-if="scope.row.totalAmount < 0" :style="{color:'green'}">{{scope.row.totalAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="totalRate" header-align="center" align="center" label="环比增长率%" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalRate > 0" :style="{color:'red'}">{{scope.row.totalRateView}}</p>
                                    <p v-if="scope.row.totalRate < 0" :style="{color:'green'}">{{scope.row.totalRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                </el-tab-pane>
                <el-tab-pane label="累计销售情况" name="fourth">
                    单位：亿元
                    <el-table :data="monthList"
                              style="width:100%;margin-top:10px;"
                              row-key="id"
                              :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}"
                              :summary-method="getSummaries"
                              show-summary>
                        <el-table-column header-align="center" align="center" label="月份" prop="title"></el-table-column>
                        <el-table-column header-align="center" align="center" label="本月销售">
                            <el-table-column prop="month" header-align="center" align="center" label="本月" width="120"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年" width="120"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比" width="120"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比" width="120"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率%" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率%" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                        <el-table-column header-align="center" align="center" label="本年累计销售">
                            <el-table-column prop="total" header-align="center" align="center" label="累计" width="120"></el-table-column>
                            <el-table-column prop="totalAmount" header-align="center" align="center" label="环比增长额" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalAmount > 0" :style="{color:'red'}">{{scope.row.totalAmount}}</p>
                                    <p v-if="scope.row.totalAmount < 0" :style="{color:'green'}">{{scope.row.totalAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="totalRate" header-align="center" align="center" label="环比增长率%" width="120">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.totalRate > 0" :style="{color:'red'}">{{scope.row.totalRateView}}</p>
                                    <p v-if="scope.row.totalRate < 0" :style="{color:'green'}">{{scope.row.totalRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import axios from 'axios'
    import {getBaseUrl} from "@/util";

    export default {
        data(){
            return{
                activeName: 'first',
                cityLabel:'地域销售情况',
                typeNum:0,
                isLabel:'',
                cardList:[],
                cityListVisible:true,
                cityList:[],
                typeList:[],
                channelList:[],
                monthList:[],
                getCityTypeList:[],
                getCityTypeListVisible:false,
                getCityChanList:[],
                getCityChanListVisible:false,
                option:'',
                optionType:'',
                secondList:[],
                secondListVisible:false,
                secondLabel:'',
            }
        },
        components:{
        },
        methods:{
            cityClick(){
                this.getCityTypeListVisible = false;  //彩票类型表格隐藏
                this.getCityChanListVisible = false;  //经营方式表格隐藏
                this.secondListVisible = false;       //三级表格隐藏
                this.isLabel = '';                    //第二集导航为空
                this.secondLabel = '';                //第三集导航为空
                this.cityListVisible = true;          //默认地域显示
                this.getCityList();
            },
            typeClick(){
                if(this.typeNum===1){
                    this.secondLabel = '';
                    this.secondListVisible = false;
                    this.getCityTypeListVisible = true;
                }else if(this.typeNum===2){
                    this.secondLabel = '';
                    this.secondListVisible = false;
                    this.getCityChanListVisible = true;
                }
            },
            secondClick(name,id,type){
                if(this.typeNum === 1){
                    axios.get(getBaseUrl()+apiPage.api.listChannel, {
                        params: {option:this.option,optionType: this.optionType,option2: id, optionType2: type,},
                    }).then((data) => {
                        this.getCityTypeListVisible = false;
                        this.secondListVisible = true;
                        this.secondList = data.data;
                        this.secondLabel = name + '经营方式销售情况';
                    })
                }else if(this.typeNum === 2){
                    axios.get(getBaseUrl()+apiPage.api.listType, {
                        params: {option: this.option, optionType: this.optionType,option2: id, optionType2: type,},
                    }).then((data) => {
                        this.getCityChanListVisible = false;
                        this.secondListVisible = true;
                        this.secondList = data.data;
                        this.secondLabel = name + '彩票类型销售情况';
                    })
                }
            },
            handleClick(name,id,type){
                axios.get(getBaseUrl()+apiPage.api.listType, {
                    params: {option: id, optionType: type,},
                }).then((data) => {
                    this.cityListVisible = false;
                    this.getCityTypeListVisible = true;
                    this.getCityTypeList = data.data;
                    this.isLabel = name + '彩票类型销售情况';
                    this.option = data.option;
                    this.optionType = data.optionType;
                    this.typeNum=1;
                })
            },
            handleClick2(name,id,type){
                axios.get(getBaseUrl()+apiPage.api.listChannel, {
                    params: {option: id, optionType: type,},
                }).then((data) => {
                    this.cityListVisible = false;
                    this.getCityChanListVisible = true;
                    this.getCityChanList = data.data;
                    this.isLabel = name + '经营方式销售情况';
                    this.option = data.option;
                    this.optionType = data.optionType;
                    this.typeNum=2;
                })
            },
            getCityList(){
                this.$get(apiPage.api.listCity).then((data) => {
                    if(data.code == 0){
                        this.cityList = data.data;
                    }
                })
            },
            getTypeList(){
                this.$get(apiPage.api.listType).then((data) => {
                    if(data.code == 0){
                        this.typeList = data.data;
                    }
                })
            },
            getChannelList(){
                this.$get(apiPage.api.listChannel).then((data) => {
                    if(data.code == 0){
                        this.channelList = data.data;
                    }
                })
            },
            getMonthList(){
                this.$get(apiPage.api.listMonth).then((data) => {
                    if(data.code == 0){
                        this.monthList = data.data;
                    }
                })
            },
            getCardList(){
                axios.get('/mock/homeSale.json').then((data) => {
                    if(data){
                        this.cardList = data.list;
                    }
                })
            },
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                //环比增长率%
                let isMonthSale = 0;
                let yesMonthSale = 0;
                let isMonthTotalSale = 0;
                //同比增长率%
                let yesSameRate = 0;
                let sameTotalRate = 0;
                //本年环比增长率%
                let yearSale = 0;
                let yesTotal = 0;
                let yearTotalSale = 0;

                data.forEach((i) => {
                    if(i.month != null && i.yesterMonth != null){
                        isMonthSale +=  i.month;
                        yesMonthSale += i.yesterMonth;
                        isMonthTotalSale = (isMonthSale - yesMonthSale)/yesMonthSale*100;
                        isMonthTotalSale = isMonthTotalSale.toFixed(2);
                    }
                    if(i.month != null && i.yesteryearMonth != null){
                        isMonthSale +=  i.month;
                        yesSameRate += i.yesteryearMonth;
                        sameTotalRate = (isMonthSale - yesSameRate)/yesSameRate*100;
                        sameTotalRate = sameTotalRate.toFixed(2);
                    }
                    if(i.yesteryear != null && i.total != null){
                        yearSale +=  i.yesteryear;
                        yesTotal += i.total;
                        yearTotalSale = (yesTotal - yearSale)/yearSale*100;
                        yearTotalSale = yearTotalSale.toFixed(2);
                    }
                });


                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '合计';
                        return;
                    }
                    if(index === 3 || index === 4) {
                        sums[index] = '0';
                        return;
                    }
                    if(index === 6) {
                        sums[index] = isMonthTotalSale + '%';
                        return;
                    }
                    if(index === 8) {
                        sums[index] = sameTotalRate + '%';
                        return;
                    }
                    if(index === 11) {
                        sums[index] = yearTotalSale + '%';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                            const value = Number(curr);
                            if (!isNaN(value)) {
                                return prev + curr;
                            } else {
                                return prev;
                            }
                        }, 0);
                    }
                });
                return sums;
            },
        },
        created() {
            this.getCityList();
            this.getCardList();
            this.getTypeList();
            this.getMonthList();
            this.getChannelList();
        }
    }
</script>

<style>
    .home .el-table [class*=el-table__row--level] .el-table__expand-icon{
        position: absolute!important;
        left: 2px!important;
    }
    .home .cell .el-table__indent{
        padding-left:0!important;
    }
    .home .cell .el-table__placeholder{
        display: block!important;
    }
</style>