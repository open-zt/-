<template>
    <div>忘记密码页面</div>
</template>

<script>
    export default {
        name: "forget-password"
    }
</script>

<style scoped>

</style>