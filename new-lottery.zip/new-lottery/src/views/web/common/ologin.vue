<template>
    <div class="site-wrapper site-page--login">
        <div class="site-content__wrapper">
            <div class="site-content">
<!--                <div class="brand-info">-->
<!--                    <h2 class="brand-info__text">终端采购系统</h2>-->
<!--                </div>-->

                <div class="login-main">
                    <div id="login" class="login">
                        <span slot="label" class="login-title">登录</span>
                        <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="login()" status-icon class="form">
                            <el-form-item prop="userName">
                                <el-input v-model="dataForm.username" placeholder="帐号"></el-input>
                            </el-form-item>
                            <el-form-item prop="password">
                                <el-input v-model="dataForm.password" type="password" placeholder="密码"></el-input>
                            </el-form-item>
                            <el-form-item>
                                <div class="login-password">
                                    <el-checkbox v-model="checked">记住用户名</el-checkbox>
                                    <router-link to="forgetPassWord"><span>忘记密码</span></router-link>
                                </div>
                            </el-form-item>
                            <el-form-item>
                                <el-button class="login-btn-submit" type="primary" @click="login()">登录</el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="login-right">
                        <div class="logo">
                          <span class="iconfont icon-logoshiliang"></span>
                        </div>
                        <div class="name">
                            中国福利彩票 终端采购系统
                        </div>
                        <div class="icp">京公网安备11010802014104号 © 2008-2019</div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</template>

<script>
    import apiPage from '../api/index'

    export default {
        name: "login",
        data(){
            return{
                checked:false,
                dataForm:{
                    username:'',
                    password:'',
                    roleId:5,
                },
                dataRule:{
                    username: [
                        {required: true, message: '登录名不能为空', trigger: 'blur'}
                    ],
                    password: [
                        {required: true, message: '密码不能为空', trigger: 'blur'}
                    ],
                }
            }
        },
        methods:{
            login(){
                let loginData = {
                    'username': this.dataForm.username,
                    'password': this.$md5(this.dataForm.password),
                    'roleId':this.dataForm.roleId
                };
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        this.$post(apiPage.api.login,loginData).then((data)=>{
                            if (data.code === 0) {
                                sessionStorage.setItem("token", data.token);
                                sessionStorage.setItem("name",data.userInfo.name);
                                sessionStorage.setItem("userId",data.userInfo.userId);
                                sessionStorage.setItem("account",data.userInfo.account);
                                sessionStorage.setItem("isAgent",data.userInfo.isAgent);
                                sessionStorage.setItem('isCountry',data.isCountry);
                                this.$store.commit('common/updateIsCountry',data.isCountry);

                                this.$store.commit('common/updateMainTabs', []);
                                this.$store.commit('common/updateMainTabsActiveName', '');
                                this.$store.commit('common/updateMenuActiveName', '');

                                if(this.checked == true){
                                    this.checked = true;
                                    this.setCookie(this.dataForm.username, 30 , this.checked);
                                }else{
                                    this.checked = false;
                                    this.clearCookie();
                                };
                                this.$router.replace({name: 'home'})
                            } else {
                                this.$message.error(data.msg)
                            }
                        })

                    }
                })
            },
            setCookie(c_name,exdays,checked) {
                var exdate = new Date(); //获取时间
                exdate.setTime(exdate.getTime() + 24 * 60 * 60 * 1000 * exdays); //保存的天数
                //字符串拼接cookie
                window.document.cookie = "username" + "=" + c_name + ";path=/;expires=" + exdate.toGMTString();
                window.document.cookie = "checked" + "=" + checked + ";path=/;expires=" + exdate.toGMTString();
            },
            getCookie() {
                if (document.cookie.length > 0) {
                    var arr = document.cookie.split('; '); //这里显示的格式需要切割一下自己可输出看下
                    for (var i = 0; i < arr.length; i++) {
                        var arr2 = arr[i].split('='); //再次切割
                        if (arr2[0] == 'username') {
                            this.dataForm.username = arr2[1];
                        } else if (arr2[0] == 'checked') {
                            this.checked = arr2[1];
                        }
                    }
                }
                if(this.checked){
                    this.checked = true;
                }else{
                    this.checked = false;
                }
            },
            clearCookie() {
                this.setCookie("", "", -1); //修改2值都为空，天数为负1天就好了
            },
        },
        mounted() {
            this.getCookie();
        },
        created(){
        }
    }
</script>

<style lang="less">
    .site-wrapper.site-page--login {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        /*background-color: rgba(38, 50, 56, .6);*/
        overflow: hidden;
        &:before {
            position: fixed;
            top: 0;
            left: 0;
            z-index: -1;
            width: 100%;
            height: 100%;
            content: "";
            background:rgba(255,255,255,1);
            background-size: cover;
        }
        .site-content__wrapper {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            padding: 0;
            margin: 0;
            overflow-x: hidden;
            overflow-y: auto;
            background-color: transparent;
        }
        .site-content{
            padding:0;
            position:static;
        }
        .login-main {
            width: 675px;
            height:420px;
            box-shadow:0px 12px 24px 0px rgba(0,0,0,0.15);
            display: flex;
            position: absolute;
            top: 50%;
            left: 50%;
            margin-top: -210px;
            margin-left: -338px;

        }
        .login{
            background:#fff;
            padding:30px;
            width:280px;
            border-radius: 6px;
            text-align: center;
        }
        .login .form .el-input__inner{
            border:none!important;
            border-bottom:1px solid #DCDFE6!important;
            border-radius: 0;
        }
        .login-title {
            font-size:24px;
            font-family:PingFangSC-Medium,PingFang SC;
            font-weight:500;
            color:rgba(51,51,51,1);
            line-height:36px;
            display: block;
            margin:20px 0 30px;
        }
        .login-password{
            display: flex;
            justify-content:space-between;
            > a{
                font-size:14px;
                font-weight:400;
                color:rgba(51,51,51,1);
            }
        }
        .login-right{
            width:395px;
            height:420px;
            background:url("../../../assets/images/login-banner.png");
            text-align: center;
            color:#fff;
            > .logo{
                > span {
                    margin-top:36px;
                    display: inline-block;
                    font-size: 56px;
                }
            }
            > .name{
                width:204px;
                height:102px;
                font-size:34px;
                font-weight:600;
                line-height:51px;
                font-family:PingFangSC-Semibold,PingFang SC;
                margin:66px auto 112px;
            }
            > .icp{
                font-size:12px;
                font-family:PingFangSC-Regular,PingFang SC;
                font-weight:400;
                line-height:18px;
            }
        }
        .login-btn-submit {
            width: 100%;
            background:rgba(230,230,230,1);
            border-color:rgba(230,230,230,1);
            border-radius:4px;
            color:#999999;
        }
    }
</style>
