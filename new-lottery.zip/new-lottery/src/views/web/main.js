import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from '../../store'
import '../../icons'
import ElementUI from 'element-ui';
import '../../element-ui-theme'
import 'element-ui/lib/theme-chalk/index.css'
import '../../assets/less/index.less'
import {GetData,PostData} from '../../util/request'

import cloneDeep from 'lodash/cloneDeep'
import { isAuth} from "../../util"

import md5 from 'js-md5'

import VueDND from 'awe-dnd'
Vue.use(VueDND);

import Viewer from 'v-viewer'
import 'viewerjs/dist/viewer.css'
Vue.use(Viewer);

import '../../assets/font/iconfont.css'

// 保存整站vuex本地储存初始状态
window.SITE_CONFIG['storeState'] = cloneDeep(store.state);

Vue.config.productionTip = false;
import axios from 'axios';
axios.defaults.withCredentials = true;


Vue.use(ElementUI);
Vue.prototype.isAuth = isAuth;
Vue.prototype.$get = GetData;
Vue.prototype.$post = PostData;
Vue.prototype.$md5 = md5;

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app');
