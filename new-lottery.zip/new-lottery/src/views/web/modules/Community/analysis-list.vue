<template>
    <div>
        社区分析
    </div>
</template>

<script>
    export default {
        name: "analysis-list"
    }
</script>

<style scoped>

</style>