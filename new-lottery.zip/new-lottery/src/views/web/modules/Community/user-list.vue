<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="昵称">
                <el-input v-model="dataForm.title" placeholder="请输入昵称" clearable></el-input>
            </el-form-item>
            <el-form-item label="用户状态">
                <el-select placeholder="请选择" clearable v-model="dataForm.state">
                    <el-option value="0" label="正常"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="昵称">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="姓名">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="联系方式">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="好友">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="动态">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="评论">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="点赞">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="用户状态">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small">禁言</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                dataListSelections:[],
                dataList:[],
                dataForm:{

                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            handleSelectionChange(){

            },
            clear(){

            },
            getDataList(){

            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {

        }
    }
</script>

<style scoped>

</style>