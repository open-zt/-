<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="票圈">
                <el-input v-model="dataForm.title" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="姓名">
                <el-input v-model="dataForm.title" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="手机号">
                <el-input v-model="dataForm.title" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    :show-overflow-tooltip="true"
                    label="动态">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="票圈">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="发布用户">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="发布时间">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="评论">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="点赞">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                dataListSelections:[],
                dataList:[],
                dataForm:{

                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            handleSelectionChange(){

            },
            clear(){

            },
            getDataList(){

            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {

        }
    }
</script>

<style scoped>

</style>