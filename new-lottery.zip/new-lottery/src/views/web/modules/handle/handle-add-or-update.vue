<template>
    <div>
        <el-dialog
                :title="this.title"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                width="30%"
                :visible.sync="visible">

            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
                <el-form-item label="名称" prop="name">
                    <el-input v-model="dataForm.name" placeholder="请输入"></el-input>
                </el-form-item>
                <el-form-item label="排序" prop="sort">
                    <el-input v-model="dataForm.sort" placeholder="请输入"></el-input>
                </el-form-item>
                <el-form-item>
                    <div>设置排序后，将按照排序序号正序排列</div>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="dataFormSubmit()" :disabled="isDisable">确 定</el-button>
            </span>

        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "new-handle",
        data(){
            return{
                visible:false,
                isDisable:false,
                title:'',
                dataForm:{
                    id:'',
                    name:'',
                    sort:'',
                    type:''
                },
                dataRule:{
                    name:[{required: true,message: '名称必填', trigger: 'blur'}]
                },
            }
        },
        methods:{
            init(id,command){
                this.visible = true;
                this.isDisable=false;
                this.dataForm.id = id;
                this.dataForm.type = command;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                });

                if(this.dataForm.type == 'prod_unit'){
                    this.title ='单位管理';
                    if(this.dataForm.id){
                        this.$get(apiPage.api.dictInfo + this.dataForm.id).then((data) =>{
                            if(data.code == 0){
                                this.dataForm = data.dict;
                            }
                        })
                    }
                }else if(this.dataForm.type == 'faceValue'){
                    this.title = '面值管理';
                    if(this.dataForm.id){
                        this.$get(apiPage.api.productFaceValueInfo + this.dataForm.id).then((data) =>{
                            if(data.code == 0){
                                this.dataForm = data.info;
                                this.dataForm.type = 'faceValue'
                            }
                        })
                    }
                }
            },
            dataFormSubmit(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.isDisable = true;
                        if(this.dataForm.type == 'prod_unit'){
                            this.$post(apiPage.api.dictSave + `${!this.dataForm.id ?'save':'update'}`,this.dataForm).then((data) => {
                                if(data.code == 0){
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 1500,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList')
                                        }
                                    })
                                } else {
                                    this.isDisable = false;
                                    this.$message.error(data.msg);
                                }
                            })
                        }
                        if(this.dataForm.type == 'faceValue'){
                            this.$post(apiPage.api.productFaceValueSave + `${!this.dataForm.id ?'save':'update'}`,this.dataForm).then((data) => {
                                if(data.code == 0){
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 1500,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('faceValue')
                                        }
                                    })
                                } else {
                                    this.isDisable = false;
                                    this.$message.error(data.msg);
                                }
                            })
                        }

                    }
                })
            }

        },
        created() {

        }
    }
</script>

<style scoped>

</style>