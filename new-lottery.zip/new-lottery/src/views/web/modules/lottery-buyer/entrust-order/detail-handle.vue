<template>
    <div>
        <el-dialog
                class="dialog-con"
                title="委托服务订单详情"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" label-width="100px">
                <p>当前订单状态:<span class="black">{{dataForm.stateName}}</span></p>
                <el-row :gutter="20">
                    <el-col :span="8">
                        <el-form-item prop="orderNo" label="订单编号">
                            <span>{{dataForm.orderNo}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item prop="createTime" label="下单时间">
                            <span>{{dataForm.createTime}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="8">
                        <el-form-item prop="takeTicket" label="是否领票">
                            <span v-if="dataForm.takeTicket == 0">否</span>
                            <span v-if="dataForm.takeTicket == 1">是</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item prop="winningState" label="是否中奖">
                            <span v-if="dataForm.winningState == 0">否</span>
                            <span v-if="dataForm.winningState == 1">是</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item prop="redemption" label="是否兑奖">
                            <span v-if="dataForm.redemption == 0">否</span>
                            <span v-if="dataForm.redemption == 1">是</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p class="black">彩票信息</p>
                <el-row :gutter="20">
                    <el-col :span="8">
                        <el-form-item prop="cycle" label="期号">
                            <span>{{dataForm.cycle}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item prop="playType" label="玩法">
                            <span v-if="dataForm.playType == 1">双色球</span>
                            <span v-if="dataForm.playType == 2">福彩</span>
                            <span v-if="dataForm.playType == 3">七乐彩</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item prop="playMode" label="投注方式">
                            <span v-if="dataForm.playMode == 0">单式</span>
                            <span v-if="dataForm.playMode == 1">复式</span>
                            <span v-if="dataForm.playMode == 2">胆拖</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="8">
                        <el-form-item prop="itemNum" label="注数">
                            <span>{{dataForm.itemNum}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item prop="multiple" label="倍数">
                            <span>{{dataForm.multiple}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item prop="amount" label="金额">
                            <span>{{dataForm.amount}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="8">
                        <el-form-item label="票号">
                            <span>无</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col >
                        <el-form-item  label="选号">
                            <div v-for="item in orderItemList">
                                <span class="red" v-for="item in item.red.split(',')">{{item}}</span>
                                <span class="blue">{{item.blue}}</span>
                            </div>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p class="black">开奖信息</p>
                <el-row :gutter="20">
                    <el-col>
                        <el-form-item label="开奖号码">
                            <div v-if="this.dataForm.winingRed == null">无</div>
                            <div v-else>
                                <span class="red">{{this.openRed[0]}}</span>
                                <span class="red">{{this.openRed[1]}}</span>
                                <span class="red">{{this.openRed[2]}}</span>
                                <span class="red">{{this.openRed[3]}}</span>
                                <span class="red">{{this.openRed[4]}}</span>
                                <span class="red">{{this.openRed[5]}}</span>
                                <span class="blue">{{dataForm.winingBlue}}</span>
                            </div>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p class="black">中奖信息</p>
                <el-row>
                    <el-col>
                        <span v-if="this.orderWingingList.length == 0">无</span>
                        <el-table v-else :data="orderWingingList" border show-summary>
                            <el-table-column
                                prop="award"
                                header-align="center"
                                align="center"
                                label="中奖奖级">
                            </el-table-column>
                            <el-table-column
                                    prop="nodeNum"
                                    header-align="center"
                                    align="center"
                                    label="中奖注数（注）">
                            </el-table-column>
                            <el-table-column
                                    prop="amount"
                                    header-align="center"
                                    align="center"
                                    label="中奖金额（元）">
                            </el-table-column>
                        </el-table>
                    </el-col>
                </el-row>
                <p class="black">彩民信息</p>
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="彩民姓名">
                            <span>{{dataForm.userName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="昵称">
                            <span>{{dataForm.nickName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="手机号">
                            <span>{{dataForm.userMobile}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p class="black">投注站信息</p>
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="投注站昵称">
                            <span>{{dataForm.agentName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="投注站编号">
                            <span>{{dataForm.agentCode}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="投注站地址">
                            <span>{{dataForm.agentGeo}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="业主">
                            <span>{{dataForm.ownerName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="联系方式  ">
                            <span>{{dataForm.agentTel}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p class="black">订单追溯</p>
                <el-row>
                    <el-col>
                        <el-timeline>
                            <el-timeline-item
                                    v-for="(item, index) in orderLogList"
                                    :key="index"
                                    placement="top"
                                    :timestamp="item.createTime">
                                <span :style="{marginRight:'200px'}">{{item.stepName}}</span>
                                <span>{{item.operName}}:{{item.operator}}</span>
                                <p v-if="item.stepName == '取消'">原因：{{item.cancelReason}}</p>
                            </el-timeline-item>
                        </el-timeline>
                    </el-col>
                </el-row>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'

    export default {
        data(){
            return{
                visible:false,
                dataForm:{
                    id:'',
                },
                orderLogList:[],
                orderItemList:[],
                orderWingingList:[],
                openRed:[],
                dataRule:{
                },
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.dataForm.id = id;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                });

                if(this.dataForm.id){
                    this.$get(apiPage.api.orderInfo + this.dataForm.id).then((data) => {
                        if(data.code == 0){
                            this.dataForm = data.info;
                            if(data.info.winingRed !=null){
                                this.openRed = data.info.winingRed.split(',');
                            }
                            this.orderLogList = data.info.orderLogList;
                            this.orderItemList = data.info.orderItemList;
                            this.orderWingingList = data.info.orderWingingList;
                        }
                    })
                }
            },
        },
        created() {

        }
    }
</script>

<style scoped>
    .black{
        color:#000;
    }
    .red{
        background:red;
        width:30px;
        height:30px;
        color:#fff;
        border-radius:50%;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        margin-right:6px;
    }
    .blue{
        background:blue;
        width:30px;
        height:30px;
        color:#fff;
        border-radius:50%;
        display: inline-flex;
        justify-content: center;
        align-items: center;
    }
</style>