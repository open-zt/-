<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="下单时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        range-separator="至"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="订单编号">
                <el-input v-model="dataForm.orderNo" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="订单状态">
                <el-select v-model="dataForm.state" clearable>
                    <el-option value="待付款" label="待付款"></el-option>
                    <el-option value="已付款" label="已付款"></el-option>
                    <el-option value="待出票" label="待出票"></el-option>
                    <el-option value="待开奖" label="待开奖"></el-option>
                    <el-option value="已取消" label="已取消"></el-option>
                    <el-option value="已中奖" label="已中奖"></el-option>
                    <el-option value="未中奖" label="未中奖"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="彩民">
                <el-input v-model="dataForm.lotteryParam" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="投注站">
                <el-input v-model="dataForm.agentName" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    label="下单时间">
            </el-table-column>
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    label="订单编号">
            </el-table-column>
            <el-table-column
                    prop="playType"
                    header-align="center"
                    align="center"
                    label="玩法">
                <template slot-scope="scope">
                    <p v-if="scope.row.playType == 1">双色球</p>
                    <p v-if="scope.row.playType == 2">福彩</p>
                    <p v-if="scope.row.playType == 3">七乐彩</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="playMode"
                    header-align="center"
                    align="center"
                    label="投注方式">
                <template slot-scope="scope">
                    <p v-if="scope.row.playMode == 0">单式</p>
                    <p v-if="scope.row.playMode == 1">复式</p>
                    <p v-if="scope.row.playMode == 2">胆拖</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="itemNum"
                    header-align="center"
                    align="center"
                    label="注数">
            </el-table-column>
            <el-table-column
                    prop="amount"
                    header-align="center"
                    align="center"
                    label="订单金额">
            </el-table-column>
            <el-table-column
                    prop="stateName"
                    header-align="center"
                    align="center"
                    label="订单状态">
            </el-table-column>
            <el-table-column
                    prop="nickName"
                    header-align="center"
                    align="center"
                    label="彩民">
                <template slot-scope="scope">
                    <p>{{scope.row.nickName}}</p>
                    <p>{{scope.row.userMobile}}</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="agentName"
                    header-align="center"
                    align="center"
                    label="投注站">
            </el-table-column>
            <el-table-column
                    prop="takeTicket"
                    header-align="center"
                    align="center"
                    label="是否领票">
                <template slot-scope="scope">
                    <p v-if="scope.row.takeTicket == 0">否</p>
                    <p v-if="scope.row.takeTicket == 1">是</p>
                    <p v-if="scope.row.takeTicket == null">一</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="winningState"
                    header-align="center"
                    align="center"
                    label="是否中奖">
                <template slot-scope="scope">
                    <p v-if="scope.row.winningState == 0">否</p>
                    <p v-if="scope.row.winningState == 1">是</p>
                    <p v-if="scope.row.winningState == null">一</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="redemption"
                    header-align="center"
                    align="center"
                    label="是否兑奖">
                <template slot-scope="scope">
                    <p v-if="scope.row.redemption == 0">否</p>
                    <p v-if="scope.row.redemption == 1">是</p>
                    <p v-if="scope.row.redemption == null">一</p>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="detailsHandle(scope.row.id)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
        <details-handle ref="detailsHandle"  @refreshDataList="getDataList"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import DetailsHandle from './detail-handle'
    export default {
        name: "lottery-list",
        data(){
            return{
                dataList:[],
                dataForm:{
                    startTime:'',
                    endTime:'',
                    orderNo:'',
                    state:'',
                    lotteryParam:'',
                    agentName:''
                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
                dataListSelections:[]
            }
        },
        components:{
            DetailsHandle
        },
        methods:{
            clear(){
                this.dataForm = {
                    startTime:'',
                    endTime:'',
                    orderNo:'',
                    state:'',
                    lotteryParam:'',
                    agentName:''
                };
                this.getDataList();
            },
            detailsHandle(id){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.init(id);
                })
            },
            getDataList(){
                let request = {
                    'startTime':this.dataForm.startTime[0] ? this.dataForm.startTime[0] : '',
                    'endTime':this.dataForm.startTime[1] ? this.dataForm.startTime[1] : '',
                    'orderNo':this.dataForm.orderNo,
                    'state':this.dataForm.state,
                    'lotteryParam':this.dataForm.lotteryParam,
                    'agentName':this.dataForm.agentName,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.orderList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>