<template>
    <div>
        <el-form :model="dataForm">
            <el-form-item label="投诉分类：">
                <el-radio v-model="dataForm.orderType" label="0" @change="getDataList">全部</el-radio>
                <el-radio v-model="dataForm.orderType" label="1" @change="getDataList">来自订单</el-radio>
                <el-radio v-model="dataForm.orderType" label="2" @change="getDataList">直接投诉</el-radio>
            </el-form-item>
        </el-form>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="维修人员">
                <el-input v-model="dataForm.managerParam" placeholder="请输入账号或名称" clearable></el-input>
            </el-form-item>
            <el-form-item label="投注站编号">
                <el-input v-model="dataForm.agentParam" placeholder="请输入投注站编号" clearable></el-input>
            </el-form-item>
            <el-form-item label="投诉时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    header-align="center"
                    align="center"
                    label="供应商">
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="维修人员">
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="投注站">
                <template slot-scope="scope">
                    <p>{{scope.row.agentCode}}</p>
                    <p>{{scope.row.agentName}}</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    label="订单编号">
            </el-table-column>
            <el-table-column
                    prop="content"
                    header-align="center"
                    align="center"
                    width="300px"
                    :show-overflow-tooltip="true"
                    label="投诉内容">
            </el-table-column>
            <el-table-column
                    prop="imgUrl"
                    header-align="center"
                    align="center"
                    label="图片">
                <template slot-scope="scope">
                    <span v-if="scope.row.imgUrl == ''">无</span>
                    <div v-else>
                        <span>查看</span>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    width="150"
                    label="投诉时间">
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        data(){
            return{
                dataList:[],
                dataForm:{

                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            getDataList(){

            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
        }
    }
</script>

<style scoped>

</style>