<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary">新增</el-button>
            <el-button type="primary">导入</el-button>
            <el-button type="primary" :disabled="dataListSelections.length <= 0">删除</el-button>
        </div>
        <el-table
                border
                style="width:100%"
                :data="dataList"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="设备供应商名称">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="设备供应商地址">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="地区维修负责人">
            </el-table-column>
            <el-table-column
                    prop="title"
                    header-align="center"
                    align="center"
                    label="合作状态">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="addOrUpdate(scope.row.id)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                dataListSelections:[],
                dataList:[],
                dataForm:{

                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            handleSelectionChange(){

            },
            clear(){

            },
            addOrUpdate(){

            },
            getDataList(){

            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {

        }
    }
</script>

<style scoped>

</style>