<template>
    <div>
        <el-dialog
                class="dialog-con"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                title="耗材订单详情"
                :visible.sync="visible" >

            <el-form :model="infoForm"  label-width="100px">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="当前订单状态:" size="mini">
                            <span class="black">已完成</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="订单编号:" size="mini">
                            <span>{{infoForm.orderNo}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="下单时间:" size="mini">
                            <span>{{infoForm.createTime}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-table :data="dataList" border  style="width: 100%" >
                            <el-table-column
                                    prop="prodName"
                                    header-align="center"
                                    align="center"
                                    label="耗材信息">
                                <template slot-scope="scope">
                                    <p>{{scope.row.prodName}}</p>
                                    <p class="black" v-if="scope.row.faceValue != null">({{scope.row.faceValue}})</p>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    prop="price"
                                    header-align="center"
                                    align="center"
                                    label="单价">
                                <template slot-scope="scope">
                                    <p>￥{{scope.row.price}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    prop="num"
                                    header-align="center"
                                    align="center"
                                    label="数量">
                                <template slot-scope="scope">
                                    <p class="black">{{scope.row.num}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    prop="amount"
                                    header-align="center"
                                    align="center"
                                    label="金额">
                                <template slot-scope="scope">
                                    <p>￥{{scope.row.amount}}</p>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div class="amount-content">
                            <p class="amount-to">合计：</p>
                            <div>
                                <p>合计种类及数量：</p>
                                <p>共 {{this.dataList.length}} 种 {{num}} 个</p>
                            </div>
                            <div>
                                <p>合计金额：</p>
                                <p>￥{{infoForm.amount}}</p>
                            </div>
                            <div>
                                <p>实付金额:</p>
                                <p>￥{{infoForm.payAmount}}</p>
                            </div>
                        </div>
                    </el-col>
                </el-row>
                <el-row>
                    <p class="black">投注站信息</p>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="投注站编号:" size="mini">
                            <span>{{infoForm.agentCode}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="投注站地址:" size="mini">
                            <span>{{infoForm.address}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="业主:" size="mini">
                            <span>{{infoForm.ownerName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="联系电话:" size="mini">
                            <span>{{infoForm.tel}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <p class="black">管理员信息</p>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="管理员:" size="mini">
                            <span>{{infoForm.managetName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="手机号:" size="mini">
                            <span>{{infoForm.managetTel}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <p class="black">订单追溯</p>
                </el-row>
                <el-row>
                    <el-col>
                        <el-timeline>
                            <el-timeline-item
                                    v-for="(activity, index) in mallOrderLogList"
                                    :key="index"
                                    placement="top"
                                    :timestamp="activity.createTime">
                                <p>{{activity.stepName}}</p>
                                <p>{{activity.operName}}:<span>{{activity.operator}}</span></p>
                            </el-timeline-item>
                        </el-timeline>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">关闭</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        data(){
            return{
                visible:false,
                infoForm:{},
                dataList:[],
                mallOrderLogList:[],
                num:0,
                spanArr:[],
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.infoForm = {};
                this.$get(apiPage.api.mallOrderInfo + id).then((data) => {
                    if(data.code == 0){
                        if(data.orderInfo.mallOrderInfo){
                            this.infoForm = data.orderInfo.mallOrderInfo;
                        }
                        this.dataList = data.orderInfo.mallOrderItemList;
                        this.num = 0;
                        this.dataList.forEach((i) => {
                            this.num += parseInt(i.num);
                        });
                        this.mallOrderLogList = data.orderInfo.mallOrderLogList;
                    }
                })
            },
        },
        mounted(){
        },
        created() {

        }
    }
</script>

<style scoped>
    .black{
        color:#000;
    }
    .amount-content{
        float:right;font-size: 16px;text-align: right;
        border: 1px solid #EBEEF5;
        border-top:none;
        width:100%;
        overflow:hidden;
    }
    .amount-to {
        float:left;
        margin:70px;
    }
    .amount-content div{
        display: flex;
        width: 500px;
        float:right;
    }
    .amount-content div p:first-child{
        width:250px;
    }
    .amount-content div p:last-child{
        width:200px;
    }
</style>