<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="下单时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        range-separator="至"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="订单编号">
                <el-input v-model="dataForm.orderNo" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="订单状态">
                <el-select v-model="dataForm.state" clearable>
                    <el-option value="待付款" label="待付款"></el-option>
                    <el-option value="已取消" label="已取消"></el-option>
                    <el-option value="已付款" label="已付款"></el-option>
                    <el-option value="已出库" label="已出库"></el-option>
                    <el-option value="待收货" label="待收货"></el-option>
                    <el-option value="已完成" label="已完成"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    label="下单时间">
            </el-table-column>
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    label="订单编号">
            </el-table-column>
            <el-table-column
                    prop="state"
                    header-align="center"
                    align="center"
                    label="订单状态">
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    width="400px"
                    label="耗材信息">
                <template slot-scope="scope">
                    <div v-for="item in scope.row.itemList" style="text-align: left;" >
                        <p :style="{color:'#000',fontWeight:'500'}">{{item.prodName}}<span v-if="item.faceValue != null">({{item.faceValue}})</span></p>
                        <span :style="{marginRight:'10px'}">单价：¥ {{item.price}}</span>
                        <span :style="{marginRight:'10px'}">数量：{{item.num}}</span>
                        <span :style="{marginRight:'10px'}">金额：¥ {{item.amount}}</span>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                    prop="num"
                    header-align="center"
                    align="center"
                    label="合计种类及数量">
                <template slot-scope="scope">
                    <p>共{{scope.row.num}}种</p>
                    <div>{{scope.row.itemList|getSum}}本</div>
                </template>
            </el-table-column>
            <el-table-column
                    prop="amount"
                    header-align="center"
                    align="center"
                    label="实付金额">
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="终端">
                <template slot-scope="scope">
                    <p>联系人：{{scope.row.channelUserName}}</p>
                    <p>联系方式：{{scope.row.mobile}}</p>
                    <p>投注站昵称：{{scope.row.agentName}}</p>
                </template>
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="专管员">
                <template slot-scope="scope">
                    <p>{{scope.row.managetName}}</p>
                    <p>{{scope.row.managetTel}}</p>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="detailsHandle(scope.row.id)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <ConsumeDetails ref="consumeDetails"></ConsumeDetails>

    </div>
</template>

<script>
    import apiPage from '@/api'
    import ConsumeDetails from './consume-details'
    export default {
        data(){
            return{
                dataList:[],
                dataForm:{
                    type:'2',
                    startTime:'',
                    endTime:'',
                    orderNo:'',
                    state:''
                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        components:{
            ConsumeDetails
        },
        filters:{
            getSum(f){
                var arr=0;
                for(var i=0;i<f.length;i++){
                    arr=arr+f[i].num;
                }
                return arr;
            },
        },
        methods:{
            clear(){
                this.dataForm = {
                    type:'2',
                    startTime:'',
                    endTime:'',
                    orderNo:'',
                    state:''
                };
                this.getDataList();
            },
            detailsHandle(id){
                this.$nextTick(() => {
                    this.$refs.consumeDetails.init(id);
                })
            },
            getDataList(){
                let request = {
                    'type':this.dataForm.type,
                    'startTime':this.dataForm.startTime[0],
                    'endTime':this.dataForm.startTime[1],
                    'orderNo':this.dataForm.orderNo,
                    'state':this.dataForm.state,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };

                this.$get(apiPage.api.mallOrderList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style>
    .el-date-editor .el-range-separator{
        padding:0!important;
    }
</style>