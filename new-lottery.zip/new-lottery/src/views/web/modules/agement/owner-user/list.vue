<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
            <el-button type="primary" @click="exportExcel()" plain>导入</el-button>
            <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="业主姓名">
                <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="身份证号">
                <el-input v-model="dataForm.idCard" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="业主状态">
                <el-select v-model="dataForm.status" clearable>
                    <el-option value="0" label="无效"></el-option>
                    <el-option value="1" label="有效"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="业主姓名">
            </el-table-column>
            <el-table-column
                    prop="idCard"
                    header-align="center"
                    align="center"
                    label="身份证号">
            </el-table-column>
            <el-table-column
                    prop="sex"
                    header-align="center"
                    align="center"
                    label="性别">
                <template slot-scope="scope">
                    <p v-if="scope.row.sex == 1">男</p>
                    <p v-if="scope.row.sex == 2">女</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="address"
                    header-align="center"
                    align="center"
                    label="通讯地址">
            </el-table-column>
            <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="业主状态">
                <template slot-scope="scope">
                    <div v-if="scope.row.status == 0">无效</div>
                    <div v-if="scope.row.status == 1">有效</div>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.userId)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <add-or-update-handle ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update-handle>
        <export-handle ref="exportHandle" @refreshDataList="getDataList"></export-handle>
    </div>
</template>

<script>
    import addOrUpdateHandle from './add-or-update'
    import exportHandle from './export-excel'
    import apiPage from '@/api'
    export default {
        name: "lottery-list",
        data(){
            return{
                dataList:[],
                dataForm:{
                    name:'',
                    idCard:'',
                    status:''
                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
                dataListSelections:[]
            }
        },
        components:{
            addOrUpdateHandle,exportHandle
        },
        methods:{
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            exportExcel(){
                this.$nextTick(() => {
                    this.$refs.exportHandle.init();
                })
            },
            addOrUpdateHandle(userId){
                this.$nextTick(() => {
                    this.$refs.addOrUpdate.init(userId);
                })
            },
            getDataList(){
                let request = {
                    'name':this.dataForm.name,
                    'idCard':this.dataForm.idCard,
                    'status':this.dataForm.status,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.ownerUserList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            deleteHandle(id) {
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.userId
                });
                let request = {
                    'ids': ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.ownerUserBatchRemove, request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        } else {
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            }
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>