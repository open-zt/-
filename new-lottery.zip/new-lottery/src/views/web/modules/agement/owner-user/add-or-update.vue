<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.userId?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" label-width="100px"  @keyup.enter.native="submitFormData()" >
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="name" label="业主姓名">
                            <el-input v-model="dataForm.name" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="idCard" label="身份证号">
                            <el-input v-model="dataForm.idCard" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="sex" label="性别">
                            <el-select v-model="dataForm.sex" placeholder="请选择">
                                <el-option value="1" label="男"></el-option>
                                <el-option value="2" label="女"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="nation" label="民族">
                            <el-input v-model="dataForm.nation" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="politicsStatus" label="政治面貌">
                            <el-select v-model="dataForm.politicsStatus" placeholder="请选择">
                                <el-option value="0" label="共产党员"></el-option>
                                <el-option value="1" label="民主党派"></el-option>
                                <el-option value="2" label="团员"></el-option>
                                <el-option value="3" label="群众"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="birthDate" label="出生日期">
                            <el-date-picker
                                    style="width:100%"
                                    v-model="dataForm.birthDate"
                                    type="date"
                                    value-format="yyyy-MM-dd"
                                    placeholder="请选择">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="nativePlace" label="籍贯">
                            <el-input v-model="dataForm.nativePlace" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="education" label="文化程度">
                            <el-select v-model="dataForm.education" placeholder="请选择">
                                <el-option value="0" label="研究生"></el-option>
                                <el-option value="1" label="本科"></el-option>
                                <el-option value="2" label="专科"></el-option>
                                <el-option value="3" label="中专"></el-option>
                                <el-option value="4" label="高中"></el-option>
                                <el-option value="5" label="初中"></el-option>
                                <el-option value="6" label="初中以下"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="occupation" label="现从事职业">
                            <el-input v-model="dataForm.occupation" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="mobile" label="手机号">
                            <el-input v-model="dataForm.mobile" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="geo" label="地区">
                            <el-cascader
                                    placeholder="请选择省/市/区/街道"
                                    :options="geoList"
                                    :clearable="true"
                                    filterable
                                    style="width:100%"
                                    v-model="dataForm.geoList"
                                    @change="handleCurrent"
                            ></el-cascader>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="liveAddress" label="详细地址">
                            <el-input v-model="dataForm.liveAddress" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item prop="status" label="业主状态">
                            <el-select v-model="dataForm.status" placeholder="请选择"  style="width:100%">
                                <el-option value="0" label="无效"></el-option>
                                <el-option value="1" label="有效"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()" :disabled="isDisable">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import {mobileRule} from "@/util/validate";

    export default {
        data(){
            const idCardRule = (rule,value,callback) =>{
                var reg = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
                let request = {
                    id:this.dataForm.userId,
                    verifyParam:this.dataForm.idCard
                };
                if (value === '') {
                    callback(new Error('身份证号必填'));
                } else if(!reg.test(value)) {
                    callback(new Error('请输入合法的身份证号'));
                }else if(request){
                    this.$post(apiPage.api.verifyOwnerUserIdCard,request).then((data) =>{
                        if(data.code == 500){
                            callback(data.msg);
                        }else{
                            callback();
                        }
                    }).catch(() => {
                        callback(new Error('服务异常'));
                    })
                }else{
                    callback();
                }
            };
            return{
                visible:false,
                isDisable:false,
                geoList:[],
                dataForm:{
                    userId:'',
                    name:'',
                    idCard:'',
                    sex:'',
                    nation:'',
                    birthDate:'',
                    nativePlace:'',
                    occupation:'',
                    politicsStatus:'',
                    education:'',
                    geo:'',
                    geoList:[],
                    liveAddress:'',
                    mobile:'',
                    status:'1',
                },
                dataRule:{
                    name:[{required: true, message: '业主姓名必填', trigger: 'blur'}],
                    idCard:[{required: true,validator:idCardRule, trigger: 'blur'}],
                    sex:[{required: true, message: '性别必填', trigger: 'blur'}],
                    nation:[{required: true, message: '民族必填', trigger: 'blur'}],
                    birthDate:[{required: true, message: '出生日期必填', trigger: 'blur'}],
                    nativePlace:[{required: true, message: '籍贯必填', trigger: 'blur'}],
                    occupation:[{required: true, message: '现从事职业必填', trigger: 'blur'}],
                    politicsStatus:[{required: true, message: '政治面貌必填', trigger: 'blur'}],
                    education:[{required: true, message: '文化程度必填', trigger: 'blur'}],
                    mobile:[{required: true,validator:mobileRule,trigger: 'blur'}],
                    liveAddress:[{required: true, message: '详细地址必填', trigger: 'blur'}],
                    status:[{required: true, message: '业主状态必填', trigger: 'blur'}],
                    geo:[{required: true, message: '通讯地址必填', trigger: 'blur'}],
                },
            }
        },
        methods:{
            handleCurrent(value) {
                if (value != null && value.length > 0) {
                    this.dataForm.geo = value[value.length - 1];
                }
            },
            init(userId){
                this.visible = true;
                this.isDisable=false;
                this.dataForm.userId = userId;

                this.$nextTick(() => {
                   this.$refs['dataForm'].resetFields();
                   this.dataForm.geoList = [];
                });

                if(this.dataForm.userId){
                    this.$get(apiPage.api.ownerUserInfo + this.dataForm.userId).then((data) => {
                        if(data.code == 0){
                            this.dataForm = data.user;
                            this.dataForm.sex = data.user.sex.toString();
                            this.dataForm.politicsStatus = data.user.sex.toString();
                            this.dataForm.education = data.user.education.toString();
                            this.dataForm.status = data.user.status.toString();
                        }
                    })
                }


                //地区下拉
                this.$get(apiPage.api.agentGeoList).then((data) => {
                    if(data.code == 0){
                        this.geoList = data.list;
                    }
                });
            },
            submitFormData(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.isDisable = true;
                        this.$post(apiPage.api.ownerUserSave + `${!this.dataForm.userId ? 'save' : 'update'}`,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 800,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                });
                                this.isDisable = true;
                            } else {
                                this.isDisable = false;
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            }
        },
        created() {

        }
    }
</script>

<style scoped>

</style>