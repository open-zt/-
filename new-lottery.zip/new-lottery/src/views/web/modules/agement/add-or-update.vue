<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.id?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :before-close="handleClose"
                width="60%"
                :visible.sync="visible">
            <el-button type="primary" @click="closeAgent()" v-if="this.dataForm.id && this.status != 2" class="close-agent">关闭投注站</el-button>
            <el-steps :active="active" finish-status="success">
                <el-step title="投注站信息"></el-step>
                <el-step title="业主信息"></el-step>
                <el-step title="投注机信息"></el-step>
                <el-step title="管理设置"></el-step>
            </el-steps>

            <el-card shadow="always" v-show="active == 0">
                <el-form :model="dataForm" :rules="dataRule" ref="dataForm" label-width="145px">
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form-item prop="code" label="投注站编号">
                                <el-input v-model="dataForm.code" placeholder="请输入"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="agentArea" label="投注站面积(平方米)">
                                <el-input v-model="dataForm.agentArea" placeholder="请输入"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form-item prop="operationMode" label="经营方式">
                                <el-select v-model="dataForm.operationMode" placeholder="请选择"  style="width:100%">
                                    <el-option value="1" label="专营"></el-option>
                                    <el-option value="2" label="兼营"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="telephone" label="固定电话">
                                <el-input v-model="dataForm.telephone" placeholder="请输入"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form-item prop="geo" label="地区">
                                <el-cascader
                                        placeholder="请选择省/市/区/街道"
                                        :options="geoList"
                                        :clearable="true"
                                        filterable
                                        style="width:100%"
                                        v-model="dataForm.geoList"
                                        @change="handleCurrent"
                                ></el-cascader>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="address" label="详细地址">
                                <el-input v-model="dataForm.address" placeholder="请输入"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="12">
                          <el-form-item prop="openTime" label="营业开始时间">
                              <el-time-picker
                                      is-range
                                      style="width:100%"
                                      v-model="dataForm.openTime"
                                      format="HH:mm"
                                      value-format="HH:mm"
                                      range-separator="至"
                                      start-placeholder="开始时间"
                                      end-placeholder="结束时间"
                                      placeholder="选择时间范围">
                              </el-time-picker>
                          </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="approveDate" label="站点批准日期">
                                <el-date-picker
                                        style="width:100%"
                                        v-model="dataForm.approveDate"
                                        type="date"
                                        value-format="yyyy-MM-dd"
                                        placeholder="请选择">
                                </el-date-picker>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <el-form-item prop="openDate" label="开业日期">
                                <el-date-picker
                                        style="width:100%"
                                        v-model="dataForm.openDate"
                                        type="date"
                                        value-format="yyyy-MM-dd"
                                        placeholder="请选择">
                                </el-date-picker>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </el-card>
            <el-card shadow="always" v-show="active == 1">
                <el-form :model="infoForm" :rules="infoRule" ref="infoForm" label-width="140px">
                    <el-row>
                        <el-col>
                            <el-form-item prop="ownerName" label="业主姓名">
                                <el-select v-model="infoForm.ownerName" placeholder="请选择" filterable >
                                    <el-option v-for="item in ownerUserList" :value="item.userId" :label="item.name" :key="item.userId"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </el-card>
            <el-card shadow="always" v-show="active == 2">
                <el-form :model="equipmentsForm" :rules="equipmentsRule" ref="equipmentsForm" label-width="140px">
                    <p>投注机信息</p>
    <!--                <el-button type="primary"  style="position:relative;left:120px;top:0;margin-left:-120px;margin-bottom: 10px;">添加投注机</el-button>-->
    <!--                <el-select v-model="dataForm.equipmentCode" @change="handleChange" filterable placeholder="添加投注机" :style="{marginBottom:'10px'}">-->
    <!--                    <el-option  v-for="item in equipmentList" :value="item.id" :key="item.id" :label="item.equipmentCode" :disabled="item.disabled"></el-option>-->
    <!--                </el-select>-->
                    <el-dropdown>
                        <el-button type="primary" :style="{marginBottom:'10px'}">
                            添加投注机<i class="el-icon-arrow-down el-icon--right"></i>
                        </el-button>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item v-for="item in equipmentList" :key="item.id" :disabled="item.disabled" @click.native="handleChange(item.id)">{{item.equipmentCode}}</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                    <el-row>
                        <el-col>
                            <el-form-item class="ml0">
                                <el-table border :data="equipmentsForm.equipments">
                                    <el-table-column label="编号" align="center" prop="equipmentCode" header-align="center"></el-table-column>
                                    <el-table-column label="型号" align="center" prop="modelNumber" header-align="center"></el-table-column>
                                    <el-table-column label="供应商" align="center" prop="supplierName" header-align="center"></el-table-column>
                                    <el-table-column label="中标日期" align="center" prop="biddingDate" header-align="center"></el-table-column>
                                    <el-table-column label="采购日期" align="center" prop="purchaseDate" header-align="center"></el-table-column>
                                    <el-table-column label="上线日期" align="center" prop="onlineDate" header-align="center" width="250">
                                        <template slot-scope="scope">
                                            <el-form-item :prop="`equipments.${scope.$index}.onlineDate`"  :rules='equipmentsRule.equipments.onlineDate'>
                                                <el-date-picker
                                                        v-model="scope.row.onlineDate"
                                                        type="date"
                                                        value-format="yyyy-MM-dd"
                                                        placeholder="请选择">
                                                </el-date-picker>
                                            </el-form-item>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="操作" align="center" prop="purchaseDate" header-align="center">
                                        <template slot-scope="scope">
                                            <el-button type="text" @click="del(scope.row,scope.$index)">删除</el-button>
                                        </template>
                                    </el-table-column>
                                </el-table>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col>
                            <el-form-item prop="serviceMan" label="投注机维修归属">
                                <el-select v-model="equipmentsForm.serviceMan" placeholder="请选择" filterable >
                                    <el-option value="专管员" label="专管员"></el-option>
                                    <el-option value="供应商" label="供应商"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col>
                            <p>说明：完善投注机信息，便于投注站在终端进行设备报修，同时中心可以精准掌握投注站的营业表现</p>
                        </el-col>
                    </el-row>
                </el-form>
            </el-card>
            <el-card shadow="always" v-show="active == 3">
                <el-form :model="mangerForm" :rules="mangerRule" ref="mangerForm" label-width="140px">
                    <el-row>
                        <el-col>
                            <el-form-item prop="managerName" label="专管员" >
                                <el-select v-model="mangerForm.managerName" placeholder="请选择" filterable>
                                    <el-option v-for="item in managerList" :value="item.userId" :label="item.name" :key="item.userId"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </el-card>

            <el-button style="margin-top: 12px;" @click="prev" v-if="active == 1 || active == 2 || active == 3">上一步</el-button>
            <el-button style="margin-top: 12px;" @click="next" v-if="active == 0 || active == 1 || active == 2">下一步</el-button>
            <el-button style="margin-top: 12px;" @click="submitFormData" v-if="active == 3">保存</el-button>
            <el-button style="margin-top: 12px;" @click="handleClose()" :disabled="isDisable">关闭</el-button>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "add-or-update",
        data(){
            const codeRule = (rule,value,callback) => {
                let request = {
                    id:this.dataForm.id,
                    verifyParam:this.dataForm.code
                };
                this.$post(apiPage.api.verifyAgentCode,request).then((data) =>{
                    if(data.code == 500){
                        callback(data.msg);
                    }else{
                        callback();
                    }
                }).catch(() => {
                    callback(new Error('服务异常'));
                })
            };
          return{
              visible:false,
              isDisable:false,
              active:0,
              status:'',
              ownerUserList:[],//业主下拉
              geoList:[],     //省市区下拉
              managerList:[], //专管员下拉
              equipmentList:[],//设备编号下拉
              dataForm:{
                  id:'',
                  code:'',
                  agentArea:'',
                  operationMode:'',
                  geo:'',
                  geoList:[],
                  address:'',
                  telephone:'',
                  approveDate:'',
                  openDate:'',
                  openTime:'',
                  closeTime:'',
              },
              dataRule:{
                  code:[{required: true, message: '投注站编号必填', trigger: 'blur'},
                      {validator:codeRule, trigger: 'blur'}],
                  agentArea:[{required: true, message: '投注站面积必填', trigger: 'blur'}],
                  geo:[{required: true, message: '地区必填', trigger: 'blur'}],
                  address:[{required: true, message: '详细地址必填', trigger: 'blur'}],
                  approveDate:[{required: true, message: '站点批准日期必填', trigger: 'blur'}],
              },
              infoForm:{
                  ownerName:'',
              },
              infoRule:{
                  ownerName:[{required: true, message: '业主姓名必填', trigger: 'blur'}],
              },
              equipmentsForm:{
                  equipments:[],
                  serviceMan:'',
              },
              equipmentsRule:{
                  equipments:{
                      equipmentCode: [{required: true, message: '编号必填',trigger: 'blur'}],
                      onlineDate: [{required: true, message: '日期必填',trigger: 'blur'}],
                  },
                  serviceMan:[{required: true, message: '投注机维修归属必填', trigger: 'blur'}],
              },
              mangerForm:{
                  managerName:'',
              },
              mangerRule:{
                  managerName:[{required: true, message: '专管员必填', trigger: 'blur'}],
              }
          }
        },
        methods:{
            handleClose(){
                this.dataForm.openTime = '';
                this.active = 0;
                this.visible = false;
            },
            handleChange(id){
                    var r = this.equipmentList.findIndex((value)=>value.id==id);
                    this.equipmentList[r].disabled=true;

                    this.$get(apiPage.api.equipmentInfo + id).then((data) => {
                    if(data.code == 0){
                        this.equipmentsForm.equipments.push(data.equipmentInfo);
                    }
                });
            },
            del(data,index){
                let r = this.equipmentList.findIndex((value)=>value.equipmentCode==data.equipmentCode);
                this.equipmentList[r].disabled=false;
                this.$confirm(`您确定要删除选中的内容吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.equipmentsForm.equipments.splice(index,1);
                });
            },
            handleCurrent(value) {
                if (value != null && value.length > 0) {
                    this.dataForm.geo = value[value.length - 1];
                }
            },
            prev(){
                --this.active;
                if (this.active < 0) this.active = 0;
            },
            next(){
                if(this.active === 0){
                    this.$refs['dataForm'].validate((valid) => {
                        if (valid) {
                            this.active = 1;
                        }
                    })
                }else if(this.active === 1){
                    this.$refs['infoForm'].validate((valid) =>{
                        if(valid){
                            this.active = 2;
                        }
                    })
                }else if(this.active === 2){
                    this.$refs['equipmentsForm'].validate((valid) =>{
                        if(valid){
                            this.active =3;
                        }
                    })
                }else if(this.active === 3){
                    this.$refs['mangerForm'].validate((valid) =>{
                        if(valid){
                            this.active =3;
                        }
                    })
                }
            },
            init(id,status){
                this.visible = true;
                this.isDisable=false;
                this.dataForm.id = id;
                this.status = status;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.dataForm.geoList = [];
                    this.$refs['infoForm'].resetFields();
                    this.$refs['equipmentsForm'].resetFields();
                    this.$refs['mangerForm'].resetFields();
                });

                if(this.dataForm.id){
                    this.$get(apiPage.api.agentInfo + this.dataForm.id).then((data) => {
                        if(data.code == 0){
                            this.dataForm = data.agent;
                            this.dataForm.geoList = data.agent.geoList;
                            if(this.dataForm.operationMode){
                                this.dataForm.operationMode = this.dataForm.operationMode.toString();
                            }

                            if(data.agent.timeList != []){
                                this.dataForm.openTime = data.agent.timeList;
                            }
                            this.infoForm.ownerName = data.agent.ownerId;
                            this.equipmentsForm.equipments = data.agent.agentEquipmentList;
                            this.equipmentsForm.serviceMan = data.agent.serviceMan;
                            this.mangerForm.managerName = data.agent.managerId;
                        }
                    })
                }

                //业主下拉
                this.$get(apiPage.api.agentOwnerUserList).then((data) => {
                    if(data.code == 0){
                        this.ownerUserList = data.ownerUserList;
                    }
                });

                //专管员下拉
                this.$get(apiPage.api.agentManagerList).then((data) => {
                    if(data.code == 0){
                        this.managerList = data.managerList;
                    }
                });
                //地区下拉
                this.$get(apiPage.api.agentGeoList).then((data) => {
                    if(data.code == 0){
                        this.geoList = data.list;
                    }
                });

                //设备编号下拉
                this.$get(apiPage.api.equipmentList).then((data) => {
                    if(data.code == 0){
                        this.equipmentList = data.equipmentList;

                    }
                });
            },
            submitFormData(){
                let request = {
                    id:this.dataForm.id,
                    code:this.dataForm.code,
                    agentArea:this.dataForm.agentArea,
                    operationMode:this.dataForm.operationMode,
                    geo:this.dataForm.geo,
                    address:this.dataForm.address,
                    telephone:this.dataForm.telephone,
                    approveDate:this.dataForm.approveDate,
                    openDate:this.dataForm.openDate,
                    openTime:this.dataForm.openTime[0]?this.dataForm.openTime[0]:'',
                    closeTime:this.dataForm.openTime[1]?this.dataForm.openTime[1]:'',
                    ownerName:this.infoForm.ownerName,
                    equipments:this.equipmentsForm.equipments,
                    serviceMan:this.equipmentsForm.serviceMan,
                    managerName:this.mangerForm.managerName
                };
                this.$refs['mangerForm'].validate((valid) =>{
                    if(valid){
                        this.isDisable = true;
                        this.$post(apiPage.api.agentSave + `${!this.dataForm.id ? 'save' :'update'}`,request).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 800,
                                    onClose: () => {
                                        this.active = 0;
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                });
                            } else {
                                this.isDisable = false;
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })

            },
            closeAgent(){
                this.$confirm(`关闭投注站须由省中心批示同意后才可进行关闭后，系统将终止该投注站的所有操作，请谨慎执行此操作
                当前您确认关闭投注站吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.closeAgent + this.dataForm.id).then((data) =>{
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.visible = false;
                                    this.$emit('refreshDataList')
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消关闭投注站'
                    });
                });
            }
        }
    }
</script>

<style>
    .el-form-item .el-form-item{
        height: 58px;
    }
    .ml0 .el-form-item__content{
        margin-left:0!important;
    }
    .close-agent{
        margin-bottom:10px;
        position:absolute;
        top:38px;
        right:50px;
    }
    .el-date-editor .el-range-separator{
        width:10%!important;
    }
</style>