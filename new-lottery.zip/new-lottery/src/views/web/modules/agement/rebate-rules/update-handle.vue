<template>
    <el-dialog
            title="修改"
            :close-on-click-modal="false"
            width="30%"
            :visible.sync="visible">
        <p>
            说明：规则修改后，投注站订购即开票将按照新的规则进行返利，因此请谨慎操作
        </p>
        <p>
            终端：投注站
        </p>
        <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()"
                 label-width="130px">
            <el-form-item label="即开票采购返利" prop="value">
                <el-row>
                    <el-col :span="20">
                        <el-input v-model="dataForm.value"></el-input>
                    </el-col>
                    <el-col :span="3">
                        %
                    </el-col>
                </el-row>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="visible = false">取消</el-button>
          <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
        </span>
    </el-dialog>
</template>

<script>
    import apiPage from '@/api'

    export default {
            data(){
                const valueRule = (rule, value, callback) => {
                    var reg = /^[1-9][0-9]{0,1}$/
                    if (value == '') {
                        callback(new Error('即开票采购返利不能为空'))
                    } else if(!reg.test(value)) {
                        callback(new Error('只能输入1~99的整数'))
                    }else{
                        callback()
                    }
                };
                return {
                    visible: false,
                    dataForm: {
                        id: '',
                        value: '8'
                    },
                    dataRule: {
                        value: {required: true, validator: valueRule, trigger: 'blur'}
                    }
                }
            },
            methods:{
                init(id) {
                    this.visible = true;
                    this.dataForm.id = id;
                    this.$get(apiPage.api.agentRebate).then((data)=> {
                        if(data.code == 0){
                            this.dataForm = data.infos[0];
                        }
                    })
                },
                dataFormSubmit() {
                    this.$refs['dataForm'].validate((valid) => {
                        if (valid) {
                            this.$post(apiPage.api.agentRebateUpdate, this.dataForm).then((data) => {
                                if (data.code == 0) {
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 1500,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList');
                                        }
                                    })
                                } else {
                                    this.$message.error(data.msg)
                                }
                            })
                        }
                    })
                },
            }
        }
</script>

<style scoped>

</style>