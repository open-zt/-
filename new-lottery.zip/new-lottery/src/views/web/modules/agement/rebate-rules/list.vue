<template>
    <div>
        <el-table
        border
        style="width:100%"
        :data="dataList">
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="终端">
            </el-table-column>
            <el-table-column
                    prop="value"
                    header-align="center"
                    align="center"
                    label="即开票采购返利">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" v-if="scope.row.status != 2" @click="UpdateHandle(scope.row.id)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <update-handle ref="UpdateHandle" @refreshDataList="getDataList"></update-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import UpdateHandle from './update-handle'
    export default {
        data(){
            return{
                dataList:[],
            }
        },
        components: {UpdateHandle},
        methods:{
            UpdateHandle(id){
                this.$nextTick(()=> {
                    this.$refs.UpdateHandle.init(id);
                })
            },
            getDataList(){
                this.$get(apiPage.api.agentRebate).then((data)=> {
                    if(data.code == 0){
                        this.dataList = data.infos;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>