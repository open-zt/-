<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
            <el-button type="primary" @click="exportExcel()" plain>导入</el-button>
            <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="投注站编号">
                <el-input v-model="dataForm.code" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="业主">
                <el-input v-model="dataForm.ownerName" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="经营状态">
                <el-select v-model="dataForm.status" clearable>
                    <el-option value="0" label="暂停营业"></el-option>
                    <el-option value="1" label="营业中"></el-option>
                    <el-option value="2" label="已关闭"></el-option>
                    <el-option value="3" label="尚未营业"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="委托服务状态">
                <el-select v-model="dataForm.flag" clearable>
                    <el-option value="0" label="暂停接单"></el-option>
                    <el-option value="1" label="接单中"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="投注站编号">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="投注站昵称">
            </el-table-column>
            <el-table-column
                    prop="geo"
                    header-align="center"
                    align="center"
                    width="150"
                    label="地区">
            </el-table-column>
            <el-table-column
                    prop="address"
                    header-align="center"
                    align="center"
                    label="详细地址">
            </el-table-column>
            <el-table-column
                    prop="ownerName"
                    header-align="center"
                    align="center"
                    label="业主">
            </el-table-column>
            <el-table-column
                    prop="gyNumber"
                    header-align="center"
                    align="center"
                    label="雇员（人）">
            </el-table-column>
            <el-table-column
                    prop="managerName"
                    header-align="center"
                    align="center"
                    label="专管员">
            </el-table-column>
            <el-table-column
                    prop="sbNumber"
                    header-align="center"
                    align="center"
                    label="设备数量（台）">
            </el-table-column>
            <el-table-column
                    prop="serviceMan"
                    header-align="center"
                    align="center"
                    label="设备维修人员">
            </el-table-column>
            <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="经营状态">
            </el-table-column>
            <el-table-column
                    prop="flag"
                    header-align="center"
                    align="center"
                    label="委托服务状态">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" v-if="scope.row.status != '已关闭'" @click="addOrUpdateHandle(scope.row.id,scope.row.status)">编辑</el-button>
                    <el-button type="text" size="small" v-if="scope.row.status == '已关闭'" @click="detailsHandle(scope.row.id)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <export-handle ref="exportHandle" @refreshDataList="getDataList"></export-handle>
        <add-or-update-handle ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update-handle>
        <details-handle ref="detailsHandle"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import exportHandle from './export-excel'
    import addOrUpdateHandle from './add-or-update'
    import detailsHandle from './details-handle'
    export default {
        name: "lottery-list",
        data(){
            return{
                dataList:[],
                dataForm:{
                    code:'',
                    ownerName:'',
                    status:'',
                    flag:''
                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
                dataListSelections:[]
            }
        },
        components:{
            exportHandle,addOrUpdateHandle,detailsHandle
        },
        methods:{
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            exportExcel(){
                this.$nextTick(() => {
                    this.$refs.exportHandle.init();
                })
            },
            addOrUpdateHandle(id,status){
                this.$nextTick(() => {
                    this.$refs.addOrUpdate.init(id,status);
                })
            },
            detailsHandle(id){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.init(id);
                })
            },
            getDataList(){
                let request = {
                    'code':this.dataForm.code,
                    'ownerName':this.dataForm.ownerName,
                    'status':this.dataForm.status,
                    'flag':this.dataForm.flag,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.agentList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            deleteHandle(id) {
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.id
                });
                let request = {
                    'ids': ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.agentBatchRemove, request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 3000,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        } else {
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            }
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>