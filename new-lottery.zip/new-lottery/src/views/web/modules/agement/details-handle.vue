<template>
    <div>
        <el-dialog
                class="dialog-con"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                title="投注站详情"
                :before-close="handleClose"
                :visible.sync="visible" >
            <el-steps :active="active" finish-status="success">
                <el-step title="投注站信息"></el-step>
                <el-step title="业主信息"></el-step>
                <el-step title="投注机信息"></el-step>
                <el-step title="管理设置"></el-step>
            </el-steps>
            <el-card shadow="always" v-show="active == 0">
                <el-form :model="dataForm" label-width="145px">
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form-item prop="code" label="投注站编号">
                                <span>{{dataForm.code}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="agentArea" label="投注站面积(平方米)">
                                <span>{{dataForm.agentArea}}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form-item prop="operationMode" label="经营方式">
                                <span v-if="dataForm.operationMode == 1">专营</span>
                                <span v-if="dataForm.operationMode == 2">兼营</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="telephone" label="固定电话">
                                <span>{{dataForm.telephone}}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form-item prop="geo" label="地区">
                                <span>{{dataForm.geoAddress}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="address" label="详细地址">
                                <span>{{dataForm.address}}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form-item prop="openTime" label="营业开始时间">
                                <span>{{dataForm.openTime[0]}} - {{dataForm.openTime[1]}}</span>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="approveDate" label="站点批准日期">
                                <span>{{dataForm.approveDate}}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="12">
                            <el-form-item prop="openDate" label="开业日期">
                                <span>{{dataForm.openDate}}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </el-card>

            <el-card shadow="always" v-show="active == 1">
                    <el-form :model="infoForm"  ref="infoForm" label-width="140px">
                        <el-row>
                            <el-col>
                                <el-form-item prop="ownerName" label="业主姓名">
                                    <span>{{dataForm.ownerName}}</span>
                                </el-form-item>
                            </el-col>
                        </el-row>
                    </el-form>
                </el-card>
            <el-card shadow="always" v-show="active == 2">
                    <el-form :model="equipmentsForm"  ref="equipmentsForm" label-width="140px">
                        <p>投注机信息</p>
                        <el-row>
                            <el-col>
                                <el-form-item class="ml0">
                                    <el-table border :data="equipmentsForm.equipments">
                                        <el-table-column label="编号" align="center" prop="equipmentCode" header-align="center"></el-table-column>
                                        <el-table-column label="型号" align="center" prop="modelNumber" header-align="center"></el-table-column>
                                        <el-table-column label="供应商" align="center" prop="supplierName" header-align="center"></el-table-column>
                                        <el-table-column label="中标日期" align="center" prop="biddingDate" header-align="center"></el-table-column>
                                        <el-table-column label="采购日期" align="center" prop="purchaseDate" header-align="center"></el-table-column>
                                        <el-table-column label="上线日期" align="center" prop="onlineDate" header-align="center" width="250"></el-table-column>
                                    </el-table>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col>
                                <el-form-item prop="serviceMan" label="投注机维修归属:">
                                    <span>{{equipmentsForm.serviceMan}}</span>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col>
                                <p>说明：完善投注机信息，便于投注站在终端进行设备报修，同时中心可以精准掌握投注站的营业表现</p>
                            </el-col>
                        </el-row>
                    </el-form>
                </el-card>
            <el-card shadow="always" v-show="active == 3">
                <el-form :model="mangerForm"  ref="mangerForm" label-width="140px">
                    <el-row>
                        <el-col>
                            <el-form-item prop="managerName" label="专管员:" >
                                <span>{{dataForm.managerName}}</span>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </el-card>
            <el-button style="margin-top: 12px;" @click="prev" v-if="active == 1 || active == 2 || active == 3">上一步</el-button>
            <el-button style="margin-top: 12px;" @click="next" v-if="active == 0 || active == 1 || active == 2">下一步</el-button>
            <el-button @click="visible = false">取 消</el-button>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "details-handle",
        data(){
            return{
                visible:false,
                active:0,
                dataForm:{
                    openTime:'',
                },
                infoForm:{},
                equipmentsForm:{},
                mangerForm:{},
            }
        },
        methods:{
            prev(){
                --this.active;
                if (this.active < 0) this.active = 0;
            },
            next(){
                this.active ++
            },
            handleClose(){
                this.dataForm.openTime = '';
                this.active = 0;
                this.visible = false;
            },
            init(id){
                this.visible = true;
                this.$get(apiPage.api.agentInfo + id).then((data) => {
                    if(data.code == 0){
                        this.dataForm = data.agent;
                        if(this.dataForm.operationMode){
                            this.dataForm.operationMode = this.dataForm.operationMode.toString();
                        }

                        if(data.agent.timeList != []){
                            this.dataForm.openTime = data.agent.timeList;
                        }
                        this.equipmentsForm.equipments = data.agent.agentEquipmentList;
                    }
                })
            }
        },
        created() {

        }
    }
</script>

<style scoped>

</style>