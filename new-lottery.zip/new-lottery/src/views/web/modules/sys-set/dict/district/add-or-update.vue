<template>
    <el-dialog
            class="dialog-con"
            :title="!dataForm.id ? '新增' : '修改'"
            :close-on-click-modal="false"
            :visible.sync="visible">

        <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
            <el-form-item label="名称" prop="regionName">
                <el-input v-model="dataForm.regionName" placeholder="名称"></el-input>
            </el-form-item>
            <el-form-item label="上级菜单" prop="parentName">
                <el-popover
                        ref="menuListPopover"
                        placement="bottom-start"
                        trigger="click">
                    <el-tree
                            :data="menuList"
                            :props="menuListTreeProps"
                            node-key="regionId"
                            ref="menuListTree"
                            @current-change="menuListTreeCurrentChangeHandle"
                            :highlight-current="true"
                            :expand-on-click-node="false">
                    </el-tree>
                </el-popover>
                <el-input v-model="dataForm.parentName" v-popover:menuListPopover :readonly="true"
                          placeholder="点击选择上级菜单" class="menu-list__input"></el-input>
            </el-form-item>
            <el-form-item label="地区级别" prop="regionLevel">
                <el-select v-model="dataForm.regionLevel" placeholder="地区级别">
                    <el-option value="1" label="省"></el-option>
                    <el-option value="2" label="市"></el-option>
                    <el-option value="3" label="区"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="排序号" prop="sort">
                <el-input-number v-model="dataForm.sort" controls-position="right" :min="0" label="排序号"></el-input-number>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="visible = false">取消</el-button>
          <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
        </span>
    </el-dialog>
</template>

<script>
    import apiPage from '@/api'
    import {treeDataTranslate} from '@/util'
    export default {
        name: "add-or-update",
        data(){
            return{
                visible:false,
                dataForm:{
                    id:'',
                    regionName:'',
                    parentId: 0,
                    parentName:'',
                    regionLevel:'1'
                },
                dataRule:{
                    regionName: [
                        {required: true, message: '地理名称不能为空', trigger: 'blur'}
                    ],
                    parentName: [
                        {required: true, message: '上级菜单不能为空', trigger: 'change'}
                    ],
                    regionLevel: [
                        {required: true, message: '地区不能为空', trigger: 'change'}
                    ],
                },
                menuList: [],
                menuListTreeProps: {
                    label: 'regionName',
                    children: 'children'
                }
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.dataForm.id = id;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields()
                });

                this.$get(apiPage.api.districtDictList).then((data) => {
                    if(data.code == 0){
                        this.menuList = treeDataTranslate(data.list, 'regionId')
                    }
                }).then(() => {
                    if (!this.dataForm.id) {
                        // 新增
                        this.menuListTreeSetCurrentNode()
                    } else {
                        // 修改
                        this.$get(apiPage.api.districtInfo + `${this.dataForm.id}`).then((data) => {
                            this.dataForm.id = data.info.regionId;
                            this.dataForm.regionName = data.info.regionName;
                            this.dataForm.parentId = data.info.parentId;
                            this.dataForm.regionLevel = data.info.regionLevel;
                            this.menuListTreeSetCurrentNode();
                        });
                    }
                })
            },
            // 菜单树选中
            menuListTreeCurrentChangeHandle(data, node) {
                this.dataForm.parentId = data.regionId;
                this.dataForm.parentName = data.regionName;
            },
            // 菜单树设置当前选中节点
            menuListTreeSetCurrentNode() {
                this.$refs.menuListTree.setCurrentKey(this.dataForm.parentId);
                this.dataForm.parentName = (this.$refs.menuListTree.getCurrentNode()['regionName']);
            },
            dataFormSubmit(){
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        this.$post(apiPage.api.districtSave + `${!this.dataForm.id ? 'save' : 'update'}`, this.dataForm).then((data) => {
                            if (data.code == 0) {
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 1500,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList');
                                    }
                                })
                            } else {
                                this.$message.error(data.msg)
                            }
                        });
                    }
                })
            }
        }
    }
</script>

<style scoped>

</style>