<template>
    <div>
<!--        地理信息-->
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
            <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="名称">
                <el-input v-model="dataForm.regionName" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="dataList"
                border
                style="width:100%"
                row-key="regionId"
                :tree-props="{children: 'children'}"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="regionName"
                    header-align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="regionCode"
                    header-align="center"
                    align="center"
                    label="编码">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="排序">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small"  @click="addOrUpdateHandle(scope.row.regionId)">编辑</el-button>
<!--                    <el-button type="text" size="small" disabled @click="removeHandle(scope.row.menuId,scope.row.name)">删除</el-button>-->
                </template>
            </el-table-column>
        </el-table>

        <!-- 弹窗, 新增 / 修改 -->
        <add-or-update v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update>

    </div>
</template>

<script>
    import apiPage from '@/api'
    import AddOrUpdate from './add-or-update'
    export default {
        name: "district-list",
        data(){
            return{
                dataForm:{
                    regionName:''
                },
                dataList:[],
                addOrUpdateVisible:false,
                dataListSelections:[],
            }
        },
        components: {
            AddOrUpdate
        },
        methods:{
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            clear(){
                this.dataForm = {
                    regionName:''
                }
                this.getDataList();
            },
            addOrUpdateHandle(id) {
                this.addOrUpdateVisible = true;
                this.$nextTick(() => {
                    this.$refs.addOrUpdate.init(id);
                })
            },
            getDataList(){
                this.$get(apiPage.api.districtList).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.list;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            deleteHandle(id){
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.regionId
                });
                let request = {
                    'ids': ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.districtRemove, request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 3000,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        } else {
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>