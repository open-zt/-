<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.userId?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" label-width="100px"  @keyup.enter.native="submitFormData()" >
                <p>用户基础信息</p>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="name" label="姓名">
                            <span>{{dataForm.name}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="idCard" label="身份证号">
                            <span>{{dataForm.idCard}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="sex" label="性别">
                            <span v-if="dataForm.sex == 1">男</span>
                            <span v-if="dataForm.sex == 2">女</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="birthDate" label="出生日期 ">
                            <span>{{dataForm.birthDate}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="nativePlace" label="籍贯">
                            <span>{{dataForm.nativePlace}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="mobile" label="手机号">
                            <el-input v-model="dataForm.mobile" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p>支付信息</p>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="银行卡号">
<!--                            <span>{{dataForm.username}}</span>-->
                        </el-form-item>
                    </el-col>
                </el-row>
                <p>账号信息</p>
                <el-row>
                    <el-col :span="12">
                        <el-form-item prop="username" label="账号">
                            <span>{{dataForm.username}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="角色">
                            <span v-if="dataForm.isAgent == '0'">彩民</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item prop="createDate" label="注册时间">
                            <span>{{dataForm.createDate}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import {mobileRule} from "@/util/validate";

    export default {
        data(){
            return{
                visible:false,
                dataForm:{
                    userId:'',
                    isAgent:'',
                    name:'',
                    idCard:'',
                    sex:'',
                    birthDate:'',
                    nativePlace:'',
                    mobile:'',
                    username:'',
                    createDate:''
                },
                dataRule:{
                    mobile:[{required: true,validator:mobileRule,trigger: 'blur'}],
                },
            }
        },
        methods:{
            init(userId){
                this.visible = true;
                this.dataForm.userId = userId;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                });

                if(this.dataForm.userId){
                    this.$get(apiPage.api.lotteryUserInfo + this.dataForm.userId).then((data) => {
                        if(data.code == 0){
                            this.dataForm = data.user;
                        }
                    })
                }
            },
            submitFormData(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.$post(apiPage.api.agentUserUpdate,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 1500,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                })
                            } else {
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            }
        },
        created() {

        }
    }
</script>

<style scoped>

</style>