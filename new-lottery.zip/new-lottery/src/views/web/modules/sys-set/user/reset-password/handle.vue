<template>
    <el-dialog
            class="dialog-con"
            title="重置密码"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            width="10%"
            :visible.sync="visible">
         <h3 :style="{textAlign:'center'}">新密码:{{passWord}}</h3>
    </el-dialog>
</template>

<script>
    import apiPage from '@/api'
    export default {
        data(){
            return{
                visible:false,
                userId:'',
                passWord:'',
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.userId = id;
                let request = {
                  'userId':this.userId
                };
                this.$post(apiPage.api.resetPassWord,request).then((data) => {
                    if(data.code == 0){
                        this.passWord = data.newPwd;
                    }
                })
            }
        },
        created() {

        }
    }
</script>

<style scoped>

</style>