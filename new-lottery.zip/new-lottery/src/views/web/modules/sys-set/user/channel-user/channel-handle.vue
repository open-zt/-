<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.userId?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" label-width="100px"  @keyup.enter.native="submitFormData()" >
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="name" label="姓名">
                            <el-input v-model="dataForm.name" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="idCard" label="身份证号">
                            <el-input v-model="dataForm.idCard" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="sex" label="性别">
                            <el-select v-model="dataForm.sex" placeholder="请选择">
                                <el-option value="1" label="男"></el-option>
                                <el-option value="2" label="女"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="手机号" prop="mobile">
                            <el-input v-model="dataForm.mobile" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <p class="black">账号信息</p>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="username" label="账号">
                            <span>{{dataForm.username}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="nickName" label="昵称">
                            <span>{{dataForm.nickName}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="roleName" label="角色">
                            <span>{{dataForm.roleName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="gmtCreate" label="创建时间">
                            <span>{{dataForm.gmtCreate}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="status" label="状态">
                            <el-select v-model="dataForm.status" clearable>
                                <el-option value="0" label="无效"></el-option>
                                <el-option value="1" label="有效"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()" :disabled="isDisable">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import {mobileRule} from "@/util/validate";

    export default {
        name: "channel-handle",
        data(){
            const idCardRule = (rule,value,callback) =>{
                var reg = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
                let request = {
                    id:this.dataForm.userId,
                    verifyParam:this.dataForm.idCard
                };
                if (value === '') {
                    callback(new Error('身份证号必填'));
                } else if(!reg.test(value)) {
                    callback(new Error('请输入合法的身份证号'));
                }else if(request){
                    this.$post(apiPage.api.verifyOwnerUserIdCard,request).then((data) =>{
                        if(data.code == 500){
                            callback(data.msg);
                        }else{
                            callback();
                        }
                    }).catch(() => {
                        callback(new Error('服务异常'));
                    })
                }else{
                    callback();
                }
            };
            return{
                visible:false,
                isDisable:false,
                dataForm:{
                    userId:'',
                    name:'',
                    idCard:'',
                    sex:'',
                    mobile:'',
                    username:'',
                    nickName:'',
                    roleName:'',
                    gmtCreate:'',
                    status:'',
                },
                dataRule:{
                    name:[{required: true, message: '名称必填', trigger: 'blur'}],
                    idCard:[{required: true,validator:idCardRule, trigger: 'blur'}],
                    sex:[{required: true, message: '性别必填', trigger: 'blur'}],
                    mobile:[{required: true,validator:mobileRule, trigger: 'blur'}],
                    status:[{required: true, message: '状态必填', trigger: 'blur'}],
                }
            }
        },
        methods:{
            init(userId){
                this.visible = true;
                this.dataForm.userId = userId;
                this.isDisable = false;
                if(this.dataForm.userId){
                    this.$get(apiPage.api.channelUserInfo + this.dataForm.userId).then((data) =>{
                        if(data.code == 0){
                            this.dataForm = data.channel;
                            if(data.channel.sex){
                                this.dataForm.sex = data.channel.sex.toString();
                            }
                            if(data.channel.status == 0){
                                this.dataForm.status = '无效'
                            }else if(data.channel.status == 1){
                                this.dataForm.status = '有效'
                            }
                        }
                    })
                }
            },
            submitFormData(){
                if(this.dataForm.status == '有效'){
                    this.dataForm.status= "1";
                }else if(this.dataForm.status == '无效'){
                    this.dataForm.status= "0";
                };
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        this.isDisable = true;
                        this.$post(apiPage.api.channelUserSave + `${!this.dataForm.userId ?'save':'update'}`,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 800,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                });
                            } else {
                                this.isDisable = false;
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            },
        }
    }
</script>

<style scoped>

</style>