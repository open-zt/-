<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="账号">
                <el-input v-model="dataForm.username" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="姓名">
                <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="手机号">
                <el-input v-model="dataForm.mobile" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="角色">
                <el-select  v-model="dataForm.roleSign" placeholder="请输入" clearable>
                    <el-option value="1" label="投注站业主"></el-option>
                    <el-option value="2" label="投注站雇员"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="状态">
                <el-select  v-model="dataForm.status" placeholder="请输入" clearable>
                    <el-option value="0" label="无效"></el-option>
                    <el-option value="1" label="有效"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="dataList"
                style="width:100%"
                border>
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="账号">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="姓名">
            </el-table-column>
            <el-table-column
                    prop="mobile"
                    header-align="center"
                    align="center"
                    label="手机号">
            </el-table-column>
            <el-table-column
                    prop="geo"
                    header-align="center"
                    align="center"
                    label="地区">
            </el-table-column>
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="归属投注站">
            </el-table-column>
            <el-table-column
                    prop="roleSign"
                    header-align="center"
                    align="center"
                    label="角色">
                <template slot-scope="scope">
                    <p v-if="scope.row.roleSign == 'tzzUser'">投注站业主</p>
                    <p v-if="scope.row.roleSign == 'gyUser'">投注站雇员</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="createDate"
                    header-align="center"
                    align="center"
                    label="创建时间">
            </el-table-column>
            <el-table-column
                prop="status"
                header-align="center"
                align="center"
                label="用户状态">
                <template slot-scope="scope">
                    <p v-if="scope.row.status == 0">无效</p>
                    <p v-if="scope.row.status == 1">有效</p>
                </template>
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.userId,scope.row.roleSign)">编辑</el-button>
                    <el-button type="text" size="small" @click="resetPassWord(scope.row.userId)">密码重置</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
        <add-or-update ref="addOrUpdate"  @refreshDataList="getDataList"></add-or-update>
        <details-handle ref="detailsHandle"  @refreshDataList="getDataList"></details-handle>
        <reset-pass-word ref="resetPassWord"></reset-pass-word>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import AddOrUpdate from './agent-owner-handle'
    import DetailsHandle from './employe-details-handle'
    import resetPassWord from '../reset-password/handle'
    export default {
        name: "list",
        data(){
            return{
                dataForm:{
                    isAgent:'1',
                    username:'',
                    name:'',
                    mobile:'',
                    roleSign:'',
                    status:''
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        components:{
            AddOrUpdate,DetailsHandle,resetPassWord
        },
        methods:{
            resetPassWord(id){
                this.$nextTick(() => {
                    this.$refs.resetPassWord.init(id);
                })
            },
            addOrUpdateHandle(id,roleSign){
                if(roleSign == 'tzzUser'){
                    this.$nextTick(() => {
                        this.$refs.addOrUpdate.init(id);
                    })
                }else if(roleSign == 'gyUser'){
                    this.$nextTick(() => {
                        this.$refs.detailsHandle.init(id);
                    })
                }
            },
            clear(){
                this.dataForm = {
                    isAgent:'1',
                    username:'',
                    name:'',
                    mobile:'',
                    roleSign:'',
                    status:''
                };
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'isAgent':this.dataForm.isAgent,
                    'username':this.dataForm.username,
                    'name':this.dataForm.name,
                    'mobile':this.dataForm.mobile,
                    'roleSign':this.dataForm.roleSign,
                    'status':this.dataForm.status,
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.agentUserList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>