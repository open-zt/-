<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="账号">
                <el-input v-model="dataForm.username" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="昵称">
                <el-input v-model="dataForm.nickName" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="姓名">
                <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="手机号">
                <el-input v-model="dataForm.mobile" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="角色">
                <el-select  v-model="dataForm.roleSign" placeholder="请输入" clearable>
                    <el-option value="渠道商" label="渠道商"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="状态">
                <el-select  v-model="dataForm.status" placeholder="请输入" clearable>
                    <el-option value="0" label="无效"></el-option>
                    <el-option value="1" label="有效"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="dataList"
                style="width:100%"
                border>
            <el-table-column
                    prop="username"
                    header-align="center"
                    align="center"
                    label="账号">
                <template slot-scope="scope">
                    <p v-if="scope.row.username">{{scope.row.username}}</p>
                    <p v-else>-</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="nickName"
                    header-align="center"
                    align="center"
                    label="昵称">
                <template slot-scope="scope">
                    <p v-if="scope.row.nickName">{{scope.row.nickName}}</p>
                    <p v-else>-</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="姓名">
            </el-table-column>
            <el-table-column
                    prop="mobile"
                    header-align="center"
                    align="center"
                    label="手机号">
            </el-table-column>
            <el-table-column
                    prop="channelName"
                    header-align="center"
                    align="center"
                    label="归属渠道">
                <template slot-scope="scope">
                    <p v-if="scope.row.channelName">{{scope.row.channelName}}</p>
                    <p v-else>-</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="roleName"
                    header-align="center"
                    align="center"
                    label="角色">
            </el-table-column>
            <el-table-column
                    prop="gmtCreate"
                    header-align="center"
                    align="center"
                    label="创建时间">
            </el-table-column>
            <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="用户状态">
                <template slot-scope="scope">
                    <p v-if="scope.row.status == 0">无效</p>
                    <p v-if="scope.row.status == 1">有效</p>
                </template>
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.userId)">编辑</el-button>
                    <el-button type="text" size="small" @click="resetPassWord(scope.row.userId)">密码重置</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
        <add-or-update ref="addOrUpdate"  @refreshDataList="getDataList"></add-or-update>
        <reset-pass-word ref="resetPassWord"></reset-pass-word>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import AddOrUpdate from './channel-handle'
    import resetPassWord from '../reset-password/handle'
    export default {
        name: "list",
        data(){
            return{
                dataForm:{
                    username:'',
                    nickName:'',
                    name:'',
                    mobile:'',
                    roleSign:'',
                    status:''
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        components:{
            AddOrUpdate,resetPassWord
        },
        methods:{
            resetPassWord(id){
                this.$nextTick(() => {
                    this.$refs.resetPassWord.init(id);
                })
            },
            addOrUpdateHandle(userId){
                this.$nextTick(() => {
                    this.$refs.addOrUpdate.init(userId);
                })
            },
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'username':this.dataForm.username,
                    'nickName':this.dataForm.nickName,
                    'name':this.dataForm.name,
                    'mobile':this.dataForm.mobile,
                    'roleSign':this.dataForm.roleSign,
                    'status':this.dataForm.status,
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.channelUserList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>