<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.userId?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="submitFormData()" label-width="110px">
                <p>用户信息</p>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="姓名" prop="name">
                            <el-input v-model="dataForm.name" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="手机号" prop="mobile">
                            <el-input v-model="dataForm.mobile" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p>部门信息</p>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="部门" class="is-required">
                            <el-popover
                                    placement="bottom"
                                    width="300"
                                    trigger="click">
                                <el-input placeholder="搜索部门" prefix-icon="el-icon-search" v-model="filterText" clearable></el-input>
                                <el-tree
                                        :data="deptList"
                                        :props="deptTreeProps"
                                        node-key="deptId"
                                        ref="deptTree"
                                        :default-expanded-keys="defaultExpandKeys"
                                        @node-click="handleNodeClick"
                                        :filter-node-method="filterNode">
                                </el-tree>
                                <el-input slot="reference" v-model="dataForm.deptName" placeholder="请输入"  suffix-icon="el-icon-arrow-down"></el-input>
                            </el-popover>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="职位" prop="position">
                            <el-input v-model="dataForm.position" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p>账号信息</p>
                <el-row :gutter="20">
                    <el-col :span="12" v-if="!this.dataForm.userId">
                        <el-form-item label="账号（工号）" prop="username" >
                            <el-input v-model="dataForm.username" placeholder="请输入"></el-input>
                            <div>初始密码为123456</div>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12" v-if="this.dataForm.userId">
                        <el-form-item label="账号（工号）">
                            <div>{{dataForm.username}}</div>
                            <div>初始密码为123456</div>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="角色" prop="roleId">
                            <el-select v-model="dataForm.roleId" placeholder="请选择"  style="width:100%">
                                <el-option v-for="item in roleSelectList" :value="item.roleId" :label="item.roleName" :key="item.roleId"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="用户状态" prop="status">
                            <el-select v-model="dataForm.status" placeholder="请选择"  style="width:100%">
                                <el-option value="0" label="无效"></el-option>
                                <el-option value="1" label="有效"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import {mobileRule} from "@/util/validate";

    export default {
        data(){
            const userNameRule = (rule,value,callback) => {
                let request = {
                    verifyParam:this.dataForm.username
                };
                this.$post(apiPage.api.verifyUserName,request).then((data) =>{
                    if(data.code == 500){
                        callback(data.msg);
                    }else{
                        callback();
                    }
                }).catch(() => {
                    callback(new Error('服务异常'));
                })
            };
            return{
                filterText:'',
                visible:false,
                roleSelectList:[],
                deptSelectList:[],
                dataForm:{
                    userId:'',
                    name:'',
                    mobile:'',
                    deptId:'',
                    deptName:'',
                    position:'',
                    username:'',
                    roleId:'',
                    status:'1',
                },
                dataRule:{
                    name:[{required: true, message: '姓名必填', trigger: 'blur'}],
                    mobile:[{required: true,validator:mobileRule, trigger: 'blur'}],
                    deptName:[{required: true, message: '部门必填', trigger: 'blur'}],
                    username:[{required: true, message: '账号必填', trigger: 'blur'},{validator:userNameRule, trigger: 'blur'}],
                    roleId:[{required: true, message: '角色必填', trigger: 'blur'}],
                    status:[{required: true, message: '用户状态 必填', trigger: 'blur'}],
                },
                deptList:[],
                deptTreeProps:{
                    children: 'list',
                    label: 'name'
                },
                defaultExpandKeys:[],
            }
        },
        watch: {
            filterText(val) {
                this.$refs.deptTree.filter(val);
            }
        },
        methods:{
            handleNodeClick(data) {
                this.dataForm.deptName = data.name;
                this.dataForm.deptId = data.deptId;
            },
            filterNode(value, data) {
                if (!value) return true;
                return data.name.indexOf(value) !== -1;
            },
            init(id,deptId,deptName){
                this.visible = true;
                this.dataForm.userId = id;
                this.dataForm.deptId = deptId;
                this.dataForm.deptName = deptName;

                this.$nextTick(() => {
                    this.dataForm.username = '';
                    this.$refs['dataForm'].resetFields();
                });

                this.$get(apiPage.api.deptTree).then((data) => {
                    if(data.code == 0){
                        this.deptList = data.deptTree;
                        this.defaultExpandKeys = [this.deptList[0].deptId];
                    }
                });
                this.$get(apiPage.api.roleSelectList).then((data) => {
                    if(data.code == 0){
                        this.roleSelectList = data.roleList;
                    }
                });

                if(this.dataForm.userId){
                    this.$get(apiPage.api.userInfo + this.dataForm.userId).then((data) => {
                        if(data.code == 0){
                            this.dataForm = data.user;
                            this.dataForm.status = data.user.status.toString();
                        }
                    })
                }

            },
            submitFormData(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        if(this.dataForm.deptName == ''){
                            this.$message.error('部门必填');
                        }else{
                            this.$post(apiPage.api.userSave + `${!this.dataForm.userId ? 'save' : 'update'}`,this.dataForm).then((data) => {
                                if(data.code == 0){
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 1500,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList')
                                        }
                                    })
                                } else {
                                    this.$message.error(data.msg);
                                }
                            })
                        }

                    }
                })
            }
        },

    }
</script>

<style scoped>

</style>