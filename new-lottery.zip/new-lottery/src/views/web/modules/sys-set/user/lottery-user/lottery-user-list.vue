<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="手机号">
                <el-input v-model="dataForm.mobile" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="昵称">
                <el-input v-model="dataForm.nickName" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="dataList"
                style="width:100%"
                border>
            <el-table-column
                    prop="mobile"
                    header-align="center"
                    align="center"
                    label="手机号">
            </el-table-column>
            <el-table-column
                    prop="nickName"
                    header-align="center"
                    align="center"
                    label="昵称">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="姓名">
            </el-table-column>
            <el-table-column
                    prop="createDate"
                    header-align="center"
                    align="center"
                    label="注册时间">
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.userId)">编辑</el-button>
                    <el-button type="text" size="small" @click="resetPassWord(scope.row.userId)">密码重置</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
        <details-handle ref="detailsHandle"  @refreshDataList="getDataList"></details-handle>
        <reset-pass-word ref="resetPassWord"></reset-pass-word>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import DetailsHandle from './lottery-user-details'
    import resetPassWord from '../reset-password/handle'
    export default {
        name: "list",
        data(){
            return{
                dataForm:{
                    isAgent:'0',
                    mobile:'',
                    nickName:'',
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        components:{
            DetailsHandle,resetPassWord
        },
        methods:{
            resetPassWord(id){
                this.$nextTick(() => {
                    this.$refs.resetPassWord.init(id);
                })
            },
            addOrUpdateHandle(id){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.init(id);
                })
            },
            clear(){
                this.dataForm = {
                    isAgent:'0',
                    mobile:'',
                    nickName:'',
                };
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'isAgent':this.dataForm.isAgent,
                    'mobile':this.dataForm.mobile,
                    'nickName':this.dataForm.nickName,
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.lotteryUserList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>