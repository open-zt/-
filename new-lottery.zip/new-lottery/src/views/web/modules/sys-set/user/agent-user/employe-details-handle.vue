<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.userId?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" label-width="100px"  @keyup.enter.native="submitFormData()" >
                <p>用户基础信息</p>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="name" label="姓名">
                            <span>{{dataForm.name}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="idCard" label="身份证号">
                            <span>{{dataForm.idCard}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="sex" label="性别">
                            <span v-if="dataForm.name == 1">男</span>
                            <span v-if="dataForm.name == 2">女</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="nation" label="出生日期 ">
                            <span>{{dataForm.birthDate}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="mobile" label="手机号">
                            <el-input v-model="dataForm.mobile" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item prop="liveAddress" label="家庭住址">
                           <span>{{dataForm.liveAddress}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <p>账号信息</p>
                <el-row>
                    <el-col :span="12">
                        <el-form-item prop="username" label="账号">
                            <span>{{dataForm.username}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="roleSign" label="角色">
                            <span v-if="dataForm.roleSign == 'gyUser'">投注站雇员</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item prop="createDate" label="创建时间">
                            <span>{{dataForm.createDate}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import {mobileRule} from "@/util/validate";

    export default {
        data(){
            const idCardRule = (rule,value,callback) =>{
                var reg = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
                let request = {
                    id:this.dataForm.userId,
                    verifyParam:this.dataForm.idCard
                };
                if (value === '') {
                    callback(new Error('身份证号必填'));
                } else if(!reg.test(value)) {
                    callback(new Error('请输入合法的身份证号'));
                }else if(request){
                    this.$post(apiPage.api.verifyOwnerUserIdCard,request).then((data) =>{
                        if(data.code == 500){
                            callback(data.msg);
                        }else{
                            callback();
                        }
                    }).catch(() => {
                        callback(new Error('服务异常'));
                    })
                }else{
                    callback();
                }
            };
            return{
                visible:false,
                geoList:[],
                dataForm:{
                    userId:'',
                    name:'',
                    idCard:'',
                    sex:'',
                    nation:'',
                    birthDate:'',
                    nativePlace:'',
                    occupation:'',
                    politicsStatus:'',
                    education:'',
                    geo:'',
                    geoList:[],
                    liveAddress:'',
                    mobile:'',
                    createDate:''
                },
                dataRule:{
                    mobile:[{required: true,validator:mobileRule,trigger: 'blur'}],
                },
            }
        },
        methods:{
            init(userId){
                this.visible = true;
                this.dataForm.userId = userId;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.dataForm.geoList = [];
                });

                if(this.dataForm.userId){
                    this.$get(apiPage.api.agentUserInfo + this.dataForm.userId).then((data) => {
                        if(data.code == 0){
                            this.dataForm = data.user;
                        }
                    })
                }

                //地区下拉
                this.$get(apiPage.api.agentGeoList).then((data) => {
                    if(data.code == 0){
                        this.geoList = data.list;
                    }
                });
            },
            submitFormData(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.$post(apiPage.api.agentUserUpdate,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 1500,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                })
                            } else {
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            }
        },
        created() {

        }
    }
</script>

<style scoped>

</style>