<template>
    <div>
        <div>
            <el-row>
                <el-col :span="4">
                    <h2>部门</h2>
                    <el-tree
                            :data="deptList"
                            :props="deptTreeProps"
                            node-key="deptId"
                            :highlight-current="true"
                            :default-expanded-keys="defaultExpandKeys"
                            @node-click="handleNodeClick"
                            ref="deptTree">
                    </el-tree>
                </el-col>
                <el-col :span="20">
                    <div :style="{marginBottom:'10px'}">
                        <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
                        <el-button type="primary"  plain>导入</el-button>
                        <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
                    </div>
                    <el-table
                            :data="dataList"
                            border
                            style="width:100%"
                            @selection-change="handleSelectionChange">
                        <el-table-column
                                type="selection"
                                width="55">
                        </el-table-column>
                        <el-table-column
                                prop="username"
                                header-align="center"
                                align="center"
                                label="帐号（工号）">
                        </el-table-column>
                        <el-table-column
                                prop="name"
                                header-align="center"
                                align="center"
                                label="姓名">
                        </el-table-column>
                        <el-table-column
                                prop="deptName"
                                header-align="center"
                                align="center"
                                label="部门">
                        </el-table-column>
                        <el-table-column
                                prop="position"
                                header-align="center"
                                align="center"
                                label="职位">
                        </el-table-column>
                        <el-table-column
                                prop="mobile"
                                header-align="center"
                                align="center"
                                label="手机号">
                        </el-table-column>
                        <el-table-column
                                prop="status"
                                header-align="center"
                                align="center"
                                label="用户状态">
                            <template slot-scope="scope">
                                <p v-if="scope.row.status == 0">无效</p>
                                <p v-if="scope.row.status == 1">有效</p>
                            </template>
                        </el-table-column>
                        <el-table-column
                                header-align="center"
                                align="center"
                                label="操作"
                                width="150">
                            <template slot-scope="scope">
                                <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.userId)">编辑</el-button>
                                <el-button type="text" size="small" @click="resetPassWord(scope.row.userId)">重置密码</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                            @size-change="handleSizeChange"
                            @current-change="handleCurrentChange"
                            :current-page.sync="pageIndex"
                            :page-size="pageSize"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="totalPage"
                            v-if="this.dataList !=''">
                    </el-pagination>
                </el-col>
            </el-row>
        </div>
        <add-or-update ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update>
        <reset-pass-word ref="resetPassWord"></reset-pass-word>
    </div>
</template>

<script>
    import apiPage  from '@/api'
    import AddOrUpdate from './add-or-update'
    import resetPassWord from '../reset-password/handle'
    export default {
        data(){
            return{
                dataList:[],
                dataListSelections:[],
                pageIndex: 1,
                pageSize: 10,
                totalPage: 0,
                deptList:[],
                deptTreeProps:{
                    children: 'list',
                    label: 'name'
                },
                defaultExpandKeys:[],
                deptId:'',
                deptName:'',
                isOnce:true,
            }
        },
        components:{
            AddOrUpdate,resetPassWord
        },
        methods:{
            handleNodeClick(data) {
                this.deptId = data.deptId;
                this.deptName = data.name;
                this.getDataList()
            },
            addOrUpdateHandle(id){
                this.$nextTick(() => {
                    this.$refs.addOrUpdate.init(id,this.deptId,this.deptName);
                })
            },
            resetPassWord(id){
                this.$nextTick(() => {
                    this.$refs.resetPassWord.init(id);
                })
            },
            deleteHandle(id){
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.userId
                });
                let request = {
                    'ids':ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.ownerUserBatchRemove,request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                })
            },
            handleSelectionChange(val){
                this.dataListSelections = val;
            },
            getDeptList(){
                this.$get(apiPage.api.deptTree).then((data) => {
                    if(data.code == 0){
                        this.deptList = data.deptTree;
                        if(this.isOnce){
                            this.deptId = this.deptList[0].deptId;
                            this.deptName = this.deptList[0].name;
                            this.isOnce = false;
                        }
                        this.$nextTick(() =>{
                            this.$refs.deptTree.setCurrentKey(this.deptList[0].deptId);
                            this.defaultExpandKeys = [this.deptList[0].deptId];
                        })
                    }
                });
            },
            getDataList(){
                    let request = {
                        'deptId':this.deptId,
                        'current': this.pageIndex,
                        'size': this.pageSize
                    };
                    this.$get(apiPage.api.userList,request).then((data) => {
                        if(data.code == 0){
                            this.dataList = data.page.data;
                            this.totalPage = data.page.total;
                        }else{
                            this.dataList = [];
                            this.$message.error(data.msg)
                        }
                    })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            }
        },
        created() {
            this.getDeptList();
            setTimeout(() => {
                this.getDataList();
            },500)
        }
    }
</script>
