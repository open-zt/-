<template>
        <el-dialog
                class="dialog-con"
                title="委托服务时间"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                width="40%"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="150px">
                <el-form-item label="投注截止时间" prop="submitOrderTimeout">
                    <el-time-picker
                            v-model="dataForm.submitOrderTimeout"
                            value-format="HH:mm:ss"
                            placeholder="选择时间">
                    </el-time-picker>
                    <div>说明：1. 设置后，手机端委托服务会在开奖当天该时间后停止本期投注</div>
                    <div>2. 彩民每天在该时间前下的订单可以当天出票，之后下的订单隔天出票</div>
                    <div>3. 投注截止时间必须是彩票实际停售到开奖（19:00~21:15）之外的时间</div>
                </el-form-item>
                <el-form-item label="接单(出票)开始时间" prop="acceptOrderTime">
                    <el-time-picker
                            v-model="dataForm.acceptOrderTime"
                            value-format="HH:mm:ss"
                            placeholder="选择时间">
                    </el-time-picker>
                    <div>说明：1. 设置后，投注站每天该时间之后可以进行接单（出票）</div>
                    <div>2. 接单(出票)开始时间必须是彩票实际停售到开奖（19:00~21:15）之外的时间</div>
                </el-form-item>
                <el-form-item label="接单(出票)截止时间" prop="ticketOrderTimeout">
                    <el-time-picker
                            v-model="dataForm.ticketOrderTimeout"
                            value-format="HH:mm:ss"
                            @change="handleChange"
                            placeholder="选择时间">
                    </el-time-picker>
                    <div>说明：1. 设置后，投注站每天该时间之后没有接单（出票）的订单将会自动取消</div>
                    <div>2. 接单(出票)截止必须是彩票实际停售到开奖（19:00~21:15）之外的时间</div>
                    <div>3. 接单(出票)截止时间应大于投注截止时间</div>
                </el-form-item>
                <el-button type="primary" @click="dataFormSubmit()" :style="{marginLeft:'600PX'}">确 定</el-button>
            </el-form>
        </el-dialog>
</template>

<script>
    import apiPage from '@/api'
    export default {
        data(){
            const dataRule = (rule,value,callback) => {
                var maxTime=211500;
                var minTime=190000;
                var str=value.substring(0,2)+value.substring(3,5)+value.substring(6,);
                if(Number(str)<=maxTime&&Number(str)>=minTime){
                    callback('投注截止时间必须是彩票实际停售到开奖（19:00~21:15）之外的时间')
                }else{
                    callback();
                }
            };
            return{
                visible:false,
                dataForm:{
                    submitOrderTimeout:'',
                    acceptOrderTime:'',
                    ticketOrderTimeout:'',
                },
                dataRule:{
                    submitOrderTimeout:[{required: true, message: '投注截止时间必填', trigger: 'blur'},{validator:dataRule, trigger: 'blur'}],
                    acceptOrderTime:[{required: true, message: '接单(出票)开始时间必填', trigger: 'blur'},{validator:dataRule, trigger: 'blur'}],
                    ticketOrderTimeout:[{required: true, message: '接单(出票)截止时间', trigger: 'blur'},{validator:dataRule, trigger: 'blur'}],
                },
                startTime:'',
                endTime:''
            }
        },
        methods:{
            handleChange(){
                this.startTime = this.dataForm.submitOrderTimeout.substring(0,2)+this.dataForm.submitOrderTimeout.substring(3,5)+this.dataForm.submitOrderTimeout.substring(6,);
                this.endTime = this.dataForm.ticketOrderTimeout.substring(0,2)+this.dataForm.ticketOrderTimeout.substring(3,5)+this.dataForm.ticketOrderTimeout.substring(6,);
                if(Number(this.startTime)>=Number(this.endTime)){
                    this.$message.error('投注截止时间不能晚于接单(出票)截止时间');
                    return false;
                }
            },
            init(){
                this.visible = true;
                this.$get(apiPage.api.baseConfigInfo).then((data) => {
                    if(data.code == 0){
                        this.dataForm = data.info;
                    }
                })
            },
            dataFormSubmit(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        if(this.startTime >= this.endTime){
                            this.handleChange();
                        }else{
                            this.$post(apiPage.api.baseConfigUpdate,this.dataForm).then((data) => {
                                if(data.code == 0){
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 1500,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList')
                                        }
                                    })
                                } else {
                                    this.$message.error(data.msg);
                                }
                            })
                        }


                    }
                });
            },
        },
        created() {
        }
    }
</script>

<style scoped>

</style>