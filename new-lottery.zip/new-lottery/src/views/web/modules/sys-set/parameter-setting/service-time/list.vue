<template>
    <div>
        <p>说明：委托服务时间影响终端彩民的委托服务及投注站出票工作，请谨慎操作</p>
        <el-table
                :data="dataList"
                border
                style="width:100%">
            <el-table-column
                    prop="submitOrderTimeout"
                    header-align="center"
                    align="center"
                    label="投注截止时间">
            </el-table-column>
            <el-table-column
                    prop="acceptOrderTime"
                    header-align="center"
                    align="center"
                    label="接单（出票）开始时间">
            </el-table-column>
            <el-table-column
                    prop="ticketOrderTimeout"
                    header-align="center"
                    align="center"
                    label="接单（出票）截止时间">
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.id)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>

        <add-or-update ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update>
    </div>
</template>

<script>
    import apiPage  from '@/api'
    import AddOrUpdate from './update-handle'
    export default {
        name: "list",
        data(){
            return{
                dataList:[],
                dataListSelections:[],
                pageIndex: 1,
                pageSize: 10,
                totalPage: 0,
            }
        },
        components:{
            AddOrUpdate
        },
        methods:{
            addOrUpdateHandle(id){
                this.$nextTick(() =>{
                    this.$refs.addOrUpdate.init(id);
                })
            },
            getDataList(){
                this.$get(apiPage.api.baseConfigInfo).then((data) => {
                    if(data.code == 0){
                        this.dataList = [data.info];
                    }
                })
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>