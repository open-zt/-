<template>
    <el-dialog
            :title="!this.dataForm.id?'新增彩票休市时间':'修改彩票休市时间'"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            width="30%"
            :visible.sync="visible">

        <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="100px">
            <el-form-item label="休市原因" prop="name">
                <el-input v-model="dataForm.name" placeholder="比如:春节"></el-input>
            </el-form-item>
            <el-form-item label="休市时间段" prop="startDate">
                <el-date-picker
                        v-model="dataForm.startDate"
                        type="daterange"
                        format="yyyy - MM - dd"
                        value-format="yyyy-MM-dd"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="dataFormSubmit()">确 定</el-button>
            </span>

    </el-dialog>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "new-handle",
        data(){
            return{
                visible:false,
                title:'',
                dataForm:{
                    id:'',
                    name:'',
                    startDate:'',
                    endDate:'',
                },
                dataRule:{
                    name:[{required: true,message: '休市原因必填', trigger: 'blur'}],
                    startDate:[{required: true,message: '休市时间段必填', trigger: 'blur'}]
                },
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.dataForm.id = id;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                });

                if(this.dataForm.id){
                    this.$get(apiPage.api.sysCycleInfo + this.dataForm.id).then((data) =>{
                        if(data.code == 0){
                            this.dataForm = data.cycle;
                            this.dataForm.startDate = [data.cycle.startDate,data.cycle.endDate];
                        }
                    })
                }
            },
            dataFormSubmit(){
                let request = {
                    'id':this.dataForm.id,
                    'name':this.dataForm.name,
                    'startDate':this.dataForm.startDate[0],
                    'endDate':this.dataForm.startDate[1]
                };
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.$post(apiPage.api.sysCycleSave + `${!this.dataForm.id ?'save':'update'}`,request).then((data) => {
                            if(data.code == 0){
                                this.dataForm.id = data.id;
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 1500,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList');
                                    }
                                })
                            } else {
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            }

        },
        created() {

        }
    }
</script>

<style scoped>

</style>