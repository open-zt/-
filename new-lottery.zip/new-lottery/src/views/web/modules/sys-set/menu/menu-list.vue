<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
        </div>
        <el-table
                :data="dataList"
                border
                style="width:100%"
                row-key="menuId"
                :tree-props="{children: 'list'}">
            <el-table-column
                    prop="name"
                    header-align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="icon"
                    header-align="center"
                    align="center"
                    label="图标">
            </el-table-column>
            <el-table-column
                    prop="type"
                    header-align="center"
                    align="center"
                    label="类型">
                <template slot-scope="scope">
                    <el-tag v-if="scope.row.type === 0" size="small">目录</el-tag>
                    <el-tag v-else-if="scope.row.type === 1" size="small" type="success">菜单</el-tag>
                    <el-tag v-else-if="scope.row.type === 2" size="small" type="info">按钮</el-tag>
                </template>
            </el-table-column>
            <el-table-column
                    prop="url"
                    header-align="center"
                    align="center"
                    label="路径">
            </el-table-column>
            <el-table-column
                    prop="perms"
                    header-align="center"
                    align="center"
                    label="权限">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" v-if="scope.row.status != 2" @click="addOrUpdateHandle(scope.row.menuId)">编辑</el-button>
                    <el-button type="text" size="small" disabled @click="removeHandle(scope.row.menuId,scope.row.name)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!-- 弹窗, 新增 / 修改 -->
        <add-or-update v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getMenuList1"></add-or-update>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import AddOrUpdate from './add-or-update'
    export default {
        data(){
            return{
                dataList:[],
                addOrUpdateVisible:false,
            }
        },
        components: {
            AddOrUpdate
        },
        methods:{
            addOrUpdateHandle(id) {
                this.addOrUpdateVisible = true;
                this.$nextTick(() => {
                    this.$refs.addOrUpdate.init(id);
                })
            },
            getMenuList(){
                this.$get(apiPage.api.menuList).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.menuList;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            getMenuList1(){
                this.$get(apiPage.api.menuList).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.menuList;
                        this.$router.go(0)
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            removeHandle(id,name){
                let request = {
                    "menuId":id
                }
                this.$confirm(`确定对[${name}]进行[删除]操作?`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$post(apiPage.api.menuRemove,request).then((data) => {
                        if (data.code == 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getMenuList()
                                }
                            })
                        } else {
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {
                })
            }
        },
        created() {
            this.getMenuList();
        }
    }
</script>

<style scoped>

</style>