<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="创建时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="操作账号">
                <el-input v-model="dataForm.username" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="日志内容">
                <el-input v-model="dataForm.operation" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="dataList"
                style="width:100%"
                border>
            <el-table-column
                    prop="gmtCreate"
                    header-align="center"
                    align="center"
                    label="创建时间">
            </el-table-column>
            <el-table-column
                    prop="username"
                    header-align="center"
                    align="center"
                    label="操作账号">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="操作者">
            </el-table-column>
            <el-table-column
                    prop="ip"
                    header-align="center"
                    align="center"
                    label="IP地址">
            </el-table-column>
            <el-table-column
                    prop="operation"
                    header-align="center"
                    align="center"
                    label="日志内容">
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "list",
        data(){
            return{
                dataForm:{
                    startTime:'',
                    endTime:'',
                    username:'',
                    operation:'',
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            clear(){
              this.dataForm = {
                  startTime:'',
                  endTime:'',
                  username:'',
                  operation:'',
              };
              this.getDataList();
            },
            getDataList(){
                let request = {
                    'startTime':this.dataForm.startTime[0],
                    'endTime':this.dataForm.startTime[1],
                    'username':this.dataForm.username,
                    'operation':this.dataForm.operation,
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.logList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>