<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
            <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="角色名称">
                <el-input v-model="dataForm.roleName" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="roleName"
                    header-align="center"
                    align="center"
                    label="角色名称">
            </el-table-column>
            <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="角色状态">
                <template slot-scope="scope">
                    <p v-if="scope.row.status == 0">无效</p>
                    <p v-if="scope.row.status == 1">有效</p>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.roleId)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <add-or-update-handle ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import addOrUpdateHandle from './add-or-update'
    export default {
        data(){
            return{
                dataListSelections:[],
                dataList:[],
                dataForm:{
                    roleName:'',
                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        components:{
            addOrUpdateHandle
        },
        methods:{
            addOrUpdateHandle(id){
                this.$nextTick(() => {
                    this.$refs.addOrUpdate.init(id);
                })
            },
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'roleName':this.dataForm.roleName,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.roleList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            deleteHandle(id) {
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.roleId
                });
                let request = {
                    'ids': ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.roleBatchRemove, request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 3000,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        } else {
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>