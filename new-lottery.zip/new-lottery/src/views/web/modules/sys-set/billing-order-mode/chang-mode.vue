<template>
    <div>
        <el-dialog
                title="变更模式提示"
                :visible.sync="visible"
                width="30%">
            <div class="red" :style="{textAlign:'center'}">
                <p>模式变更后不可恢复，请您确认本省即开票订购模式需要变更再进行此操作</p>
                <p>即开票模式变更后 ，该系统与即开票相关的业务功能将发生显著变化</p>
                <p>主要变化如下：</p>
                <p>• 即开票信息的维护方式</p>
                <p>• 即开票订单的管理方式</p>
                <p>• 投注站/渠道订购即开票的方式</p>
                <p>您确定要变更当前的订购模式吗？</p>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visible = false">取 消</el-button>
                <el-button type="primary" @click="submit">确定并进行下一步</el-button>
          </span>
        </el-dialog>

        <el-dialog
                title="变更模式提示"
                :visible.sync="visibleMode"
                width="30%">
            <div>
                <p>当前模式：<span class="black" :style="{fontSize:18+ 'px'}">向省（自治区、直辖市）、市（区）订购即开票</span></p>
                <p>该模式下，省（自治区、直辖市）需自行维护即开票信息、管理即开票订单</p>
                <p>变更模式：<span class="red" :style="{fontSize:18+ 'px'}">向国家中心订购即开票</span></p>
                <p>该模式下，省（自治区、直辖市）可查看即开票信息及销售单位的即开票订单</p>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visibleMode = false">取 消</el-button>
                <el-button type="primary" @click="confirmChange">确定变更</el-button>
          </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "chang-mode",
        data(){
            return{
                visible:false,
                visibleMode:false,
            }
        },
        methods:{
            init(){
                this.visible = true;
            },
            submit(){
                this.visible = false;
                this.visibleMode = true;
            },
            confirmChange(){
                alert(124)
            }
        }
    }
</script>

<style scoped>

</style>