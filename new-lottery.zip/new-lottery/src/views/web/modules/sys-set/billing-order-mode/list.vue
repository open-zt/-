<template>
    <div>
        <p>模式说明：</p>
        <p class="black">1. 向省（自治区、直辖市）、市（区）订购即开票</p>
        <p>如果省（自治区、直辖市）直接向下属销售单位供应即开票，则选择该模式</p>
        <p> 该模式下，省（自治区、直辖市）需自行维护即开票信息、管理即开票订单</p>
        <p class="black">2. 向国家中心订购即开票</p>
        <p>如果省（自治区、直辖市）下属销售单位直接向国家中心订购即开票，则选择该模式</p>
        <p>该模式下，省（自治区、直辖市）可查看即开票信息及销售单位的即开票订单</p>
        <el-table
                :data="dataList"
                style="width:100%"
                border>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="当前模式">
            </el-table-column>
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    label="生效时间">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="changeMode()">变更模式</el-button>
                </template>
            </el-table-column>
        </el-table>
        <change-mode ref="changeMode"></change-mode>
    </div>
</template>

<script>
    import ChangeMode from './chang-mode'

    export default {
        name: "list",
        data(){
            return{
                dataList:[
                    {
                        name:'向省（自治区、直辖市）、市（区）订购即开票',
                        createTime:'2019-12-05 15:12:00'
                    }
                ],
            }
        },
        components: {
            ChangeMode
        },
        methods:{
            changeMode(){
                this.$nextTick(() => {
                    this.$refs.changeMode.init();
                })
            },
        }
    }
</script>

<style scoped>

</style>