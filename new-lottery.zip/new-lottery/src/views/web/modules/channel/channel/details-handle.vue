<template>
    <el-dialog
            class="dialog-con"
            title="渠道详情"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            :visible.sync="detailVisible">

        <el-form :model="dataForm"  ref="dataForm" label-width="110px">
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="名称">
                        <span>{{dataForm.name}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="渠道类型">
                        <span>{{dataForm.channelName}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="渠道返利">
                        <span>{{dataForm.rebate}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="负责人">
                        <span>{{dataForm.managerMan}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="联系方式">
                        <span>{{dataForm.tel}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="地区">
                        <span>{{dataForm.geoAddress}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="详细地址">
                        <span>{{dataForm.address}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="营业执照">
                        <el-image style="width: 100px; height: 100px;margin-right: 10px;"  :src="url"></el-image>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <p class="black">合同编号</p>
            </el-row>
            <el-row>
                <el-col :span="12">
                    <el-form-item label="合同编号">
                        <span>{{dataForm.contractNo}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="20">
                    <el-form-item label="合同文件">
                        <span class="pointer" @click="downFile">{{dataForm.contractFile}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <p class="black">渠道执行人</p>
            </el-row>
            <el-row>
                <el-col>
                    <el-table
                            border
                            style="width:100%"
                            :data="userList">
                        <el-table-column
                                prop="name"
                                header-align="center"
                                align="center"
                                label="姓名">
                        </el-table-column>
                        <el-table-column
                                prop="idCard"
                                header-align="center"
                                align="center"
                                label="身份证号">
                        </el-table-column>
                        <el-table-column
                                prop="sex"
                                header-align="center"
                                align="center"
                                label="性别">
                            <template slot-scope="scope">
                                <p v-if="scope.row.sex == 1">男</p>
                                <p v-if="scope.row.sex == 2">女</p>
                            </template>
                        </el-table-column>
                        <el-table-column
                                prop="mobile"
                                header-align="center"
                                align="center"
                                label="手机号">
                        </el-table-column>
                        <el-table-column
                                fixed="right"
                                header-align="center"
                                align="center"
                                label="操作"
                                width="150">
                            <template slot-scope="scope">
                                <el-button type="text" size="small" @click="userHandle(scope.row.userId)">详情</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
            </el-row>
        </el-form>
        <user-details ref="userDetails"></user-details>
    </el-dialog>
</template>

<script>
    import axios from 'axios'
    import apiPage from '@/api'
    import {getBaseUrl} from "@/util";
    import UserDetails from '../user-handle/user-details'
    export default {
        data(){
            return{
                detailVisible:false,
                dataForm:{
                    id:'',
                    userId:'',
                    contractFile:'',
                },
                url:'',
                userList:[],
            }
        },
        components:{UserDetails},
        methods:{
            downFile(){
                let request = {
                  'fileName':this.dataForm.contractFile
                };
                axios({
                    url:getBaseUrl() + apiPage.api.downloadFile,
                    method:'post',
                    responseType: 'blob',
                    data:request
                }).then((data) => {
                    console.log(data);
                    // window.location.href = window.URL.createObjectURL(new Blob([data], { type:'application/pdf'}))
                })
            },
            userHandle(userId){
                this.$nextTick(() => {
                    this.$refs.userDetails.init(userId);
                })
            },
            init(id,userId){
                this.detailVisible = true;
                this.dataForm.id = id;
                this.dataForm.userId = userId;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                });
                if(this.dataForm.id){
                    this.getDetails();
                    this.getUserDetails();
                }
            },
            getDetails(){
                this.$get(apiPage.api.channelInfo + this.dataForm.id).then((data) => {
                    if(data.code == 0){
                        this.dataForm = data.channel;
                        this.url = data.channel.businessLicense;
                        let url = data.channel.contractFile;
                        let num = url.lastIndexOf('/')+1;
                        let name = url.substr(num);
                        this.dataForm.contractFile = name;
                    }
                });
            },
            getUserDetails(){
                this.$get(apiPage.api.channelUserInfo + this.dataForm.userId).then((data) => {
                    if(data.code == 0){
                        this.userList = [data.channel];
                    }
                });
            },

        }
    }
</script>

<style scoped>

</style>