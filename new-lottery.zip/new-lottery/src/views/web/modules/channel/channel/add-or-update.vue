<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.id?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="submitFormData()" label-width="100px">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="名称" prop="name">
                            <el-input v-model="dataForm.name" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="渠道类型" prop="channelType">
                            <el-tooltip  effect="dark"  placement="bottom-start">
                                <div slot="content">A类渠道：只有渠道商可以订货，彩票中心直接向渠道商返利<br/> B类渠道：渠道商下面的子渠道商也可以订货，彩票中心按照返利规则分别返利</div>
                                <i class="el-icon-info pointer" style="position:relative;left:-10px;top:0"></i>
                            </el-tooltip>
                            <el-select v-model="dataForm.channelType">
                                <el-option v-for="item in channelTypeList" :key="item.id" :value="item.id" :label="item.name"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="渠道返利" prop="rebate">
                            <el-row>
                                <el-col :span="22">
                                    <el-input v-model="dataForm.rebate" placeholder="请输入"></el-input>
                                </el-col>
                                <el-col :span="2">
                                    %
                                </el-col>
                            </el-row>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="负责人" prop="managerMan">
                            <el-input v-model="dataForm.managerMan" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="联系方式" prop="tel">
                            <el-input v-model="dataForm.tel" placeholder="请输入手机号码"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="20">
                        <el-form-item prop="geo" label="地区">
                            <el-cascader
                                    placeholder="请选择省/市/区/街道"
                                    :options="geoList"
                                    :clearable="true"
                                    filterable
                                    style="width:100%"
                                    v-model="dataForm.geoList"
                                    @change="handleCurrent"
                            ></el-cascader>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="20">
                        <el-form-item prop="address" label="详细地址">
                            <el-input v-model="dataForm.address" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="营业执照" prop="businessLicense">
                            <el-upload
                                    list-type="picture-card"
                                    :action="imgUrl"
                                    :multiple="true"
                                    :limit="1"
                                    :file-list="file"
                                    :before-upload="beforeUploadHandle"
                                    :on-remove="handleRemove"
                                    :on-success="handleSuccess"
                                    :on-preview="preview">
                                <el-button type="text">上传图片</el-button>
                                <div slot="tip" class="el-upload__tip">注：支持png、jpg、jpeg格式的图片</div>
                            </el-upload>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <p class="black">合同编号</p>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="合同编号" prop="contractNo">
                            <el-input v-model="dataForm.contractNo" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="合同文件" prop="contractFile">
                            <el-upload
                                    :drag="true"
                                    :action="FileUrl"
                                    :limit="1"
                                    :file-list="contractFile"
                                    :before-upload="beforeHandleFile"
                                    :on-remove="handleRemoveFile"
                                    :on-success="successHandleFile"
                                    :on-preview="previewFile"
                            >
                                <i class="el-icon-upload"></i>
                                <div class="el-upload__text">将文件拖到此处，或<em>点此上传文件</em><br/>请上传 pdf 类型的文件</div>
                            </el-upload>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <p class="black">渠道执行人</p>
                </el-row>
                <el-row>
                    <el-col :span="9">
                        <el-form-item label="姓名" prop="userId">
                            <el-select v-model="dataForm.userId" filterable @change="HandleChange">
                                <el-option v-for="item in channelUsersList" :key="item.userId" :value="item.userId" :label="item.nameIdCard"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="3">
                        <div style="margin-top: 12px;" class="pointer" @click="userAddOrUpdate('')">
                            <i class="el-icon-plus"></i>新建
                        </div>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col>
                        <el-table
                                border
                                style="width:100%"
                                v-if="tableVisible"
                                :data="userList">
                            <el-table-column
                                    prop="name"
                                    header-align="center"
                                    align="center"
                                    label="姓名">
                            </el-table-column>
                            <el-table-column
                                    prop="idCard"
                                    header-align="center"
                                    align="center"
                                    label="身份证号">
                            </el-table-column>
                            <el-table-column
                                    prop="sex"
                                    header-align="center"
                                    align="center"
                                    label="性别">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sex == 1">男</p>
                                    <p v-if="scope.row.sex == 2">女</p>
                                </template>
                            </el-table-column>
                            <el-table-column
                                    prop="mobile"
                                    header-align="center"
                                    align="center"
                                    label="手机号">
                            </el-table-column>
                            <el-table-column
                                    fixed="right"
                                    header-align="center"
                                    align="center"
                                    label="操作"
                                    width="150">
                                <template slot-scope="scope">
                                    <el-button type="text" size="small" @click="userAddOrUpdate(scope.row.userId)">编辑</el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="visible = false">取 消</el-button>
                <el-button type="primary" v-if="this.dataForm.id" @click="stopHandle()">终止合作</el-button>
                <el-button type="primary" @click="submitFormData()" :disabled="isDisable">确 定</el-button>
            </span>
            <el-dialog :visible.sync="dialogVisible" append-to-body>
                <img width="100%" :src="dialogImageUrl" alt="">
            </el-dialog>
        </el-dialog>


        <el-dialog
                title="提示"
                width="30%"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="saveVisible">
            <p>系统账号：{{userName}}</p>
            <p>初始密码：{{passWord}}</p>
        </el-dialog>

        <user-handle ref="userHandle" @refreshDataList="getChannelUsers"></user-handle>
        <details-handle ref="detailsHandle"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import {getBaseUrl} from "@/util";
    import UserHandle from '../user-handle/user-handle'
    import detailsHandle from './details-handle'
    import {mobileRule,numberRule} from "@/util/validate";

    export default {
        data(){
            const nameRule = (rule,value,callback) => {
                let request = {
                    id:this.dataForm.id,
                    verifyParam:this.dataForm.name
                };
                this.$post(apiPage.api.verifyChannelName,request).then((data) =>{
                    if(data.code == 500){
                        callback(data.msg);
                    }else{
                        callback();
                    }
                }).catch(() => {
                    callback(new Error('服务异常'));
                })
            };
            const contractNoRule = (rule,value,callback) => {
                let request = {
                    id:this.dataForm.id,
                    verifyParam:this.dataForm.contractNo
                };
                this.$post(apiPage.api.verifyContractNo,request).then((data) =>{
                    if(data.code == 500){
                        callback(data.msg);
                    }else{
                        callback();
                    }
                }).catch(() => {
                    callback(new Error('服务异常'));
                })
            };
            const userIdRule = (rule,value,callback) => {
                let request = {
                    channelId:this.dataForm.id,
                    userId:this.dataForm.userId
                };
                this.$post(apiPage.api.verifyChannelUser,request).then((data) =>{
                    if(data.code == 500){
                        callback(data.msg);
                    }else if(data.code == 1){
                        this.dataForm.isChange = 1;
                        callback();
                    }else if(data.code == 0){
                        this.dataForm.isChange = 0;
                        callback();
                    }
                }).catch(() => {
                    callback(new Error('服务异常'));
                })
            };
            return{
                visible:false,
                saveVisible:false,
                isDisable:false,
                tableVisible:false,
                userList:[],
                imgLength:0,
                pdfLength:0,
                imgUrl:'',
                FileUrl:'',
                file:[],//营业执照图片
                contractFile:[],//合同文件pdf
                geoList:[],
                userName:'',
                passWord:'',
                dataForm:{
                    id:'',
                    name:'',
                    channelType:'',
                    rebate:'',
                    managerMan:'',
                    tel:'',
                    geo:'',
                    geoList:[],
                    address:'',
                    businessLicense:'', //营业执照
                    contractNo:'',
                    contractFile:'',//合同文件
                    userId:'',
                    isChange:0,
                },
                dataRule:{
                    name:[{required: true, message: '名称必填', trigger: 'blur'},{validator:nameRule, trigger: 'blur'}],
                    channelType:[{required: true, message: '渠道类型必填', trigger: 'blur'}],
                    rebate:[{required: true, message: '渠道返利必填', trigger: 'blur'},{validator:numberRule, trigger: 'blur'}],
                    managerMan:[{required: true, message: '负责人必填', trigger: 'blur'}],
                    tel:[{required: true, validator:mobileRule, trigger: 'blur'}],
                    geo:[{required: true, message: '地区必填', trigger: 'blur'}],
                    address:[{required: true, message: '详细地址必填', trigger: 'blur'}],
                    businessLicense:[{required: true, message: '营业执照必填', trigger: 'blur'}],
                    contractNo:[{required: true, message: '合同编号必填', trigger: 'blur'},{validator:contractNoRule, trigger: 'blur'}],
                    // contractFile:[{required: true, message: '合同文件必填', trigger: 'blur'}],
                    userId:[{required: true, message: '姓名必填', trigger: 'blur'},{validator:userIdRule, trigger: 'blur'}],
                },
                channelTypeList:[],
                channelUsersList:[],
                dialogImageUrl: '',
                dialogVisible: false,
            }
        },
        components:{UserHandle,detailsHandle},
        methods:{
            handleCurrent(value){
                if (value != null && value.length > 0) {
                    this.dataForm.geo = value[value.length - 1];
                }
            },
            HandleChange(value){
                if(this.dataForm.id){
                    this.$confirm('<p style="color:red">渠道执行人变更后，渠道账号密码将恢复为初始密码 123456 原渠道执行人将无法使用旧密码登录系统，请您谨慎执行此操作</p>当前您确定变更渠道执行人吗？', '提示', {
                        dangerouslyUseHTMLString: true,
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        center: true
                    }).then(() => {
                        this.$get(apiPage.api.channelUserInfo + value).then((data) =>{
                            if(data.code == 0){
                                this.tableVisible = true;
                                this.userList = [data.channel];
                            }
                        })
                    }).catch(() => {

                    });
                }else{
                    this.$get(apiPage.api.channelUserInfo + value).then((data) =>{
                        if(data.code == 0){
                            this.tableVisible = true;
                            this.userList = [data.channel];
                        }
                    })
                }
            },
            userAddOrUpdate(userId){
                this.$nextTick(() => {
                    this.$refs.userHandle.init(userId);
                })
            },
            init(id){
                this.visible = true;
                this.dataForm.id = id;
                this.isDisable=false;
                this.tableVisible = false;
                this.imgUrl = getBaseUrl() + apiPage.api.sysFileUpload;
                this.FileUrl = getBaseUrl() + apiPage.api.uploadFile;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.dataForm.geoList = [];
                    this.file = [];
                    this.contractFile = [];
                    this.userList = [];
                });


                this.getGeoList();
                this.getChannelType();
                // this.getChannelUsers();
                this.getUserList();

                if(this.dataForm.id){
                    this.$get(apiPage.api.channelInfo + this.dataForm.id).then((data) =>{
                        if(data.code == 0){
                            this.dataForm = data.channel;
                            if(data.channel.businessLicense){
                                this.file = [{url:data.channel.businessLicense}];
                                // this.imgLength = this.file.length;
                                // let elUpload = document.querySelector('.el-upload--picture-card');
                                // elUpload.style.display = 'none';
                            }
                            if(data.channel.contractFile){
                                let url = data.channel.contractFile;
                                let num = url.lastIndexOf('/')+1;
                                let name = url.substr(num);
                                this.contractFile = [{name: name,url:data.channel.contractFile}];
                                // this.pdfLength = this.contractFile.length;
                                // let fileUpload = document.querySelector('.el-upload--text');
                                // fileUpload.style.display = 'none';
                            }

                        }
                    })
                }
            },
            getGeoList(){
                this.$get(apiPage.api.agentGeoList).then((data) => {
                    if(data.code == 0){
                        this.geoList = data.list;
                    }
                });
            },
            getChannelType(){
                this.$get(apiPage.api.channelType).then((data) => {
                    if(data.code == 0){
                        this.channelTypeList = data.list;
                    }
                })
            },
            getUserList(){
                this.$get(apiPage.api.channelUsers).then((data) => {
                    if(data.code == 0){
                        this.channelUsersList = data.list;
                    }
                })
            },
            getChannelUsers(id){
                this.$get(apiPage.api.channelUsers).then((data) => {
                    if(data.code == 0){
                        this.channelUsersList = data.list;
                        this.dataForm.userId = id;
                        this.HandleChange(this.dataForm.userId);
                    }
                })
            },
            stopHandle(){
                this.$confirm('<p style="color:red">须由省中心批示同意后才可终止与渠道的合作关系终止后，渠道将无法使用该系统且不可恢复，请您谨慎执行此操作</p>当前您确定需要终止与该渠道的合作吗？', '提示', {
                    dangerouslyUseHTMLString: true,
                    confirmButtonText: '确定终止',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.stopChannel + this.dataForm.id).then((data) =>{
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.visible = false;
                                    this.$emit('refreshDetails',this.dataForm.id,this.dataForm.userId)
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消终止合作'
                    });
                });
            },
            submitFormData(){
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        this.isDisable = true;
                        this.$post(apiPage.api.channelSave + `${!this.dataForm.id ?'save':'update'}`,this.dataForm).then((data) => {
                            if(data.code == 0){
                                if(this.dataForm.id){
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 800,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList')
                                        }
                                    });
                                }else{
                                    this.userName = data.accountInfo.username;
                                    this.passWord = data.accountInfo.password;
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 800,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList')
                                        }
                                    });
                                    this.saveVisible = true;
                                }
                            } else {
                                this.isDisable = false;
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            },
            beforeUploadHandle(file){
                if (file.type !== 'image/jpg' && file.type !== 'image/jpeg' && file.type !== 'image/png') {
                    this.$message.error('只支持jpg、jpeg、png格式的图片！');
                    return false;
                }
            },
            handleRemove(file,fileList){
               if( file && file.status==="success"){
                   this.$message({
                       message: '已删除营业执照照片',
                       type: 'info',
                       duration: 1000
                   });
                   this.file = fileList;
                   this.imgLength--;
                   if(this.imgLength == 0){
                       let elUpload = document.querySelector('.el-upload--picture-card');
                       elUpload.style.display = 'block';
                   }
               }
            },
            handleSuccess(res){
                if(res.code == 0){
                    this.dataForm.businessLicense = res.fileUrl;
                    this.imgLength++;
                    if(this.imgLength == 1){
                        let elUpload = document.querySelector('.el-upload--picture-card');
                        elUpload.style.display = 'none';
                    }
                }
            },
            beforeHandleFile(file){
                if (file.type !== 'application/pdf') {
                    this.$message.error('只支持pdf格式的文件！');
                    return false;
                }
            },
            successHandleFile(res){
                if(res.code == 0){
                    this.dataForm.contractFile = res.fileUrl;
                    this.pdfLength++;
                    if(this.pdfLength == 1){
                        let fileUpload = document.querySelector('.el-upload--text');
                        fileUpload.style.display = 'none';
                    }
                }
            },
            previewFile(file){
                if(this.dataForm.id){
                    window.open(file.url)
                }else{
                    window.open(file.response.fileUrl)
                }
            },
            handleRemoveFile(file,fileList){
                if( file && file.status==="success"){
                    this.$message({
                        message: '已删除合同文件',
                        type: 'info',
                        duration: 1000
                    });
                    this.contractFile = fileList;
                    this.pdfLength--;
                    if(this.pdfLength == 0){
                        let fileUpload = document.querySelector('.el-upload--text');
                        fileUpload.style.display = 'block';
                    }
                }
            },
            preview(file) {
                this.dialogImageUrl = file.url;
                this.dialogVisible = true;
            },
        }
    }
</script>

<style>
    .el-upload-dragger .el-icon-upload{
        margin:16px 0!important;
    }
</style>