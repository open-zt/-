<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary"  @click="addOrUpdateHandle()">新增</el-button>
            <el-button type="primary">导入</el-button>
            <el-button type="primary" :disabled="dataListSelections.length <= 0" @click="deleteHandle()">删除</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="名称">
                <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="渠道类型">
                <el-select v-model="dataForm.channelType">
                    <el-option v-for="item in channelTypeList" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="状态">
                <el-select v-model="dataForm.status">
                    <el-option value="0" label="终止合作"></el-option>
                    <el-option value="1" label="合作"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="typeName"
                    header-align="center"
                    align="center"
                    label="渠道类型">
            </el-table-column>
            <el-table-column
                    prop="rebate"
                    header-align="center"
                    align="center"
                    label="渠道返点">
            </el-table-column>
            <el-table-column
                    prop="managerMan"
                    header-align="center"
                    align="center"
                    label="负责人">
            </el-table-column>
            <el-table-column
                    prop="userName"
                    header-align="center"
                    align="center"
                    label="执行人">
            </el-table-column>
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="渠道账号">
                <template slot="header">
                    <el-tooltip class="item" effect="dark" content="默认初始密码 123456" placement="bottom-end">
                        <p class="pointer">渠道账号<i class="el-icon-info"></i></p>
                    </el-tooltip>
                </template>
            </el-table-column>
            <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="状态">
                <template slot-scope="scope">
                    <p v-if="scope.row.status == 0">终止合作</p>
                    <p v-if="scope.row.status == 1">合作</p>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="150">
                <template slot-scope="scope">
                    <el-button type="text" size="small" v-if="!scope.row.status == 0" @click="addOrUpdateHandle(scope.row.id)">编辑</el-button>
                    <el-button type="text" size="small" v-if="scope.row.status == 0" @click="detailsHandle(scope.row.id,scope.row.userId)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <add-or-update ref="AddOrUpdate" @refreshDataList="getDataList"  @refreshDetails="getVisible"></add-or-update>
        <details-handle ref="detailsHandle"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import AddOrUpdate from './add-or-update'
    import DetailsHandle from './details-handle'
    export default {
        components: {DetailsHandle, AddOrUpdate},
        data(){
            return{
                dataListSelections:[],
                dataList:[],
                dataForm:{
                    name:'',
                    channelType:'',
                    status:''
                },
                channelTypeList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        methods:{
            getVisible(id,userId){
                this.$refs.detailsHandle.init(id,userId);
                this.getDataList();
            },
            handleSelectionChange(val){
                this.dataListSelections = val;
            },
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            addOrUpdateHandle(id){
                this.$nextTick(() =>{
                    this.$refs.AddOrUpdate.init(id);
                })
            },
            detailsHandle(id,userId){
                this.$nextTick(()  => {
                    this.$refs.detailsHandle.init(id,userId);
                })
            },
            getChannelType(){
                this.$get(apiPage.api.channelType).then((data) => {
                    if(data.code == 0){
                        this.channelTypeList = data.list;
                    }
                })
            },
            getDataList(){
                let request = {
                    'name':this.dataForm.name,
                    'channelType':this.dataForm.channelType,
                    'status':this.dataForm.status,
                    'current':this.pageIndex,
                    'size':this.pageSize,
                };
                this.$get(apiPage.api.channelList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            deleteHandle(id){
                let status = '';
                this.dataListSelections.map((item) => {
                   status = item.status
                });
                if(status === 1){
                    this.$alert('<p>您只能删除“终止合作”的渠道，当前选择的渠道中包含正在“合作”的渠道，如果您想删除该渠道，请先【终止合作】</br>渠道的合作状态请在列表“状态”处查看</p>', '提示', {
                        dangerouslyUseHTMLString: true,
                        center: true,
                        showConfirmButton:false,
                    }).then(() => {
                        this.$message({
                            type: 'success',
                            message: '删除成功!'
                        });
                    }).catch(() => {

                    });
                }else if(status === 0){
                    var ids = id ? [id] : this.dataListSelections.map(item => {
                        return item.id
                    });
                    let request = {
                        'ids': ids
                    };
                    this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        center: true
                    }).then(() => {
                        this.$post(apiPage.api.channelRemove, request).then((data) => {
                            if (data && data.code === 0) {
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 3000,
                                    onClose: () => {
                                        this.getDataList();
                                    }
                                })
                            } else {
                                this.$message.error(data.msg)
                            }
                        });
                    }).catch(() => {

                    });
                }
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getChannelType();
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>