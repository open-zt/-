<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.userId?'新增渠道执行人':'编辑渠道执行人'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="submitFormData()" label-width="80px">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="姓名" prop="name">
                            <el-input v-model="dataForm.name" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="身份证号" prop="idCard">
                            <el-input v-model="dataForm.idCard" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item prop="sex" label="性别">
                            <el-select v-model="dataForm.sex" placeholder="请选择">
                                <el-option value="1" label="男"></el-option>
                                <el-option value="2" label="女"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="手机号" prop="mobile">
                            <el-input v-model="dataForm.mobile" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()" :disabled="isDisable">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'

    export default {
        data(){
            const idCardRule = (rule,value,callback) =>{
                var reg = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
                let request = {
                    id:this.dataForm.userId,
                    verifyParam:this.dataForm.idCard
                };
                if (value === '') {
                    callback(new Error('身份证号必填'));
                } else if(!reg.test(value)) {
                    callback(new Error('请输入合法的身份证号'));
                }else if(request){
                    this.$post(apiPage.api.verifyOwnerUserIdCard,request).then((data) =>{
                        if(data.code == 500){
                            callback(data.msg);
                        }else{
                            callback();
                        }
                    }).catch(() => {
                        callback(new Error('服务异常'));
                    })
                }else{
                    callback();
                }
            };

            const mobileRule = (rule,value,callback) =>{
                var reg = /^1[0-9]{10}$/;
                let request = {
                    id:this.dataForm.userId,
                    verifyParam:this.dataForm.mobile
                };
                if (value === '') {
                    callback(new Error('手机号必填'));
                } else if(!reg.test(value)) {
                    callback(new Error('手机号不符合规则'));
                }else if(request){
                    this.$post(apiPage.api.verifyMobile,request).then((data) =>{
                        if(data.code == 500){
                            callback(data.msg);
                        }else{
                            callback();
                        }
                    }).catch(() => {
                        callback(new Error('服务异常'));
                    })
                }else{
                    callback();
                }
            };
            return{
                visible:false,
                isDisable:false,
                dataForm:{
                    userId:'',
                    name:'',
                    idCard:'',
                    sex:'',
                    mobile:'',
                },
                dataRule:{
                    name:[{required: true, message: '名称必填', trigger: 'blur'}],
                    idCard:[{required: true,validator:idCardRule, trigger: 'blur'}],
                    sex:[{required: true, message: '性别必填', trigger: 'blur'}],
                    mobile:[{required: true,validator:mobileRule, trigger: 'blur'}],
                },
            }
        },
        methods:{
            init(userId){
                this.visible = true;
                this.dataForm.userId = userId;
                this.isDisable = false;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                })

                if(this.dataForm.userId){
                    this.$get(apiPage.api.channelUserInfo + this.dataForm.userId).then((data) =>{
                        if(data.code == 0){
                            this.dataForm = data.channel;
                            if(data.channel.sex){
                                this.dataForm.sex = data.channel.sex.toString();
                            }
                        }
                    })
                }

            },
            submitFormData(){
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        this.isDisable = true;
                        this.$post(apiPage.api.channelUserSave + `${!this.dataForm.userId ?'save':'update'}`,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 800,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList',data.userId)
                                    }
                                });
                            } else {
                                this.isDisable = false;
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            },
        }
    }
</script>

<style scoped>

</style>