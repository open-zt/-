<template>
    <div>
        <el-dialog
                class="dialog-con"
                title="渠道执行人详情"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                append-to-body
                :visible.sync="visible">
            <el-form :model="dataForm"  ref="dataForm" label-width="80px">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="姓名" prop="name">
                            <span>{{dataForm.name}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="身份证号" prop="idCard">
                            <span>{{dataForm.idCard}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item prop="sex" label="性别">
                            <span v-if="dataForm.sex == 1">男</span>
                            <span v-if="dataForm.sex == 2">女</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="手机号" prop="mobile">
                            <span>{{dataForm.mobile}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        data(){
            return{
                visible:false,
                dataForm:{
                    userId:'',
                }
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.dataForm.userId = id;
                this.$get(apiPage.api.channelUserInfo + this.dataForm.userId).then((data) =>{
                    if(data.code == 0){
                        this.dataForm = data.channel;
                        if(data.channel.sex){
                            this.dataForm.sex = data.channel.sex.toString();
                        }
                    }
                })
            }
        }
    }
</script>

<style scoped>

</style>