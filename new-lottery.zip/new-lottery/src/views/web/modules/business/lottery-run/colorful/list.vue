<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
            <el-button type="primary" @click="exportExcel()" plain>导入</el-button>
            <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="期号">
                <el-input v-model="dataForm.cycle" placeholder="请输入期号" clearable></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
            :data="dataList"
            style="width:100%"
            border
            @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    label="开奖号码">
                <template slot-scope="scope">
                    <span>{{scope.row.red}},</span>
                    <span>{{scope.row.blue}}</span>
                </template>
            </el-table-column>
            <el-table-column
                    prop="cycle"
                    header-align="center"
                    align="center"
                    label="期号">
            </el-table-column>
            <el-table-column
                    prop="cycleDate"
                    header-align="center"
                    align="center"
                    label="开奖日期">
            </el-table-column>
            <el-table-column
                    prop="currentSalesAmount"
                    header-align="center"
                    align="center"
                    label="本期销售金额(元)">
            </el-table-column>
            <el-table-column
                    prop="nextFirstAmount"
                    header-align="center"
                    align="center"
                    label="下期奖池金额(元)">
            </el-table-column>
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    label="录入时间">
            </el-table-column>
            <el-table-column
                    prop="finishTime"
                    header-align="center"
                    align="center"
                    label="发布时间">
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="detailsHandle(scope.row.id)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <add-or-update ref="addOrUpdate"  @refreshDataList="getDataList"></add-or-update>
        <export-handle ref="exportHandle" @refreshDataList="getDataList"></export-handle>
        <details-handle ref="detailsHandle"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import addOrUpdate from './add-or-update'
    import exportHandle from './export-excel'
    import DetailsHandle from "./details-handle";
    export default {
        name: "list",
        data(){
            return{
                dataForm:{
                    cycle:'',
                },
                dataList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
                dataListSelections:[]
            }
        },
        components:{
            DetailsHandle,
            addOrUpdate,exportHandle
        },
        methods:{
            addOrUpdateHandle(id){
                this.$nextTick(() =>{
                    this.$refs.addOrUpdate.init(id);
                });
            },
            detailsHandle(id){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.view(id);
                });
            },
            exportExcel(){
                this.$nextTick(() => {
                    this.$refs.exportHandle.init();
                })
            },
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'cycle':this.dataForm.cycle,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                    'playType':3
                };
                this.$get(apiPage.api.lotteryList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            deleteHandle(id){
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.id
                });
                let request = {
                    'ids':ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.lotteryBatchRemove,request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>