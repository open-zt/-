<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.id?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="detailsHandle()" label-width="130px">
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="玩法">
                            <span>福彩3D</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="开奖号码" prop="redInfo">
                            <el-row>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo"></el-input>
                                </el-col>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo1" ref="reds1" ></el-input>
                                </el-col>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo2" ref="reds2" ></el-input>
                                </el-col>
                            </el-row>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="期号" prop="cycle">
                            <el-input v-model.trim="dataForm.cycle" placeholder="请输入期号"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="开奖日期" prop="cycleDate">
                            <el-date-picker
                                    v-model="dataForm.cycleDate"
                                    type="date"
                                    value-format="yyyy-MM-dd"
                                    placeholder="开奖日期">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="本期销售金额(元)" prop="currentSalesAmount">
                            <el-input v-model.trim="dataForm.currentSalesAmount" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="15">
                        <el-form-item label="本期中奖情况">
                            <el-table border :data="dataForm.winningSituation">
                                <el-table-column label="奖级" align="center" prop="award" header-align="center"></el-table-column>
                                <el-table-column label="中奖注数" align="center" header-align="center">
                                    <template slot-scope="scope">
                                        <el-form-item :prop="`winningSituation.${scope.$index}.num`" :rules='dataRule.winningSituation.num'>
                                            <el-input size="small" v-model.trim="scope.row.num" placeholder="请输入"></el-input>
                                        </el-form-item>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="amount" header-align="center" align="center" label="单注中奖金额(元)">
                                    <template slot-scope="scope">
                                        <el-form-item :prop="`winningSituation.${scope.$index}.amount`" :rules='dataRule.winningSituation.amount'>
                                            <el-input size="small" v-model.trim="scope.row.amount" :disabled="scope.row.disabled" placeholder="请输入"></el-input>
                                        </el-form-item>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="detailsHandle()" :disabled="isDisable">确 定</el-button>
            </span>
        </el-dialog>
        <details-handle ref="detailsHandle" @refreshDataList="getVisible"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import {number,cycleRule} from "@/util/validate";
    import DetailsHandle from './details-handle'

    export default {
        name: "add-or-update",
        components:{DetailsHandle},
        data(){
            var redsRule = (rule,value,callback) => {
                let reds1 = this.$refs.reds1.value;
                let reds2 = this.$refs.reds2.value;

                var myreg = /^[0-9]$/;
                if(value === ''){
                    callback(new Error('开奖号码必填'));
                }else if(!myreg.test(value)){
                    callback(new Error('开奖号码只能在0~9中取值'));
                }
                if(reds1 == undefined || reds1 === ''){
                    callback(new Error('开奖号码必填'));
                }else if(!myreg.test(reds1)){
                    callback(new Error('开奖号码只能在0~9中取值'));
                }
                if(reds2 == undefined || reds2 === ''){
                    callback(new Error('开奖号码必填'));
                }else if(!myreg.test(reds2)){
                    callback(new Error('开奖号码只能在0~9中取值'));
                }
                else{
                    callback();
                }
            };
            const cycleRule = (rule,value,callback) =>{
                var reg =/^[1-9]\d{6}$/;
                let request = {
                    id:this.dataForm.id,
                    playType:this.dataForm.playType,
                    verifyParam:this.dataForm.cycle
                };
                if (value === '') {
                    callback(new Error('期号必填'));
                } else if(!reg.test(value)) {
                    callback(new Error('期号为7位数字'));
                }else if(request){
                    this.$post(apiPage.api.verifyCycle,request).then((data) =>{
                        if(data.code == 500){
                            callback(data.msg);
                        }else{
                            callback();
                        }
                    }).catch(() => {
                        callback(new Error('服务异常'));
                    })
                }else{
                    callback();
                }
            };
            return{
                visible:false,
                isDisable:false,
                dataForm:{
                    redInfo:'',
                    redInfo1:'',
                    redInfo2:'',
                    reds:[],
                    playType:2,
                    id:'',
                    red:'',
                    blue:'',
                    cycle:'',
                    cycleDate:'',
                    currentSalesAmount:'',
                    nextFirstAmount:'0',
                    winningSituation: [
                        {
                            award:'单选',
                            num:'',
                            amount:'',
                        },
                        {
                            award:'组选3',
                            num:'',
                            amount:'',
                        },
                        {
                            award:'组选6',
                            num:'',
                            amount:'',
                        },
                    ],
                },
                dataRule:{
                    redInfo:[{required: true, validator:redsRule, trigger: 'blur'}],
                    cycle:[{ required: true,validator: cycleRule, trigger: 'blur' }],
                    cycleDate:[{required: true, message: '开奖日期必填', trigger: 'blur'}],
                    currentSalesAmount:[{required: true,validator: number,  trigger: 'blur'}],
                    winningSituation:{
                        num: [{required: true, message: '中奖注数必填',trigger: 'blur'}],
                        amount:[{required: true, message: '单注中奖金额必填',trigger: 'blur'}]
                    }
                },
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.isDisable=false;
                this.dataForm.id = id;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.dataForm.redInfo1 = '';
                    this.dataForm.redInfo2 = '';
                });
            },
            getVisible(){
                this.visible = false;
                this.$emit('refreshDataList')
            },
            detailsHandle(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.$refs.detailsHandle.init(this.dataForm);
                    }
                });
            }
        },
        created(){

        }
    }
</script>

<style scoped>
    .el-form-item .el-form-item{
        height: 58px;
    }
</style>
<style>

</style>