<template>
    <div class="form">
        <el-dialog
                class="dialog-con"
                title="提示"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">

            <div class="red" style="font-size: 16px;text-align: center;line-height: 24px;">新增后，开奖及中奖信息将推送至终端用户，为确保信息准确，防止利益纠纷<br/>请您确认以下信息无误后再进行新增</div>
            <el-form :model="dataForm"   ref="dataForm"  @keyup.enter.native="dataFormSubmit()" label-width="150px" :class="{line:isActive}">
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="玩法">
                            <span>双色球</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="开奖红球号码">
                            <span>{{dataForm.redInfo}},{{dataForm.redInfo1}},{{dataForm.redInfo2}},{{dataForm.redInfo3}},{{dataForm.redInfo4}},{{dataForm.redInfo5}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="开奖蓝球号码">
                            <span>{{dataForm.blue}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="期号">
                            <span>{{dataForm.cycle}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="开奖日期">
                            <span>{{dataForm.cycleDate}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="本期销售金额(元)">
                            <span>{{dataForm.currentSalesAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="下期奖池金额(元)">
                            <span>{{dataForm.nextFirstAmount}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="18">
                        <el-form-item label="本期中奖情况">
                            <el-table border :data="dataForm.winningSituation">
                                <el-table-column label="奖级" align="center" prop="award" header-align="center"></el-table-column>
                                <el-table-column label="中奖注数" align="center" header-align="center">
                                    <template slot-scope="scope">
                                        <el-form-item>
                                            <span>{{scope.row.num}}</span>
                                        </el-form-item>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="amount" header-align="center" align="center" label="单注中奖金额(元)">
                                    <template slot-scope="scope">
                                        <el-form-item>
                                            <span>{{scope.row.amount}}</span>
                                        </el-form-item>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="dataFormSubmit()" :disabled="isDisable">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "details-handle",
        data(){
            return{
                visible:false,
                isDisable:false,
                isActive:true,
                dataForm:{
                    id:'',
                },
            }
        },
        methods:{
            init(data){
                this.visible = true;
                this.dataForm = data;
            },
            view(id){
                this.visible = true;
                this.isActive = false;
                this.dataForm.id = id;
                if(this.dataForm.id){
                    this.$get(apiPage.api.lotteryInfo + this.dataForm.id).then((data) => {
                        if(data.code == 0){
                            this.dataForm = data.lottery;
                            let arr = data.lottery.red.split(',');
                            this.dataForm.redInfo = arr[0];
                            this.dataForm.redInfo1 = arr[1];
                            this.dataForm.redInfo2 = arr[2];
                            this.dataForm.redInfo3 = arr[3];
                            this.dataForm.redInfo4 = arr[4];
                            this.dataForm.redInfo5 = arr[5];
                            if(data.lottery.winningSituation == '' || data.lottery.winningSituation == null){
                                this.dataForm.winningSituation = [
                                    {
                                        award:'一等奖',
                                        num:'',
                                        amount:'',
                                        disabled:false,
                                    },
                                    {
                                        award:'二等奖',
                                        num:'',
                                        amount:'',
                                        disabled:false,
                                    },
                                    {
                                        award:'三等奖',
                                        num:'',
                                        amount:3000,
                                        disabled:true,
                                    },
                                    {
                                        award:'四等奖',
                                        num:'',
                                        amount:200,
                                        disabled:true,
                                    },
                                    {
                                        award:'五等奖',
                                        num:'',
                                        amount:10,
                                        disabled:true,
                                    },
                                    {
                                        award:'六等奖',
                                        num:'',
                                        amount:5,
                                        disabled:true,
                                    }]
                            }
                        }
                    })
                }
            },
            getCycle(){
                let request = {
                    "cycle":this.dataForm.cycle
                };
                this.$post(apiPage.api.lotteryWinningTask,request).then((data) => {
                    if(data.code == 0){
                        this.$message({
                            message: '操作成功',
                            type: 'success',
                            duration: 800,
                            onClose: () => {
                                this.visible = false;
                                this.$emit('refreshDataList')
                            }
                        });
                    }
                })
            },
            dataFormSubmit(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.isDisable = true;
                        this.dataForm.red = this.dataForm.redInfo +',' + this.dataForm.redInfo1 +',' + this.dataForm.redInfo2 +',' + this.dataForm.redInfo3 +',' + this.dataForm.redInfo4 +',' + this.dataForm.redInfo5;
                        this.dataForm.reds = this.dataForm.red.split(',');
                        this.dataForm.reds.sort((m,n) => {
                            return m-n;
                        });
                        let redList = '';
                        this.dataForm.reds.forEach((item) => {
                            redList += item + ','
                        });
                        this.dataForm.red = redList.substring(0,redList.length -1);
                        this.$post(apiPage.api.lotterySave + `${!this.dataForm.id ? 'save':'update'}`,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.getCycle();
                                this.isDisable = true;
                            } else {
                                this.isDisable = false;
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            }
        }
    }
</script>

<style scoped>
    .el-form-item .el-form-item{height:36px;}
    .form .el-form.line{
        border:1px solid #ccc;
    }
</style>