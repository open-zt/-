<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.id?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                :visible.sync="visible">
            <div class="red">新增后，开奖及中奖信息将推送至终端用户，请确保信息准确，防止利益纠纷</div>
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="detailsHandle()" label-width="130px">
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="玩法">
                            <span>双色球</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="开奖红球号码" prop="redInfo">
                            <el-row>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo"></el-input>
                                </el-col>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo1" ref="reds1" ></el-input>
                                </el-col>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo2" ref="reds2"></el-input>
                                </el-col>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo3" ref="reds3"></el-input>
                                </el-col>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo4" ref="reds4"></el-input>
                                </el-col>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.redInfo5" ref="reds5"></el-input>
                                </el-col>
                            </el-row>
                            <span>如果球号是一位数，请在球号前补0，如01</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="开奖蓝球号码" prop="blue">
                            <el-row>
                                <el-col :span="4">
                                    <el-input v-model.trim="dataForm.blue" ></el-input>
                                </el-col>
                            </el-row>
                            <span>如果球号是一位数，请在球号前补0，如01</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="期号" prop="cycle">
                            <el-input v-model.trim="dataForm.cycle" placeholder="请输入期号"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="开奖日期" prop="cycleDate">
                            <el-date-picker
                                    v-model="dataForm.cycleDate"
                                    type="date"
                                    value-format="yyyy-MM-dd"
                                    placeholder="开奖日期">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="本期销售金额(元)" prop="currentSalesAmount">
                            <el-input v-model.trim="dataForm.currentSalesAmount" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="下期奖池金额(元)" prop="nextFirstAmount">
                            <el-input v-model.trim="dataForm.nextFirstAmount" placeholder="请输入"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="18">
                        <el-form-item label="本期中奖情况">
                            <el-table border :data="dataForm.winningSituation">
                                <el-table-column label="奖级" align="center" prop="award" header-align="center"></el-table-column>
                                <el-table-column label="中奖注数" align="center" header-align="center">
                                    <template slot-scope="scope">
                                        <el-form-item :prop="`winningSituation.${scope.$index}.num`" :rules='dataRule.winningSituation.num'>
                                            <el-input size="small" v-model.trim="scope.row.num" placeholder="请输入"></el-input>
                                        </el-form-item>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="amount" header-align="center" align="center" label="单注中奖金额(元)">
                                    <template slot-scope="scope">
                                        <el-form-item :prop="`winningSituation.${scope.$index}.amount`" :rules='dataRule.winningSituation.amount'>
                                            <el-input size="small" v-model.trim="scope.row.amount" :disabled="scope.row.disabled" placeholder="请输入"></el-input>
                                        </el-form-item>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="detailsHandle()" :disabled="isDisable">确 定</el-button>
            </span>
        </el-dialog>
        <details-handle ref="detailsHandle" @refreshDataList="getVisible"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import {number,cycleRule} from '@/util/validate'
    import DetailsHandle from './details-handle'
    export default {
        name: "add-or-update",
        components:{DetailsHandle},
        data(){
            var blueRule = (rule,value,callback) => {
                var myreg = /^[0][1-9]$|^[1][0-6]$/;
                if (value === '') {
                    callback(new Error('蓝球必填'));
                } else if(!myreg.test(value)) {
                    callback(new Error('开奖蓝球号码只能在01~16中取值'));
                }else {
                    callback();
                }
            };
            var redsRule = (rule,value,callback) => {
                let reds1 = this.$refs.reds1.value;
                let reds2 = this.$refs.reds2.value;
                let reds3 = this.$refs.reds3.value;
                let reds4 = this.$refs.reds4.value;
                let reds5 = this.$refs.reds5.value;

                let redRuleList = [];
                redRuleList.push(value,reds1,reds2,reds3,reds4,reds5);
                let newRedRuleList = redRuleList.sort();

                for(var i = 0; i< redRuleList.length;i++){
                    if(newRedRuleList[i] == newRedRuleList[i+1]){
                        callback(new Error('开奖红球号码不能输入重复数字'));
                    }
                }

                var myreg = /^[0][1-9]$|^[1][0-9]$|^[2][0-9]$|^[3][0-3]$/;
                if(value === ''){
                    callback(new Error('红球必填'));
                }else if(!myreg.test(value)){
                    callback(new Error('开奖红球号码只能在01~33中取值'));
                }
                if(reds1 == undefined || reds1 === ''){
                    callback(new Error('红球必填'));
                }else if(!myreg.test(reds1)){
                    callback(new Error('开奖红球号码只能在01~33中取值'));
                }
                if(reds2 == undefined || reds2 === ''){
                    callback(new Error('红球必填'));
                }else if(!myreg.test(reds2)){
                    callback(new Error('开奖红球号码只能在01~33中取值'));
                }
                if(reds3 == undefined || reds3 === ''){
                    callback(new Error('红球必填'));
                }else if(!myreg.test(reds3)){
                    callback(new Error('开奖红球号码只能在01~33中取值'));
                }
                if(reds4 == undefined || reds4 === ''){
                    callback(new Error('红球必填'));
                }else if(!myreg.test(reds4)){
                    callback(new Error('开奖红球号码只能在01~33中取值'));
                }
                if(reds5 == undefined || reds5 === ''){
                    callback(new Error('红球必填'));
                }else if(!myreg.test(reds5)){
                    callback(new Error('开奖红球号码只能在01~33中取值'));
                }

                else{
                    callback();
                }
            };
            const cycleRule = (rule,value,callback) =>{
                var reg =/^[1-9]\d{6}$/;
                let request = {
                    id:this.dataForm.id,
                    playType:this.dataForm.playType,
                    verifyParam:this.dataForm.cycle
                };
                if (value === '') {
                    callback(new Error('期号必填'));
                } else if(!reg.test(value)) {
                    callback(new Error('期号为7位数字'));
                }else if(request){
                    this.$post(apiPage.api.verifyCycle,request).then((data) =>{
                        if(data.code == 500){
                            callback(data.msg);
                        }else{
                            callback();
                        }
                    }).catch(() => {
                        callback(new Error('服务异常'));
                    })
                }else{
                    callback();
                }
            };
            return{
                visible:false,
                isDisable:false,
                dataForm:{
                    redInfo:'',
                    redInfo1:'',
                    redInfo2:'',
                    redInfo3:'',
                    redInfo4:'',
                    redInfo5:'',
                    reds:[],
                    playType:1,
                    id:'',
                    red:'',
                    blue:'',
                    cycle:'',
                    cycleDate:'',
                    currentSalesAmount:'',
                    nextFirstAmount:'',
                    winningSituation: [
                        {
                            award:'一等奖',
                            num:'',
                            amount:'',
                            disabled:false,
                        },
                        {
                            award:'二等奖',
                            num:'',
                            amount:'',
                            disabled:false,
                        },
                        {
                            award:'三等奖',
                            num:'',
                            amount:300,
                            disabled:true,
                        },
                        {
                            award:'四等奖',
                            num:'',
                            amount:200,
                            disabled:true,
                        },
                        {
                            award:'五等奖',
                            num:'',
                            amount:10,
                            disabled:true,
                        },
                        {
                            award:'六等奖',
                            num:'',
                            amount:5,
                            disabled:true,
                        },
                    ],
                },
                dataRule:{
                    redInfo:[{required: true, validator:redsRule, trigger: 'blur'}],
                    blue:[{ required: true,validator: blueRule, trigger: 'blur' }],
                    cycle:[{required: true, validator: cycleRule, trigger: 'blur' }],
                    cycleDate:[{required: true, message: '开奖日期必填', trigger: 'blur'}],
                    currentSalesAmount:[{required: true,validator: number,  trigger: 'blur'}],
                    nextFirstAmount:[{required: true,validator: number,  trigger: 'blur'}],
                    winningSituation:{
                        num: [{required: true, message: '中奖注数必填',trigger: 'blur'}],
                        amount:[{required: true, message: '单注中奖金额必填',trigger: 'blur'}]
                    }
                },
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.dataForm.id = id;
                this.isDisable=false;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.dataForm.reds = [];
                    this.dataForm.redInfo1 = '';
                    this.dataForm.redInfo2 = '';
                    this.dataForm.redInfo3 = '';
                    this.dataForm.redInfo4 = '';
                    this.dataForm.redInfo5 = '';
                    this.dataForm.winningSituation = [
                        {
                            award:'一等奖',
                            num:'',
                            amount:'',
                            disabled:false,
                        },
                        {
                            award:'二等奖',
                            num:'',
                            amount:'',
                            disabled:false,
                        },
                        {
                            award:'三等奖',
                            num:'',
                            amount:3000,
                            disabled:true,
                        },
                        {
                            award:'四等奖',
                            num:'',
                            amount:200,
                            disabled:true,
                        },
                        {
                            award:'五等奖',
                            num:'',
                            amount:10,
                            disabled:true,
                        },
                        {
                            award:'六等奖',
                            num:'',
                            amount:5,
                            disabled:true,
                        }]
                });
            },
            getVisible(){
              this.visible = false;
              this.$emit('refreshDataList')
            },
            detailsHandle(){
                this.$refs['dataForm'].validate((valid) => {
                        if(valid){
                            this.$refs.detailsHandle.init(this.dataForm);
                        }
                });
            },
        },
        created(){

        }
    }
</script>

<style scoped>
    .el-form-item .el-form-item{
        height: 58px;
    }
</style>