<template>
    <div>
        <el-dialog
                title="导入"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                width="35%"
                :before-close="handleClose"
                :visible.sync="visible">

            <div class="exprotContent">
                <el-timeline>
                    <el-timeline-item>下载右侧模板，批量填写相关信息<span @click="downTemp" class="pointer red">【福彩3D模板】</span></el-timeline-item>
                    <el-timeline-item>上传填写好的信息
                        <el-upload
                                class="upload-demo"
                                action=""
                                :auto-upload="false"
                                :on-remove="handleRemove"
                                :on-change="onchange"
                                :limit="1"
                                :file-list="fileList">
                            <el-button size="small" type="primary">选择文件</el-button>
                        </el-upload>
                    </el-timeline-item>
                </el-timeline>
                <div>说明：导入会覆盖原有的信息，请谨慎操作</div>
            </div>
            <div class="exprotSuccess" v-if="successVisible">
                <i class="el-icon-success"></i>
                导入成功
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="dataFormSubmit()" v-if="firstVisible">点击上传</el-button>
                <el-button type="primary" @click="goUpLoad()" v-if="successVisible">确定</el-button>
            </span>
        </el-dialog>

        <el-dialog
                title="导入失败"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                width="35%"
                :visible.sync="errorVisible">

            <div class="errorContent">
                <h4><i class="el-icon-info"></i>当前有 <span class="red">{{errorNum}}条</span> 错误，请调整excel后重新上传</h4>
                <el-table
                        :data="errorList"
                        border
                        style="width:100%">
                    <el-table-column
                            prop="rowNum"
                            header-align="center"
                            align="center"
                            label="行数">
                    </el-table-column>
                    <el-table-column
                            prop="errorMsg"
                            header-align="center"
                            align="center"
                            label="错误原因">
                    </el-table-column>
                </el-table>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="goBack()" v-if="">返回重新上传</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import axios from 'axios'
    import {getBaseUrl} from "@/util";

    export default {
        name: "export-excel",
        data(){
            return{
                visible:false,
                errorVisible:false,
                fileList:[],
                formData:new FormData(),
                successVisible:false,
                firstVisible:true,
                errorNum:1,
                errorList:[]
            };
        },
        methods:{
            init(){
                this.visible = true;
            },
            goBack(){
                this.errorVisible = false;
                this.visible = true;
            },
            goUpLoad(){
                this.visible = false;
                this.handleClose();
                this.$emit('refreshDataList');
            },
            handleClose() {
                Object.assign(this.$data, this.$options.data())
            },
            downTemp(){
                window.location.href = getBaseUrl() + apiPage.api.welfareExportExcel;
            },
            dataFormSubmit(){
                this.deleteFormData();
                this.fileList.forEach(file => {
                    this.formData.append('file', file.raw);
                });
                axios({
                    url:getBaseUrl() + apiPage.api.welfareImportExcel,
                    method:'post',
                    data:this.formData,
                }).then((data) => {
                    if(data.code == 0){
                        // this.deleteFormData();
                        this.successVisible = true;
                        this.firstVisible = false;
                    }else if(data.code == 1){
                        // this.deleteFormData();
                        this.errorVisible = true;
                        this.errorNum = data.size;
                        this.errorList = data.failedList;
                    } else{
                        this.$message.error(data.msg)
                    }
                })
            },
            onchange(file, fileList) {
                this.fileList = fileList
            },
            handleRemove(file, fileList) {
                this.fileList = fileList
            },
            deleteFormData(){
                this.formData.delete('file');
            }
        },
        created() {

        }
    }
</script>

<style>
    .exprotContent .el-timeline .el-timeline-item__content{
        display: flex!important;
    }
    .upload-demo{
        width:300px;
        margin-left:50px;
        margin-top:-10px;
    }
    .exprotSuccess{
        font-size: 24px!important;
        text-align: center!important;
        margin-top: 40px!important;
        color: #303133!important;
    }
    .red{
        color:red;
    }
</style>