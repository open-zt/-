<template>
    <div>
        <el-dialog
                class="dialog-con"
                :title="!this.dataForm.id?'新增':'编辑'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                @close="handleClose"
                :visible.sync="visible">
            <el-button type="primary" @click="putAway()" v-if="this.dataForm.id" class="close-agent" :style="{right:'130px'}">{{this.dataForm.status == 0 ?'上架':'下架'}}</el-button>
            <el-button type="primary" @click="soldOut()" v-if="this.dataForm.id" class="close-agent">停售</el-button>
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="110px">
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="名称" prop="name">
                            <el-input v-model="dataForm.name" placeholder="请输入名称"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="编号" prop="code">
                            <el-input v-model="dataForm.code" placeholder="请输入编号"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row  :gutter="20">
                    <el-col :span="8">
                        <el-form-item label="面值" prop="faceValue">
                            <el-select placeholder="请选择" v-model="dataForm.faceValue">
                                <el-option v-for="item in faceValueList" :key="item.id" :value="item.id" :label="item.name"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="4">
                        <div style="margin-top: 12px;" class="pointer" @click="addUnit(2)">
                            <i class="el-icon-plus"></i>
                            编辑分类
                        </div>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="价格" prop="saleAmount">
                            <el-input v-model="dataForm.saleAmount" placeholder="请输入价格"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20" >
                    <el-col :span="8">
                        <el-form-item label="单位" prop="unitDict" >
                            <el-select placeholder="请选择" v-model="dataForm.unitDict" >
                                <el-option v-for="item in unitList" :value="item.id" :key="item.id" :label="item.name"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="4">
                        <div style="margin-top: 12px;" class="pointer" @click="addUnit(1)">
                            <i class="el-icon-plus"></i>
                            编辑分类
                        </div>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="开售日期" prop="saleTime">
                            <el-date-picker
                                    v-model="dataForm.saleTime"
                                    type="date"
                                    value-format="yyyy-MM-dd"
                                    placeholder="开售日期">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="最高奖" prop="topAmount">
                           <el-input  v-model="dataForm.topAmount" placeholder="请输入最高奖"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="奖组" prop="awardGroup">
                            <el-select placeholder="请选择" v-model="dataForm.awardGroup">
                                <el-option v-for="item in awardGroupList" :key="item.id" :value="item.id" :label="item.name"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="24">
                        <el-form-item prop="imgUrlList" label="图片">
                            <ul class="upload-imgs">
                                <viewer :images="dataForm.imgUrlList">
                                    <li v-for='(item, index) in dataForm.imgUrlList' :key="index" v-dragging="{ item: item, list: dataForm.imgUrlList, group: 'item' }">
                                        <div class="img">
                                            <img :src="item">
                                            <a class="close" @click="delImg(index)">×</a>
                                        </div>
                                    </li>
                                    <li v-if="this.imgLength>=5 ? false : true">
                                        <input type="file" class="upload" @change="addImg" ref="inputer" multiple accept="image/png, image/jpeg, image/gif"/>
                                        <div class="add">点击上传<br/>{{imgLength}}/5</div>
                                    </li>
                                </viewer>
                            </ul>
                            <div class="help-block">(注：支持png、jpg、jpeg格式的图片，第一张为首图，图片可以通过拖拽调整顺序)</div>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row>
                    <p>即开票批准文号</p>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="发行日期" prop="issueTime">
                            <el-date-picker
                                    v-model="dataForm.issueTime"
                                    type="date"
                                    value-format="yyyy-MM-dd"
                                    placeholder="开售日期">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="发行批准文号" prop="issueNumber">
                            <el-input v-model="dataForm.issueNumber" placeholder="请输入发行批准文号"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="dataFormSubmit()">确 定</el-button>
            </span>
        </el-dialog>

        <el-dialog :visible.sync="dialogVisible">
            <img width="100%" :src="dialogImageUrl" alt="">
        </el-dialog>

        <new-handle ref="newHandle" @refreshDataList="getUnitList" @faceValue="getFaceValue"></new-handle>
        <put-away-handle ref="putAwayHandle" @refreshDataList="getInfo"></put-away-handle>
        <sold-handle ref="soldHandle" @refreshDataList="getVisible"></sold-handle>
        <details-handle ref="detailsHandle" @ee="dataFormSubmit"></details-handle>

    </div>
</template>

<script>
    import apiPage from '@/api'
    import axios from 'axios'
    import {getBaseUrl} from "@/util";
    import newHandle from '../consume/new-handle'
    import putAwayHandle from '../put-away/put-away-handle'
    import soldHandle from './soldout-handle'
    import detailsHandle from './details-handle'
    import {number} from "@/util/validate";

    export default {
        name: "add-or-update",
        data(){
            const codeRule = (rule,value,callback) => {
                let request = {
                    id:this.dataForm.id,
                    verifyParam:this.dataForm.code
                };
                this.$post(apiPage.api.verifyProdCode,request).then((data) =>{
                    if(data.code == 500){
                        callback(data.msg);
                    }else{
                        callback();
                    }
                }).catch(() => {
                    callback(new Error('服务异常'));
                })
            };
            return{
                visible:false,
                dialogVisible:false,
                dialogImageUrl:'',
                faceValueList:[],
                awardGroupList:[],
                imgUrl:'',
                imgLength: 0,
                unitList:[],
                selectId:'',
                dataForm:{
                    id:'',
                    name:'',
                    code:'',
                    faceValue:'',
                    saleAmount:'',
                    unitDict:'',
                    imgUrlList:[],
                    imgId:'',
                    saleTime:'',
                    topAmount:'',
                    awardGroup:'',
                    issueTime:'',
                    issueNumber:'',
                },
                type:'',
                dataRule:{
                    name:[{required: true, message: '名称必填', trigger: 'blur'}],
                    code:[{required: true, message: '编号必填', trigger: 'blur'},
                        {validator:codeRule, trigger: 'blur'}],
                    faceValue:[{required: true, message: '面值必填', trigger: 'blur'}],
                    saleAmount:[{required: true, message: '价格必填', trigger: 'blur'}],
                    unitDict:[{required: true, message: '单位必填', trigger: 'blur'}],
                    saleTime:[{required: true, message: '开售日期必填', trigger: 'blur'}],
                    topAmount:[{required: true, validator:number, trigger: 'blur'}],
                    awardGroup:[{required: true, message: '奖组必填', trigger: 'blur'}],
                    imgUrlList:[{required: true, message: '图片必填',trigger: ['blur', 'change']}],
                    issueTime:[{required: true, message: '发行日期必填', trigger: 'blur'}],
                    issueNumber:[{required: true, message: '发行批准文号必填', trigger: 'blur'}],
                },
            }
        },
        components:{
          newHandle,putAwayHandle,soldHandle,detailsHandle
        },
        methods:{
            getVisible(){
                this.visible = false;
                this.$refs.detailsHandle.init(this.dataForm.id);
            },
            handleClose(){
                this.$emit('refreshDataList')
            },
            soldOut(){
                this.$nextTick(() => {
                    this.$refs.soldHandle.init(this.dataForm.id);
                });
            },
            putAway(){
                this.$nextTick(() => {
                    this.$refs.putAwayHandle.init(this.dataForm.status,this.dataForm.id);
                })
            },
            addUnit(type){
                this.$nextTick(() => {
                    this.$refs.newHandle.init(type);
                })
            },
            getUnitList(id){
                this.$get(apiPage.api.unitList).then((data) =>{
                    if(data.code == 0){
                        this.unitList = data.list;
                        this.dataForm.unitDict = id;
                    }
                });
            },
            getFaceValue(id){
                this.$get(apiPage.api.faceValueList).then((data) => {
                    if(data.code == 0){
                        this.faceValueList = data.list;
                        this.dataForm.faceValue = id;
                    }
                });
            },
            init(type,id){
                this.visible = true;
                this.type = type;
                this.dataForm.id = id;
                this.imgUrl = getBaseUrl() + apiPage.api.sysFileUpload;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.dataForm.imgId = '';
                    this.imgLength = 0;
                });

                //获取奖组
                this.$get(apiPage.api.awardGroup).then((data) => {
                    if(data.code == 0){
                        this.awardGroupList = data.list;
                    }
                });
                if(this.dataForm.id){
                    this.getInfo();
                }
            },
            getInfo(){
                this.$get(apiPage.api.billingInfo + this.dataForm.id).then((data) => {
                    if(data.code == 0){
                        this.dataForm = data.product;
                        this.dataForm.status = data.product.status.toString();
                        this.imgLength = data.product.imgUrlList.length;
                    }
                })
            },
            dataFormSubmit(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        if(this.type == '1'){
                            this.$post(apiPage.api.playOpenSave,this.dataForm).then((data) => {
                                if(data.code == 0){
                                    this.selectId = data.id;
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 800,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList',this.selectId)
                                        }
                                    });
                                }else {
                                    this.$message.error(data.msg);
                                }
                            })
                        }else{
                            this.$post(apiPage.api.billingSave + `${!this.dataForm.id ? 'save' : 'update'}`,this.dataForm).then((data) => {
                                if(data.code == 0){
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 800,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList')
                                        }
                                    });
                                }else {
                                    this.$message.error(data.msg);
                                }
                            })
                        }
                    }
                })
            },
            addImg() {
                let inputDOM = this.$refs.inputer;
                var files = inputDOM.files;
                let oldLength = this.imgLength;
                let len = files.length + oldLength;
                if(len>5){
                    this.$message.error('最多可上传5张');
                    return false;
                }
                let fd =  new FormData();
                let config = {headers:{'Content-Type':'multipart/form-data'}};
                for(var i = 0; i< files.length;i++){
                    fd.set('file',files[i]);
                    fd.set('imgId',this.dataForm.imgId);
                    let size = Math.floor(files[i].size / 1024);
                    if (size > 5 * 1024 * 1024) {
                        alert('请选择5M以内的图片！');
                    }else{
                        axios.post(this.imgUrl,fd,config).then((data)=>{
                            if(data.code == 0){
                                this.dataForm.imgUrlList.push(data.fileUrl);
                                this.dataForm.imgId = data.imgId;
                                this.imgLength++;
                                this.$refs.inputer.value = null;
                            }else{
                                this.$message.error('上传图片错误，请重新上传');
                            }
                        })
                    }
                }
            },
            delImg(index) {
                this.$confirm(`您确认要删除选择的图片吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.dataForm.imgUrlList.splice(index, 1);
                    this.imgLength--;
                });
            },
        },
        mounted(){
        },
        created() {
            this.getUnitList();
            this.getFaceValue();
        }
    }
</script>
