<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
            <el-button type="primary" @click="exportExcel()" plain>导入</el-button>
            <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
            <el-dropdown @command="handleCommand" :style="{marginLeft:'10px'}">
                <el-button type="primary" plain>设置<i class="el-icon-arrow-down el-icon--right"></i></el-button>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item command="prod_unit">单位管理</el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
        <el-table
                :data="dataList"
                border
                style="width:100%"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="编号">
            </el-table-column>
            <el-table-column
                    prop="saleAmount"
                    header-align="center"
                    align="center"
                    label="价格">
            </el-table-column>
            <el-table-column
                    prop="unitDict"
                    header-align="center"
                    align="center"
                    label="单位">
            </el-table-column>
            <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="耗材状态">
                <template slot-scope="scope">
                    <p v-if="scope.row.status == 0">下架</p>
                    <p v-if="scope.row.status == 1">上架</p>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.id)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

        <add-or-update ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update>
        <export-handle ref="exportHandle" @refreshDataList="getDataList"></export-handle>
        <handle-list ref="handleList"></handle-list>
    </div>
</template>

<script>
    import apiPage  from '@/api'
    import addOrUpdate from './add-or-update'
    import exportHandle from './export-excel'
    import handleList from '../../../../handle/handle-list'
    export default {
        data() {
            return {
                dataList:[],
                faceValueList:[],
                pageIndex: 1,
                pageSize: 10,
                totalPage: 0,
                dataListSelections:[]
            }
        },
        components:{
            addOrUpdate,
            exportHandle,
            handleList
        },
        methods: {
            handleCommand(command) {
                this.$nextTick(() =>{
                    this.$refs.handleList.init(command);
                });
            },
            exportExcel(){
                this.$nextTick(() => {
                    this.$refs.exportHandle.init();
                })
            },
            addOrUpdateHandle(id){
                this.$nextTick(() =>{
                    this.$refs.addOrUpdate.init(id);
                });
            },
            getDataList() {
                let request = {
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.consumableList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            deleteHandle(id){
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.id
                });
                let request = {
                    'ids':ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.batchRemove,request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            }
        },
        created() {
            this.getDataList();
        }
    }
</script>
