<template>
    <div>
        <el-dialog
                title="停售"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                width="30%"
                :visible.sync="visible">
            <p :style="{textAlign:'center',lineHeight:'24px'}">停售的玩法将无法在终端显示，您确认停售该玩法吗？<br/>如果确认，请填写以下信息</p>
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="dataFormSubmit()" label-width="106px">
                <el-form-item label="停售日期" prop="soldOutTime">
                    <el-date-picker
                            v-model="dataForm.soldOutTime"
                            type="date"
                            value-format="yyyy-MM-dd"
                            placeholder="停售日期">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="停售批准文号" prop="soldOutNumber">
                    <el-input v-model="dataForm.soldOutNumber" placeholder="请输入停售批准文号"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="dataFormSubmit()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "soldout-handle",
        data(){
            return{
                visible:false,
                dataForm:{
                    id:'',
                    soldOutTime:'',
                    soldOutNumber:''
                },
                dataRule:{
                    soldOutTime:[{required: true, message: '停售日期必填', trigger: 'blur'}],
                    soldOutNumber:[{required: true, message: '停售批准文号必填', trigger: 'blur'}],
                }
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.dataForm.id = id;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                });
            },
            dataFormSubmit(){
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        this.$post(apiPage.api.productSoldOut,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 1500,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                })
                            }else{
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            }
        }
    }
</script>

<style scoped>

</style>