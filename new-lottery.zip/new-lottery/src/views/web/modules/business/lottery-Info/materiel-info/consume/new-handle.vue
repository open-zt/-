<template>
    <div>
        <el-dialog
                title="新增分类"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                width="30%"
                :visible.sync="visible">

            <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
                <el-form-item label="名称" prop="name">
                    <el-input v-model="dataForm.name" placeholder="请输入"></el-input>
                </el-form-item>
                <el-form-item label="排序" prop="sort">
                    <el-input v-model="dataForm.sort" placeholder="请输入"></el-input>
                </el-form-item>
                <el-form-item>
                    <div>设置排序后，将按照排序序号正序排列</div>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="dataFormSubmit()" :disabled="isDisable">确 定</el-button>
            </span>

        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "new-handle",
        data(){
            return{
                visible:false,
                isDisable:false,
                type:'',
                dataForm:{
                    id:'',
                    name:'',
                    sort:''
                },
                dataRule:{
                    name:[{required: true,message: '名称必填', trigger: 'blur'}]
                },
            }
        },
        methods:{
            init(type){
                this.type = type;
                this.visible = true;
                this.isDisable = false;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                })
            },
            dataFormSubmit(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.isDisable = true;
                        if(this.type == 1){
                            this.$post(apiPage.api.unitSave,this.dataForm).then((data) => {
                                if(data.code == 0){
                                    this.dataForm.id = data.id;
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 1500,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('refreshDataList',this.dataForm.id)
                                        }
                                    })
                                } else {
                                    this.isDisable = false;
                                    this.$message.error(data.msg);
                                }
                            })
                        }else if(this.type == 2){
                            this.$post(apiPage.api.faeValueSave,this.dataForm).then((data) => {
                                if(data.code == 0){
                                    this.dataForm.id = data.id;
                                    this.$message({
                                        message: '操作成功',
                                        type: 'success',
                                        duration: 1500,
                                        onClose: () => {
                                            this.visible = false;
                                            this.$emit('faceValue',this.dataForm.id)
                                        }
                                    })
                                } else {
                                    this.isDisable = false;
                                    this.$message.error(data.msg);
                                }
                            })
                        }
                    }
                })
            }

        },
        created() {

        }
    }
</script>

<style scoped>

</style>