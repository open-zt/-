<template>
    <el-dialog
            class="dialog-con"
            title="即开票详情"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            :visible.sync="visible">

        <el-form :model="dataForm"  ref="dataForm" label-width="110px">
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="名称">
                        <span>{{dataForm.name}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="编号">
                        <span>{{dataForm.code}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="面值">
                        <span>{{dataForm.faceValue}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="价格">
                        <span>{{dataForm.saleAmount}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="单位">
                        <span>{{dataForm.unitDict}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="开售日期">
                        <span>{{dataForm.saleTime}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="最高奖">
                        <span>{{dataForm.topAmount}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="奖组">
                        <span>{{dataForm.awardGroup}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <p>图片</p>
                <img  v-for="item in dataForm.imgUrlList" :src="item" width="150" height="150" style="margin-right:10px"/>
<!--                <el-image-->
<!--                        style="width: 100px; height: 100px"-->
<!--                        :src="dataForm.prodImg[0]"-->
<!--                        :preview-src-list="dataForm.prodImg">-->
<!--                </el-image>-->
            </el-row>
            <el-row>
                <p>即开票批准文号</p>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="12">
                    <el-form-item label="发行日期">
                        <span>{{dataForm.issueTime}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="发行批准文号">
                        <span>{{dataForm.issueNumber}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>

    </el-dialog>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "opentype-details",
        data(){
            return{
                visible:false,
                url: 'https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg',
                srcList: [
                    'https://fuss10.elemecdn.com/8/27/f01c15bb73e1ef3793e64e6b7bbccjpeg.jpeg',
                    'https://fuss10.elemecdn.com/1/8e/aeffeb4de74e2fde4bd74fc7b4486jpeg.jpeg'
                ],
                dataForm:{
                    prodId:'',
                },
            }
        },
        methods:{
            init(id){
                this.visible = true;
                this.dataForm.prodId = id;

                this.$get(apiPage.api.billingInfo + this.dataForm.prodId).then((data) => {
                    if(data.code == 0){
                        this.dataForm = data.product;
                    }
                });

            }
        },
        created() {

        }
    }
</script>

<style scoped>

</style>