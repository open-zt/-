<template>
    <div>
        <el-dialog
                title="玩法名称管理"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                @close="close"
                :visible.sync="visible">
            <div :style="{marginBottom:'10px'}">
                <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
                <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
            </div>
            <el-table
                    :data="dataList"
                    border
                    style="width:100%"
                    @selection-change="handleSelectionChange">
                <el-table-column
                        type="selection"
                        width="55">
                </el-table-column>
                <el-table-column
                        prop="name"
                        header-align="center"
                        align="center"
                        label="名称">
                </el-table-column>
                <el-table-column
                        prop="sort"
                        header-align="center"
                        align="center"
                        label="排序">
                </el-table-column>
                <el-table-column
                        header-align="center"
                        align="center"
                        label="操作"
                        width="100">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="addOrUpdateHandle(scope.row.id)">编辑</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page.sync="pageIndex"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalPage"
                    v-if="this.dataList !=''">
            </el-pagination>
        </el-dialog>
        <handle-add-or-update ref="handleAddOrUpdate" @refreshDataList="getDataList"></handle-add-or-update>
    </div>
</template>

<script>
    import apiPage  from '@/api'
    import handleAddOrUpdate from './play-name-add-or-update'
    export default {
        data(){
            return{
                visible:false,
                dataListSelections:[],
                dataList:[],
                pageIndex: 1,
                pageSize: 10,
                totalPage: 0,
                type:''
            }
        },
        components:{
            handleAddOrUpdate
        },
        methods:{
            close(){
                this.$emit('refreshDataList')
            },
            handleSelectionChange(val){
                this.dataListSelections = val;
            },
            addOrUpdateHandle(id){
                this.$nextTick(() =>{
                    this.$refs.handleAddOrUpdate.init(id,this.type);
                })
            },
            init(type){
                this.visible = true;
                this.type = type;
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'type':this.type,
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.playNameList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            deleteHandle(id){
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.id
                });
                let request = {
                    'ids':ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.playNameRemove,request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            }
        },
        created() {

        }
    }
</script>

<style scoped>

</style>