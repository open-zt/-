<template>
    <div>
        <el-dialog
                class="dialog-con"
                title="玩法详情"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                @close="close"
                :visible.sync="detailVisible">

            <el-form :model="dataForm"  ref="dataForm" label-width="110px">
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="玩法">
                            <span>{{dataForm.playName}}</span>
                            <span style="color:red;margin-left: 20px;">已停售</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="23">
                        <el-form-item label="玩法规则">
                            <div  style="border:1px solid #ccc;" v-html="dataForm.playRule"></div>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <p>即开票批准文号</p>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="发行日期">
                            <span>{{dataForm.issueTime}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="发行批准文号">
                            <span>{{dataForm.issueNumber}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="12">
                        <el-form-item label="停售日期">
                            <span>{{dataForm.soldOutTime}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="停售批准文号">
                            <span>{{dataForm.soldOutNumber}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "details-handle",
        data(){
            return{
                detailVisible:false,
                dataForm:{
                    id:'',
                }
            }
        },
        methods:{
            close(){
                this.$emit('ee')
            },
            init(id){
                this.detailVisible = true;
                this.dataForm.id = id;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                });
                if(this.dataForm.id){
                    this.getDetails();
                }
            },
            getDetails(){
                this.$get(apiPage.api.playInfo + this.dataForm.id).then((data) => {
                    if(data.code == 0){
                        this.dataForm = data.playInfo;
                    }
                });
            },
        },
        created() {

        }
    }
</script>

<style scoped>

</style>