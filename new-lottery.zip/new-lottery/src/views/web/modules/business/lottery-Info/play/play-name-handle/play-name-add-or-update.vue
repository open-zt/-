<template>
    <el-dialog
            title="玩法名称管理"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            width="30%"
            :visible.sync="visible">

        <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
            <el-form-item label="名称" prop="name">
                <el-input v-model="dataForm.name" placeholder="请输入"></el-input>
            </el-form-item>
            <el-form-item label="排序" prop="sort">
                <el-input v-model="dataForm.sort" placeholder="请输入"></el-input>
            </el-form-item>
            <el-form-item>
                <div>设置排序后，将按照排序序号正序排列</div>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="visible = false">取 消</el-button>
          <el-button type="primary" @click="dataFormSubmit()" :disabled="isDisable">确 定</el-button>
        </span>

    </el-dialog>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "play-name-add-or-update",
        data(){
            return{
                visible:false,
                isDisable:false,
                dataForm:{
                    id:'',
                    name:'',
                    sort:'',
                    type:''
                },
                dataRule:{
                    name:[{required: true,message: '名称必填', trigger: 'blur'}]
                },
            }
        },
        methods:{
            init(id,type){
                this.visible = true;
                this.isDisable=false;
                this.dataForm.id = id;
                this.dataForm.type = type;
                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                });

                if(this.dataForm.id){
                    this.$get(apiPage.api.playNameInfo + this.dataForm.id).then((data) =>{
                        if(data.code == 0){
                            this.dataForm = data.info;
                        }
                    })
                }

            },
            dataFormSubmit(){
                this.$refs['dataForm'].validate((valid) => {
                    if(valid){
                        this.isDisable = true;
                        this.$post(apiPage.api.playNameSave + `${!this.dataForm.id ?'save':'update'}`,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 1500,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                })
                            } else {
                                this.isDisable = false;
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            }
        }
    }
</script>

<style scoped>

</style>