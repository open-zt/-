<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" plain>设置库存</el-button>
            <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
        </div>
        <el-form :inline="true" :model="dataForm">
            <el-form-item label="名称">
                <el-input v-model="dataForm.name" placeholder="请输入名称" clearable></el-input>
            </el-form-item>
            <el-form-item label="面值">
                <el-select v-model="dataForm.faceValue" placeholder="请选择" clearable>
                    <el-option v-for="item in faceValueList" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="状态">
                <el-select v-model="dataForm.status" clearable>
                    <el-option value="0" label="下架"></el-option>
                    <el-option value="1" label="上架"></el-option>
                    <el-option value="2" label="已停售"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="dataList"
                border
                style="width:100%"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="名称">
            </el-table-column>
            <el-table-column
                    prop="code"
                    header-align="center"
                    align="center"
                    label="编号">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="面值">
            </el-table-column>
            <el-table-column
                    prop="saleAmount"
                    header-align="center"
                    align="center"
                    label="价格">
            </el-table-column>
            <el-table-column
                    prop="unitDict"
                    header-align="center"
                    align="center"
                    label="单位">
            </el-table-column>
            <el-table-column
                    prop="issueTime"
                    header-align="center"
                    align="center"
                    label="发行日期">
            </el-table-column>
            <el-table-column
                    prop="saleTime"
                    header-align="center"
                    align="center"
                    label="开售日期">
            </el-table-column>
            <el-table-column
                    prop="topAmount"
                    header-align="center"
                    align="center"
                    label="最高奖">
            </el-table-column>
            <el-table-column
                    prop="awardGroup"
                    header-align="center"
                    align="center"
                    label="奖组">
            </el-table-column>
            <el-table-column
                    prop="awardGroup"
                    header-align="center"
                    align="center"
                    label="上级中心库存">
            </el-table-column>
            <el-table-column
                    prop="awardGroup"
                    header-align="center"
                    align="center"
                    label="终端库存">
            </el-table-column>
            <el-table-column
                    prop="awardGroup"
                    header-align="center"
                    align="center"
                    label="可销售库存">
            </el-table-column>
            <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="状态">
                <template slot-scope="scope">
                    <p v-if="scope.row.status == 0">下架</p>
                    <p v-if="scope.row.status == 1">上架</p>
                    <p v-if="scope.row.status == 2">已停售</p>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" v-if="scope.row.status == 2"  @click="detailsHandle(scope.row.id)">设置库存</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>

    </div>
</template>

<script>
    import apiPage  from '@/api'
    export default {
        data() {
            return {
                dataForm: {
                    name: '',
                    faceValue: '',
                    issueTime:'',
                    status:'',
                },
                dataList:[],
                faceValueList:[],
                pageIndex: 1,
                pageSize: 10,
                totalPage: 0,
                dataListSelections:[]
            }
        },
        methods: {
            handleCommand(command) {
                this.$nextTick(() =>{
                    this.$refs.handleList.init(command);
                });
            },
            clear(){
                this.dataForm = {};
                // this.getDataList();
            },
            exportExcel(){
                this.$nextTick(() => {
                    this.$refs.exportHandle.init();
                })
            },
            addOrUpdateHandle(type,id){
                this.$nextTick(() =>{
                    this.$refs.addOrUpdate.init(type,id);
                });
            },
            detailsHandle(id){
                this.$nextTick(()  => {
                    this.$refs.detailsHandle.init(id);
                })
            },
            getDataList() {
                let request = {
                    'name':this.dataForm.name,
                    'faceValue':this.dataForm.faceValue,
                    'issueTime':this.dataForm.issueTime,
                    'status':this.dataForm.status,
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.billingList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            getFaceValueList(){
                this.$get(apiPage.api.faceValueList).then((data) => {
                    if(data.code == 0){
                        this.faceValueList = data.list;
                    }
                })
            },
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            deleteHandle(id){
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.id
                });
                let request = {
                    'ids':ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.batchRemove,request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            }
        },
        created() {
            this.getFaceValueList();
            // this.getDataList();
        }
    }
</script>
