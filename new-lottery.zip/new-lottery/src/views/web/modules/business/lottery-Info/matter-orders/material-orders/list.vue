<template>
    <div class="table-con">
        <el-form :model="dataForm">
            <el-form-item label="订单分类：">
                <el-radio v-model="dataForm.state" label="0" @change="getDataList">待配货订单</el-radio>
                <el-radio v-model="dataForm.state" label="1" @change="getDataList">已配货订单</el-radio>
                <el-radio v-model="dataForm.state" label="2" @change="getDataList">已取消订单</el-radio>
            </el-form-item>
        </el-form>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="订单编号">
                <el-input v-model="dataForm.orderNo" placeholder="请输入订单编号" clearable></el-input>
            </el-form-item>
            <el-form-item label="下单时间">
                <el-date-picker
                        v-model="dataForm.orderStartTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="配货时间" v-if="dataForm.state == 1">
                <el-date-picker
                        v-model="dataForm.allotStartTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
                <el-button type="primary" @click="distributionHandle()" v-if="dataForm.state == 0" :disabled="dataListSelections.length <= 0">批量配货</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="dataList"
                style="width:100%"
                border
                ref="multipleTable"
                @selection-change="selectionChangeHandle">
            <el-table-column
                    type="selection"
                    :selectable="checkSelectable"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    width="180"
                    label="下单时间">
            </el-table-column>
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    width="180"
                    label="订单编号">
            </el-table-column>
            <el-table-column
                    type="expand"
                    header-align="center"
                    align="center"
                    width="150"
                    label="耗材信息">
                    <template slot-scope="scope">
                        <div v-for="item in scope.row.itemList" style="text-align: left;" >
                            <p :style="{color:'#000',fontWeight:'500'}">{{item.name}}<span v-if="item.faceValue != null">({{item.faceValue}})</span></p>
                            <span :style="{marginRight:'10px'}">单价：¥ {{item.price}}</span>
                            <span :style="{marginRight:'10px'}">数量：{{item.num}}</span>
                            <span :style="{marginRight:'10px'}">金额：¥ {{item.amount}}</span>
                        </div>
                    </template>
            </el-table-column>
            <el-table-column
                    prop="totalNum"
                    header-align="center"
                    align="center"
                    label="合计种类及数量">
                <template slot-scope="scope">
                    <p>共{{scope.row.itemList.length}}种</p>
                    <div>{{scope.row.totalNum}}本</div>
                </template>
            </el-table-column>
            <el-table-column
                    prop="totalPrice"
                    header-align="center"
                    align="center"
                    label="实付金额">
            </el-table-column>
            <el-table-column
                    prop="urgent"
                    header-align="center"
                    align="center"
                    label="紧急程度">
                <template slot-scope="scope">
                    <p v-if="scope.row.urgent == 0">普通</p>
                    <p v-if="scope.row.urgent == 1">紧急</p>
                </template>
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    width="200"
                    label="投注站">
                <template slot-scope="scope">
                    <p v-if="scope.row.agentName != null">昵称：{{scope.row.agentName}}</p>
                    <p v-if="scope.row.agentId != null">编号:{{scope.row.agentId}}</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="专管员">
                <template slot-scope="scope">
                    <p>{{scope.row.managerUserName}}</p>
                    <p>{{scope.row.managerUserMobile}}</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="allotDate"
                    header-align="center"
                    align="center"
                    width="180"
                    v-if="dataForm.state == 1"
                    label="配货时间">
            </el-table-column>
            <el-table-column
                    prop="state"
                    header-align="center"
                    align="center"
                    v-if="dataForm.state == 1"
                    label="订单状态">
                <template slot-scope="scope">
                    <p v-if="scope.row.state == 1">提交</p>
                    <p v-if="scope.row.state == 3">提交后取消</p>
                    <p v-if="scope.row.state == 5">支付</p>
                    <p v-if="scope.row.state == 7">支付后取消</p>
                    <p v-if="scope.row.state == 13">出库</p>
                    <p v-if="scope.row.state == 29">取货配送</p>
                    <p v-if="scope.row.state == 61">配送成功</p>
                    <p v-if="scope.row.state == 125">签收</p>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    v-if="dataForm.state == 0"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="distributionHandle(scope.row.id)">配货</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
    </div>
</template>
<script>
    import apiPage from '@/api'
    export default {
        data(){
            return{
                dataForm:{
                    state:'0',
                    orderNo:'',
                    orderStartTime:'',
                    orderEndTime:'',
                    allotStartTime:'',
                    allotEndTime:'',
                },
                dataList:[],
                itemList:[],
                pageIndex:1,
                pageSize:10,
                totalPage:0,
                dataListSelections: []
            }
        },
        methods:{
            checkSelectable(row){
                if(row.state == '5'){
                    return true
                }else{
                    return false
                }
            },
            clear(){
                this.dataForm = {
                    state:'0',
                    orderNo:'',
                    orderStartTime:'',
                    orderEndTime:'',
                    allotStartTime:'',
                    allotEndTime:'',
                };
                this.getDataList();
            },
            distributionHandle(id){
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.id
                });
                let request = {
                    'ids':ids
                };
                this.$confirm(`确认对您选中的数据进行配货吗？
                    确认后，我们会立刻通知专管员进行取货配送`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.cityManageBatchUpdate,request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            },
            selectionChangeHandle(val) {
                this.dataListSelections = val;
            },
            getDataList(){
                let request = {
                    'state':this.dataForm.state,
                    'orderNo':this.dataForm.orderNo,
                    'orderStartTime':this.dataForm.orderStartTime[0],
                    'orderEndTime':this.dataForm.orderStartTime[1],
                    'allotStartTime':this.dataForm.allotStartTime[0],
                    'allotEndTime':this.dataForm.allotStartTime[1],
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.cityMaterialList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        mounted(){

        },
        created() {
            this.getDataList();
        }
    }
</script>
<style>
    .table-con .el-table--border .table td, .table-con .el-table--border .table th{
        border-right:none!important;
    }
</style>