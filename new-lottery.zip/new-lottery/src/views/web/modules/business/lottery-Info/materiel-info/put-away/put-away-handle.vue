<template>
    <div>
        <el-dialog
                :title="this.state == 0?'上架':'下架'"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                width="30%"
                :visible.sync="visible">

                <p v-if="this.state == 0">商品上架后便可在终端进行销售，您确认上架商品吗？</p>
                <p v-if="this.state == 1">商品在下架期间将无法进行销售，您确认下架商品吗？</p>
                <span slot="footer" class="dialog-footer">
                  <el-button @click="visible = false">取 消</el-button>
                  <el-button type="primary" @click="dataFormSubmit()">确 定</el-button>
                </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'
    export default {
        name: "put-away-handle",
        data(){
            return{
                visible:false,
                state:'',
                id:'',
            }
        },
        methods:{
            init(state,id){
                this.visible = true;
                this.state = state;
                this.id = id;
            },
            dataFormSubmit(){
                let request = {
                    id:this.id
                };
                if(this.state == 0){
                    this.$post(apiPage.api.putAway,request).then((data) => {
                        if(data.code == 0){
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.visible = false;
                                    this.$emit('refreshDataList')
                                }
                            })
                        }else{
                            this.$message.error(data.msg);
                        }
                    })
                }else{
                    this.$post(apiPage.api.soldOut,request).then((data) => {
                        if(data.code == 0){
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.visible = false;
                                    this.$emit('refreshDataList')
                                }
                            })
                        }else{
                            this.$message.error(data.msg);
                        }
                    })
                }
            },
        },

    }
</script>

<style scoped>

</style>