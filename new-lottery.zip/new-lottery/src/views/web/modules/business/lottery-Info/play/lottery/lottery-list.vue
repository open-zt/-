<template>
    <div>
        <div :style="{marginBottom:'10px'}">
            <el-button type="primary" @click="addOrUpdateHandle()" plain>新增</el-button>
            <el-button type="primary" @click="deleteHandle()" :disabled="dataListSelections.length <= 0">删除</el-button>
            <el-dropdown @command="handleCommand" :style="{marginLeft:'10px'}">
                <el-button type="primary" plain>设置<i class="el-icon-arrow-down el-icon--right"></i></el-button>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>玩法名称</el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="玩法">
                <el-input v-model="dataForm.name" placeholder="请输入玩法" clearable></el-input>
            </el-form-item>
            <el-form-item label="状态">
                <el-select v-model="dataForm.state" clearable>
                    <el-option value="0" label="已停售"></el-option>
                    <el-option value="1" label="可售"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
            border
            style="width:100%"
            :data="dataList"
            @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    prop="name"
                    header-align="center"
                    align="center"
                    label="玩法">
            </el-table-column>
            <el-table-column
                    prop="bonus"
                    header-align="center"
                    align="center"
                    :sortable="true"
                    :sort-method="sortBouns"
                    label="近30天销量">
            </el-table-column>
            <el-table-column
                    prop="state"
                    header-align="center"
                    align="center"
                    label="玩法状态">
                <template slot-scope="scope">
                    <p v-if="scope.row.state == 0">已停售</p>
                    <p v-if="scope.row.state == 1">可售</p>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    header-align="center"
                    align="center"
                    label="操作"
                    width="100">
                <template slot-scope="scope">
                    <el-button type="text" size="small" v-if="scope.row.state != 0" @click="addOrUpdateHandle(scope.row.id)">编辑</el-button>
                    <el-button type="text" size="small" v-if="scope.row.state == 0"  @click="detailsHandle(scope.row.id)">详情</el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
        <add-or-update-handle ref="addOrUpdateHandle" @refreshDataList="getDataList"></add-or-update-handle>
        <play-name-handle ref="playNameHandle" @refreshDataList="getDataList"></play-name-handle>
        <details-handle ref="detailsHandle" @refreshDataList="getDataList"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import addOrUpdateHandle from './add-or-update'
    import playNameHandle from '../play-name-handle/play-name-list'
    import detailsHandle from '../details-handle/details-handle'

    export default {
        name: "lottery-list",
        data(){
          return{
              dataList:[],
              dataForm:{
                  name:'',
                  state:'',
              },
              pageIndex:1,
              pageSize:10,
              totalPage:0,
              dataListSelections:[]
          }
        },
        components:{
            addOrUpdateHandle,playNameHandle,detailsHandle
        },
        methods:{
            handleCommand() {
                this.$nextTick(() =>{
                    this.$refs.playNameHandle.init('LETOU');
                });
            },
            clear(){
                this.dataForm = {};
                this.getDataList();
            },
            sortBouns(a,b){
                return a.bonus-b.bonus
            },
            addOrUpdateHandle(id){
                this.$nextTick(()  => {
                    this.$refs.addOrUpdateHandle.init(id);
                })
            },
            detailsHandle(id){
                this.$nextTick(()  => {
                    this.$refs.detailsHandle.init(id);
                })
            },
            getDataList(){
                let request = {
                    'name':this.dataForm.name,
                    'state':this.dataForm.state,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.lottoList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            deleteHandle(id){
                var ids = id ? [id] : this.dataListSelections.map(item => {
                    return item.id
                });
                let request = {
                    'ids':ids
                };
                this.$confirm(`确认对您选中的数据进行删除吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.$post(apiPage.api.playRemove,request).then((data) => {
                        if (data && data.code === 0) {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 1500,
                                onClose: () => {
                                    this.getDataList();
                                }
                            })
                        }else{
                            this.$message.error(data.msg)
                        }
                    });
                }).catch(() => {

                });
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>