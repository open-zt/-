<template>
    <div>
        <el-dialog
            class="dialog-con"
            :title="!this.dataForm.id?'新增':'编辑'"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            :visible.sync="visible">
            <el-button type="primary" @click="viewHandle()" class="close-agent" v-if="this.dataForm.content">预览</el-button>
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="submitFormData()" label-width="80px">
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="标题" prop="title">
                            <el-input v-model="dataForm.title" placeholder="请输入标题"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="9">
                        <el-form-item label="类型" prop="type">
                            <el-select placeholder="请选择类型" v-model="dataForm.type" clearable>
                                <el-option v-for="item in notifyDictList" :value="item.id" :label="item.name" :key="item.id"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="3">
                        <div style="margin-top: 12px;" class="pointer" @click="addUnit()">
                            <i class="el-icon-plus"></i>
                            新建分类
                        </div>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="封面图片">
                            <el-upload
                                    list-type="picture-card"
                                    :action="imgUrl"
                                    :multiple="true"
                                    :limit="1"
                                    :file-list="file"
                                    :before-upload="beforeUploadHandle"
                                    :on-remove="handleRemove"
                                    :on-success="handleSuccess"
                                    :on-preview="preview">
                                <el-button type="text">上传图片</el-button>
                            </el-upload>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" class="con-height">
                        <el-form-item label="正文" prop="content">
                            <vue-ueditor-wrap v-model="dataForm.content" :config="myConfig" ref="ue1"></vue-ueditor-wrap>
                            <div class="editor-container">
                                <div class="up-img">插入图片
                                    <input type="file" value="" accept="image/jpg, image/jpeg,image/png" id="appendImg" @change="appendImg($event)"/>
                                </div>
                            </div>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="15">
                        <el-form-item>
                            <el-checkbox v-model="dataForm.topStatus" :true-label="1" :false-label="0">置顶于手机资讯模块</el-checkbox>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()" :disabled="isDisable">确 定</el-button>
            </span>
            <el-dialog :visible.sync="dialogVisible" append-to-body>
                <img width="100%" :src="dialogImageUrl" alt="">
            </el-dialog>
        </el-dialog>
        <view-handle ref="viewHandle"></view-handle>
        <new-handle ref="newHandle" @refreshDataList="getNotifyDictList"></new-handle>
    </div>
</template>

<script>
    import axios from 'axios'
    import VueUeditorWrap from "vue-ueditor-wrap";
    import apiPage from '@/api'
    import {getBaseUrl,getImgUrl} from "@/util";
    import viewHandle from './view-handle'
    import newHandle from './new-handle'

    export default {
        name: "add-or-update",
        data(){
            return{
                visible:false,
                isDisable:false,
                myConfig: {
                    autoHeightEnabled: false,
                    initialFrameHeight: 400,
                    initialFrameWidth: '100%',
                    UEDITOR_HOME_URL: '/UE/',
                },
                imgUrl:'',
                file:[],
                imgLength:0,
                dataForm:{
                    id:'',
                    title:'',
                    type:'',
                    content:'',
                    topStatus:'0',
                    picture:'',
                },
                dataRule:{
                    title:[{required: true, message: '标题必填', trigger: 'blur'}],
                    type:[{required: true, message: '类型必填', trigger: 'blur'}],
                    content:[{required: true, message: '内容必填', trigger: 'blur'}]
                },
                dialogImageUrl: '',
                dialogVisible: false,
                notifyDictList:[],
            }
        },
        components: {
            VueUeditorWrap,viewHandle,newHandle
        },
        methods:{
            viewHandle(){
                this.$nextTick(() => {
                    this.$refs.viewHandle.init(this.dataForm.title,this.dataForm.content);
                })
            },
            addUnit(){
                this.$nextTick(() => {
                    this.$refs.newHandle.init();
                });
            },
            init(id){
                this.visible = true;
                this.isDisable=false;
                this.dataForm.id = id;
                this.imgUrl = getBaseUrl() + apiPage.api.sysFileUpload;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.file = [];
                });

                this.getNotifyDictList(id);

                if(this.dataForm.id){
                    this.$get(apiPage.api.notifyEdit + this.dataForm.id).then((data) =>{
                        if(data.code == 0){
                            this.dataForm = data.notify;
                            this.file = [{url:data.notify.picture}];
                        }
                    })
                }
            },
            getNotifyDictList(id){
                this.$get(apiPage.api.notifyDictList).then((data) => {
                    if(data.code == 0){
                        this.notifyDictList = data.list;
                        this.dataForm.type = id;
                    }
                });
            },
            appendImg(event){
                var files = event.target.files[0];
                if (!/.(jpg|jpeg|png)$/.test(files.type)) {
                    this.$message.error('上传错误！请检查上传图片类型是否是jpg,jpeg,png!');
                    return;
                }
                let fd =  new FormData();
                fd.set('file',files);
                let config = {headers:{'Content-Type':'multipart/form-data'}};

                axios.post(this.imgUrl,fd,config).then((data)=>{
                    if(data.code == 0){
                        // let test = getImgUrl() + data.fileName;src="'+`${test}`+'"
                        const inHtml = '<p style="line-height: 16px;"><img  width="600px" height="auto" style="vertical-align: middle; margin-right: 2px;" src="'+data.fileUrl+'" /></p>';
                        let u = this.$refs.ue1.editor;
                        u.execCommand("insertHtml",inHtml)
                    }else{
                        this.$message.error('上传图片错误，请重新上传');
                    }
                })
            },
            submitFormData(){
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        this.isDisable = true;
                        this.$post(apiPage.api.notifySave + `${!this.dataForm.id ? 'save' : 'update'}`,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 800,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                });
                                this.isDisable = true;
                            }else {
                                this.isDisable = false;
                                this.$message.error(data.msg);
                            }
                        })
                    }
                })
            },
            beforeUploadHandle(file){
                if (file.type !== 'image/jpg' && file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif') {
                    this.$message.error('只支持jpg、png、gif格式的图片！');
                    return false;
                }
            },
            handleRemove(file,fileList){
                this.file = fileList;
                this.imgLength--;
                if(this.imgLength == 0){
                    let elUpload = document.querySelector('.el-upload');
                    elUpload.style.display = 'block';
                }
            },
            handleSuccess(res){
                if(res.code == 0){
                    this.dataForm.picture = res.fileUrl;
                    this.imgLength++;
                    if(this.imgLength == 1){
                        let elUpload = document.querySelector('.el-upload');
                        elUpload.style.display = 'none';
                    }
                }
            },
            preview(file) {
                this.dialogImageUrl = file.url;
                this.dialogVisible = true;
            },
        },
        created() {
            this.getNotifyDictList();
        }
    }
</script>

<style>
    .up-img{ display: block;position: absolute;width: 60px;height: 35px;line-height: 35px;text-align: left;padding-left: 10px;font-size: 12px;color:#FFF;border-bottom-left-radius: 10px;border-top-left-radius: 10px;right: 1px;bottom:200px;border:1px solid #2d8cf0;z-index: 2001;cursor: pointer;background-color: #2d8cf0;}
    .editor-container input{ width: 70px;height: 35px;position: absolute;left:0;top:0;opacity: 0; }
    .con-height .el-form-item__content{line-height: 22px;}
    .el-upload-list__item {
        transition: none !important;
    }
</style>