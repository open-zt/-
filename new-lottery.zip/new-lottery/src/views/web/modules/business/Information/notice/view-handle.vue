<template>
    <el-dialog
            class="view-width"
            title="资讯预览"
            top="5vh"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            :visible.sync="visible">
            <div class="view-content">
                <div>{{title}}</div>
                <div v-html="content"></div>
            </div>
    </el-dialog>
</template>

<script>
    export default {
        data(){
            return{
                visible:false,
                title:'',
                content:'',
            }
        },
        methods:{
            init(title,content){
                this.visible = true;
                this.title = title;
                this.content = content;
            }
        }
    }
</script>

<style>
    .view-content div{
        font-size: 34px;
        color: rgb(34, 34, 34);
    }
    .view-content p{
        color: #000!important;
        font-size: 16px;
        line-height: 24px;
    }
    .view-content img{
        width:320px!important;
    }
    .view-width .el-dialog{
        width:375px;
        min-width:375px;
        height:667px;
        overflow-y: scroll;
    }
</style>