<template>
    <div>
        <ul class="byty-title">
            <li :class="{ active: isActive}">
                <p>技术部值班人员</p>
                <p>王路非</p>
                <p>王路非</p>
            </li>
            <li>
                <p>业务部值班人员</p>
                <p>王路非</p>
            </li>
        </ul>
        <el-row>
            <el-col :span="20">
                <CalendarCard :tabList="tabList" :ifEdit="false" @refreshData="refreshData"></CalendarCard>
            </el-col>
        </el-row>
    </div>
</template>

<script>
    import CalendarCard from '@/components/calendar-card/index'

    export default {
        data(){
            return {
                isActive: true,
                tabList:[],
            }
        },
        components:{
            CalendarCard,
        },
        methods:{
            refreshData(){
                this.tabList = [] ;
                this.tabList.push({
                    date:'2019-10-12',
                    data:['编辑更新']
                });
            },
            init(){
                this.tabList = [];
                this.tabList.push({
                    date:'2019-10-26',
                    data:['田丽姝','田大妞','小可爱','可可爱爱'],
                });
                this.tabList.push({
                    date:'2019-10-27',
                    data:['可可爱爱'],
                });
                this.tabList.push({
                    date:'2019-10-05',
                    data:['张三'],
                });
            },

        },
        created(){
            this.init();
        }

    }
</script>

<style scoped>
    .byty-title{
        list-style: none;
        display: flex;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
        -webkit-align-content: center;
        align-content: flex-start;
        text-align: center;
        padding-inline-start: 0;
    }
    .byty-title li{
        width:200px;
        height:126px;
        background:#f2f8fe;
        margin-right:10px;
        cursor: pointer;
    }
    .byty-title li.active{
        background:#ccc;
    }
</style>
