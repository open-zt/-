<template>
    <div>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="订单编号">
                <el-input v-model="dataForm.orderNo" placeholder="请输入" clearable></el-input>
            </el-form-item>
            <el-form-item label="评价等级">
                <el-select v-model="dataForm.level" clearable>
                    <el-option value="1" label="差评"></el-option>
                    <el-option value="2" label="中评"></el-option>
                    <el-option value="3" label="好评"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="评价时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    width="200"
                    label="订单编号">
                <template slot-scope="scope">
                    <a href="javascript:;"><p @click="detailsHandle(scope.row.orderId)" style="cursor: pointer">{{scope.row.orderNo}}</p></a>
                </template>
            </el-table-column>
            <el-table-column label="评价" header-align="center">
                <el-table-column
                        prop="level"
                        header-align="center"
                        align="center"
                        label="评价等级">
                    <template slot-scope="scope">
                        <p v-if="scope.row.level == 1">差评</p>
                        <p v-if="scope.row.level == 2">中评</p>
                        <p v-if="scope.row.level == 3">好评</p>
                    </template>
                </el-table-column>
                <el-table-column
                        prop="content"
                        header-align="center"
                        align="center"
                        :show-overflow-tooltip="true"
                        label="评价内容">
                </el-table-column>
                <el-table-column
                        prop="imgUrl"
                        header-align="center"
                        align="center"
                        width="160"
                        label="图片">
                    <template slot-scope="scope">
                        <span v-if="scope.row.imgUrlList == ''">无</span>
                        <div v-else>
                            <el-image
                                    style="width: 100px; height: 100px"
                                    :src="scope.row.imgUrlList[0]"
                                    :preview-src-list="scope.row.imgUrlList">
                            </el-image>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column
                        v-if="isCountry == 1"
                        prop=""
                        header-align="center"
                        align="center"
                        width="160"
                        label="物流评分">
                </el-table-column>
                <el-table-column
                        prop="createTime"
                        header-align="center"
                        align="center"
                        width="160"
                        label="评价时间">
                </el-table-column>
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
        <order-details ref="OrderDetails"></order-details>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import OrderDetails from '../../channel/billing-order/order-details'
    export default {
        data(){
            return{
                dataList:[],
                dataForm:{
                    orderNo:'',
                    level:'',
                    startTime:'',
                    endTime:''
                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        computed:{
            isCountry:{
                get(){return this.$store.state.common.isCountry}
            }
        },
        components:{
            OrderDetails
        },
        methods:{
            detailsHandle(id){
                this.$nextTick(() => {
                    this.$refs.OrderDetails.init(id);
                })
            },
            clear(){
                this.dataForm = {
                    orderNo:'',
                    level:'',
                    startTime:'',
                    endTime:'',
                };
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'orderNo':this.dataForm.orderNo,
                    'startTime':this.dataForm.startTime[0],
                    'endTime':this.dataForm.startTime[1],
                    'level':this.dataForm.level,
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.channelCommentList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style>
    .el-tooltip__popper{ max-width:20%;font-size: 14px!important;letter-spacing:2px; }
</style>