<template>
    <div class="form">
        <p class="black">收货信息</p>
        <el-form :model="dataForm"  ref="dataForm" label-width="110px" :label-position="labelPosition">
            <el-row :gutter="20">
                <el-col :span="5">
                    <el-form-item label="联系人：">
                        <span>{{dataForm.managerMan}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="5">
                    <el-form-item label="手机号：">
                        <span>{{dataForm.tel}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="5">
                    <el-form-item label="地区：">
                        <span>{{dataForm.geoAddress}}</span>
                    </el-form-item>
                </el-col>
                <el-col :span="5">
                    <el-form-item label="详细地址：">
                        <span>{{dataForm.address}}</span>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <p class="black">即开票信息</p>
        <el-table
                :data="dataList"
                style="width:100%"
                border>
            <el-table-column
                    type="index"
                    width="50"
                    header-align="center"
                    align="center"
                    label="序号">
            </el-table-column>
            <el-table-column
                    prop="prodName"
                    header-align="center"
                    align="center"
                    label="即开票">
            </el-table-column>
            <el-table-column
                    prop="faceValue"
                    header-align="center"
                    align="center"
                    label="面值">
            </el-table-column>
            <el-table-column
                    prop="price"
                    header-align="center"
                    align="center"
                    label="价格">
                <template slot-scope="scope">
                    <p>{{scope.row.price}} /本</p>
                </template>
            </el-table-column>
            <el-table-column
                    v-if="isCountry == 0"
                    prop="prodInv"
                    header-align="center"
                    align="center"
                    label="中心库存">
            </el-table-column>
            <el-table-column
                    v-if="isCountry == 1"
                    prop="prodInv"
                    header-align="center"
                    align="center"
                    label="国家中心库存">
            </el-table-column>
            <el-table-column
                    prop="num"
                    header-align="center"
                    align="center"
                    label="数量（本）">
                <template slot-scope="scope">
                    <div v-if="scope.row.prodInv == 0">库存不足</div>
                    <el-input-number v-else v-model="scope.row.num" controls-position="right" @change="handleChange(scope.row.num,scope.row.prodId)" :min="1" :max="scope.row.prodInv"></el-input-number>
                </template>
            </el-table-column>
            <el-table-column
                    prop="amount"
                    header-align="center"
                    align="center"
                    label="金额">
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="操作">
                <template slot-scope="scope">
                    <el-button size="small" type="primary" @click="del(scope.row.prodId)">删除</el-button>
                </template>
            </el-table-column>
            <div slot="empty">
                 <p>
                    <el-button size="small" type="primary" @click="add()"><i class="el-icon-plus"></i>添加即开票</el-button>
                 </p>
            </div>
            <div slot="append" style="text-align: center" v-if="this.dataList.length!=0">
                <p class="m10">
                    <el-button size="small" type="primary" @click="add()"><i class="el-icon-plus"></i>添加即开票</el-button>
                </p>
            </div>
        </el-table>

        <div class="amount-content">
            <div>
                <p>合计：</p>
                <p>共 {{this.numLength}} 种 {{num}} 件，¥ {{amount}}</p>
            </div>
            <div>
                <p>返利比例:</p>
                <p>{{dataForm.rebate}}%</p>
            </div>
            <div>
                <p>返利金额:</p>
                <p>￥{{rebateAmount}}</p>
            </div>
            <div v-if="isCountry == 1">
                <p>运费:</p>
                <p>-</p>
            </div>
            <div class="red">
                <p>实付金额:</p>
                <p>￥{{payAmount}}</p>
            </div>
            <div class="sub-car">
                <el-button type="primary" @click="submitOrder()" :disabled="isDisabled">提交订单</el-button>
            </div>
        </div>

        <open-order-handle ref="openOrderHandle" @refreshDataList="getCarList"></open-order-handle>
    </div>
</template>

<script>
    import apiPage from  '@/api'
    import OpenOrderHandle from './openorder-handle'
    export default {
        data(){
            return{
                labelPosition:'left',
                dataList:[],
                isDisabled:true,
                dataForm:{

                },
                numLength:0,//种类
                num:0,  //数量
                amount:0, //总金额
                rebateAmount:0,//返利金额
                payAmount:0,//实付金额
                isAgent:sessionStorage.getItem('isAgent')
            }
        },
        computed:{
            isCountry:{
                get(){return this.$store.state.common.isCountry}
            }
        },
        components:{
            OpenOrderHandle
        },
        methods:{
            // 购物车添加数量
            handleChange(value,prodId){
                let carProd = prodId +'#'+ value;
                let request = {
                    'buyer':carProd
                };
                this.$post(apiPage.api.channelBuyerCar,request).then((data) => {
                    if(data.status == 200){
                        this.getCarList();
                        this.getProdList();
                    }
                });
            },
            //总价总数量方法
            getProdList(){
                var price = 0;
                var numb = 0;
                var getNum = [];
                for(var i = 0;i < this.dataList.length;i++){
                    if(this.dataList[i].prodInv !=0){
                        getNum.push(this.dataList[i]);
                        numb += this.dataList[i].num;
                        price += Number(this.dataList[i].num * this.dataList[i].price);
                    }
                }
                this.numLength = getNum.length;
                this.amount = price.toFixed(2);
                this.num = numb;
                this.rebateAmount = Number(price*this.dataForm.rebate/100).toFixed(2);
                this.payAmount = Number(this.amount - this.rebateAmount).toFixed(2);

            },
            add(){
                this.$nextTick(() => {
                    this.$refs.openOrderHandle.init(this.dataList);
                })
            },
            // 提交订单
            submitOrder(){
                let carProd = '';
                let buyer = '';
                this.dataList.map((item) => {
                    if(item.prodInv != 0){
                        carProd += item.id + '@' + item.prodId + '@' + item.num +'@'+ item.price +'@'+item.amount +'#';
                        buyer = carProd.substr(0,carProd.length-1);
                        return buyer;
                    }
                });
                let request = {
                    'num':this.num,
                    'amount':this.amount,
                    'orderInfo':this.num +'$'+ this.amount + '$' + buyer
                };
                this.$post(apiPage.api.submitOrder,request).then((data) => {
                    if(data.status == 200){
                        this.$confirm(`<p>您的订单已支付成功！</p>金额  ¥ ${this.payAmount}`, '提示', {
                            dangerouslyUseHTMLString: true,
                            confirmButtonText: '查看订单',
                            cancelButtonText: '继续购买',
                            closeOnClickModal:false,
                            closeOnPressEscape:false,
                            center: true
                        }).then(() => {
                            this.getCarList();
                        }).catch(() => {
                            this.getCarList();
                        });
                    }else if(data.status == 400){
                        this.$message.error(data.message);
                    }
                })
            },
            getUserInfo(){
                this.$get(apiPage.api.channelOrderInfo +'?isAgent=' + this.isAgent).then((data) => {
                    if(data.status == 200){
                        this.dataForm = data.result;
                    }
                })
            },
            getCarList(){
                this.$get(apiPage.api.channelOrderCarList).then((data) => {
                    if(data.status == 200){
                        if(data.result.materials){
                            this.dataList = data.result.materials[0].prodList;
                            if(this.dataList.length !=0){
                                this.isDisabled = false;
                            }else{
                                this.isDisabled = true;
                            }
                        }else{
                            this.dataList = [];
                        }
                        this.getProdList();
                    }
                })
            },
            del(id){
                let carProd = id +'#'+ 0;
                let request = {
                    'buyer':carProd
                };
                this.$post(apiPage.api.channelBuyerCar,request).then((data) => {
                    if(data.status == 200){
                        this.$confirm(`您确定要删除选中的内容吗？`, '提示', {
                            confirmButtonText: '确定',
                            cancelButtonText: '取消',
                            center: true
                        }).then(() => {
                            this.$message({
                                message: '操作成功',
                                type: 'success',
                                duration: 800,
                                onClose: () => {
                                    this.getCarList();
                                }
                            })
                        }).catch(() => {

                        });
                    }else {
                        this.$message.error(data.msg)
                    }
                })
            },
        },
        created() {
            this.getUserInfo();
            this.getCarList();
            setTimeout(() =>{
                this.getProdList();
            },1000)
        }
    }
</script>

<style scoped>
 .amount-content{
     float:right;margin-top:20px;font-size: 16px;text-align: right;
 }
    .amount-content div{
        display: flex;
    }
    .amount-content p:first-child{
        width:100px;
        margin-top:0;
    }
    .amount-content p:last-child{
        width:200px;
        margin-top:0;
    }
    .sub-car{
        margin-bottom: 20px;
        float: right;
    }
    .form .el-form-item{
        margin-bottom:0;
    }
</style>