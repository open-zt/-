<template>
    <div>
<!--        即开票列表-->
        <el-dialog
                class="dialog-con"
                title="添加即开票"
                :close-on-press-escape="false"
                :close-on-click-modal="false"
                width="70%"
                :visible.sync="visible">

            <el-form :inline="true" :model="dataForm">
                <el-form-item label="即开票">
                    <el-input v-model="dataForm.name" placeholder="请输入" clearable></el-input>
                </el-form-item>
                <el-form-item label="面值">
                    <el-select v-model="dataForm.faceValue" placeholder="请选择" clearable>
                        <el-option v-for="item in faceValueList" :key="item.id" :value="item.id"
                                   :label="item.name"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="text" @click="clear()">清空条件</el-button>
                    <el-button type="primary" @click="getDataList()">查询</el-button>
                </el-form-item>
            </el-form>
            <el-table
                    :data="dataList"
                    border
                    :row-key="getRowKey"
                    ref="multipleTable"
                    style="width:100%"
                    @selection-change="handleSelectionChange">
                <el-table-column
                        type="selection"
                        :selectable="checkSelectable"
                        :reserve-selection="true"
                        width="55">
                </el-table-column>
                <el-table-column
                        prop="name"
                        header-align="center"
                        align="center"
                        label="即开票">
                    <template slot-scope="scope">
                        <p>{{scope.row.prodName}}</p>
                        <p>{{scope.row.code}}</p>
                    </template>
                </el-table-column>
                <el-table-column
                        prop="faceValue"
                        header-align="center"
                        align="center"
                        label="面值">
                </el-table-column>
                <el-table-column
                        prop="saleAmount"
                        header-align="center"
                        align="center"
                        label="价格(元/本)">
                </el-table-column>
                <el-table-column
                        v-if="isCountry == 0"
                        prop="prodInv"
                        header-align="center"
                        align="center"
                        label="中心库存">
                </el-table-column>
                <el-table-column
                        v-if="isCountry == 1"
                        prop="prodInv"
                        header-align="center"
                        align="center"
                        label="国家中心库存">
                </el-table-column>
                <el-table-column
                        prop="topAmount"
                        header-align="center"
                        align="center"
                        sortable
                        label="最高奖">
                </el-table-column>
                <el-table-column
                        prop="awardGroup"
                        header-align="center"
                        align="center"
                        sortable
                        label="奖组">
                </el-table-column>
                <el-table-column
                        prop="issueTime"
                        header-align="center"
                        align="center"
                        sortable
                        label="发行日期">
                </el-table-column>
                <el-table-column
                        prop="status"
                        header-align="center"
                        align="center"
                        sortable
                        width="300"
                        label="销量">
                    <template slot="header">
                        <el-cascader
                                style="display:inline-flex"
                                size="mini"
                                :props="optionProps"
                                v-model="dataForm.value"
                                :options="options"
                                @change="handleChange"></el-cascader>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page.sync="pageIndex"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalPage"
                    v-if="this.dataList !=''">
            </el-pagination>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="dataFormSubmit()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import apiPage from '@/api'

    export default {
        data() {
            return {
                visible: false,
                faceValueList: [],
                dataList: [],
                dataForm: {
                    name: '',
                    faceValue: '',
                    value: ['s','A'],
                },
                pageIndex: 1,
                pageSize: 10,
                totalPage: 0,
                dataListSelections: [],
                optionProps: {
                    label: 'name',
                    children: 'list'
                },
                options:[],
                list:[],
            }
        },
        computed:{
            isCountry:{
                get(){return this.$store.state.common.isCountry}
            }
        },
        methods: {
            getRowKey(row){
                return row.prodId
            },
            checkSelectable(row){
                if(row.prodInv != 0){
                    return true
                }else{
                    return false
                }
            },
            //销量查询
            handleChange(value) {
                this.getDataList();
            },
            handleSelectionChange(val) {
                this.dataListSelections = val;
            },
            clear() {
                this.dataForm = {
                    name: '',
                    faceValue: '',
                    value: ['s','A']
                };
                this.getDataList();
            },
            init(list) {
                this.visible = true;
                this.list = list;

                this.getFaceValueList();
                this.getDataList();
                this.getOptions();

                setTimeout(() => {
                    this.setData()
                }, 1000)
            },
            setData(){
                // if(this.list){
                    for(var i=0; i<this.list.length; i++){
                        for (let index = 0; index < this.dataList.length; index++) {
                            if (this.list[i].prodId == this.dataList[index].prodId) {
                                this.$refs.multipleTable.toggleRowSelection(this.dataList[index], true);
                            }else{
                                // this.$refs.multipleTable.clearSelection();
                            }
                        }
                    }
                // }
            },
            dataFormSubmit() {
                let num  = 0;
                let buyer = '';
                let carProd = '';
                carProd = this.dataListSelections.map((item) => {
                    if(item.num == 0){
                        num = 1;
                    }else{
                        num = item.num;
                    }
                    carProd += item.prodId + '#' + num + '_';
                    buyer = carProd.substr(0,carProd.length-1);
                    return buyer;
                });
                let request = {
                    "buyer": buyer
                };
                this.$post(apiPage.api.channelBuyerCar,request).then((data) => {
                    if(data.status == 200){
                        this.$message({
                            message: '操作成功',
                            type: 'success',
                            duration: 3000,
                            onClose: () => {
                                this.visible = false;
                                this.pageIndex = 1;
                                this.$emit('refreshDataList');
                            }
                        })
                    } else {
                        this.$message.error(data.msg)
                    }
                })
            },
            getDataList() {
                let request = {
                    'prodParam': this.dataForm.name,
                    'faceValue': this.dataForm.faceValue,
                    'salesVolume':this.dataForm.value.join(''),
                    'current': this.pageIndex,
                    'size': this.pageSize
                };
                this.$get(apiPage.api.channelOrderList, request).then((data) => {
                    if (data.status == 200) {
                        this.dataList = data.result.materials.records;
                        this.totalPage = data.result.materials.total;
                    } else {
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                    this.setData();
                })
            },
            getOptions(){
                this.$get(apiPage.api.getQueryParams).then((data) => {
                    if(data.code == 0){
                        this.options = data.list;
                    }
                })
            },
            getFaceValueList() {
                this.$get(apiPage.api.faceValueList).then((data) => {
                    if (data.code == 0) {
                        this.faceValueList = data.list;
                    }
                })
            },
            // 每页数
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val) {
                this.pageIndex = val;
                this.getDataList();
            }
        },
        created() {
        }
    }
</script>

<style scoped>

</style>