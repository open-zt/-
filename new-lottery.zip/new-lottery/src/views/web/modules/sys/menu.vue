<template>
    <div>
        菜单列表
    </div>
</template>

<script>
    export default {
        name: "menu"
    }
</script>

<style scoped>

</style>