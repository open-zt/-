<template>
    <div>
        <el-dialog
            class="dialog-con"
            :title="!this.dataForm.id?'新增':'编辑'"
            :close-on-press-escape="false"
            :close-on-click-modal="false"
            :visible.sync="visible">
            <el-form :model="dataForm" :rules="dataRule" ref="dataForm"  @keyup.enter.native="dataFormSubmit()" label-width="80px">
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="标题" prop="title">
                            <el-input v-model="dataForm.title" placeholder="请输入标题"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="15">
                        <el-form-item label="图片">
                            <el-upload
                                    list-type="picture-card"
                                    :action="imgUrl"
                                    :multiple="true"
                                    :limit="1"
                                    :file-list="file"
                                    :before-upload="beforeUploadHandle"
                                    :on-remove="handleRemove"
                                    :on-success="handleSuccess"
                                    :on-preview="preview">
                                <el-button type="text">上传图片</el-button>
                            </el-upload>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" class="con-height">
                        <el-form-item label="正文" prop="content">
                            <vue-ueditor-wrap v-model="dataForm.content" :config="myConfig" ref="ue1"></vue-ueditor-wrap>
                            <div class="editor-container">
                                <div class="up-img">插入图片
                                    <input type="file" value="" accept="image/jpg, image/jpeg,image/png" id="appendImg" @change="appendImg($event)"/>
                                </div>
                            </div>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
              <el-button @click="visible = false">取 消</el-button>
              <el-button type="primary" @click="submitFormData()">确 定</el-button>
            </span>
            <el-dialog :visible.sync="dialogVisible" append-to-body>
                <img width="100%" :src="dialogImageUrl" alt="">
            </el-dialog>
        </el-dialog>
    </div>
</template>

<script>
    import axios from 'axios'
    import VueUeditorWrap from "vue-ueditor-wrap";
    import apiPage from '@/api'
    import {getBaseUrl,getImgUrl} from "@/util";

    export default {
        name: "add-or-update",
        data(){
            return{
                visible:false,
                myConfig: {
                    autoHeightEnabled: false,
                    initialFrameHeight: 400,
                    initialFrameWidth: '100%',
                    UEDITOR_HOME_URL: '/UE/',
                },
                imgUrl:'',
                file:[],
                dataForm:{
                    id:'',
                    title:'',
                    content:'',
                    picture:'',
                },
                dataRule:{
                    title:[{required: true, message: '标题必填', trigger: 'blur'}],
                    content:[{required: true, message: '内容必填', trigger: 'blur'}]
                },
                dialogImageUrl: '',
                dialogVisible: false,
            }
        },
        components: {
            VueUeditorWrap
        },
        methods:{
            init(id){
                this.visible = true;
                this.dataForm.id = id;
                this.imgUrl = getBaseUrl() + apiPage.api.sysFileUpload;

                this.$nextTick(() => {
                    this.$refs['dataForm'].resetFields();
                    this.file = [];
                });

                if(this.dataForm.id){
                    this.$get(apiPage.api.notifyEdit + this.dataForm.id).then((data) =>{
                        if(data.code == 0){
                            this.dataForm = data.notify;
                            this.file = [{url:getImgUrl() + data.notify.picture}];
                        }
                    })
                }
            },
            appendImg(event){
                var files = event.target.files[0];
                if (!/.(jpg|jpeg|png)$/.test(files.type)) {
                    this.$message.error('上传错误！请检查上传图片类型是否是jpg,jpeg,png!');
                    return;
                }
                let fd =  new FormData();
                fd.set('file',files);
                let config = {headers:{'Content-Type':'multipart/form-data'}};

                axios.post(this.imgUrl,fd,config).then((data)=>{
                    if(data.code == 0){
                        let test = getImgUrl() + data.fileName;
                        const inHtml = '<p style="line-height: 16px;"><img  width="600px" height="auto" style="vertical-align: middle; margin-right: 2px;" src="'+`${test}`+'"/></p>';
                        let u = this.$refs.ue1.editor;
                        u.execCommand("insertHtml",inHtml)
                    }else{
                        this.$message.error('上传图片错误，请重新上传');
                    }
                })
            },
            submitFormData(){
                this.$refs['dataForm'].validate((valid) => {
                    if (valid) {
                        this.$post(apiPage.api.notifySave + `${!this.dataForm.id ? 'save' : 'update'}`,this.dataForm).then((data) => {
                            if(data.code == 0){
                                this.$message({
                                    message: '操作成功',
                                    type: 'success',
                                    duration: 1500,
                                    onClose: () => {
                                        this.visible = false;
                                        this.$emit('refreshDataList')
                                    }
                                })
                            }
                        })
                    }
                })
            },
            beforeUploadHandle(file){
                if (file.type !== 'image/jpg' && file.type !== 'image/jpeg' && file.type !== 'image/png' && file.type !== 'image/gif') {
                    this.$message.error('只支持jpg、png、gif格式的图片！');
                    return false;
                }
            },
            handleRemove(file,fileList){
                this.file = fileList;
            },
            handleSuccess(res){
                if(res.code == 0){
                    this.dataForm.picture = res.fileName;
                }
            },
            preview(file) {
                this.dialogImageUrl = file.url;
                this.dialogVisible = true;
            },
        },
        created() {

        }
    }
</script>

<style>
    .up-img{ display: block;position: absolute;width: 60px;height: 35px;line-height: 35px;text-align: left;padding-left: 10px;font-size: 12px;color:#FFF;border-bottom-left-radius: 10px;border-top-left-radius: 10px;right: 1px;bottom:200px;border:1px solid #2d8cf0;z-index: 2001;cursor: pointer;background-color: #2d8cf0;}
    .editor-container input{ width: 70px;height: 35px;position: absolute;left:0;top:0;opacity: 0; }
    .con-height .el-form-item__content{line-height: 22px;}
</style>