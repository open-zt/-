<template>
    <div id="home">
        <div class="home">
            <div class="home-title">
                <span>首页</span>|
                <el-select v-model="dataForm.city">
                    <el-option value="0" label="北京"></el-option>
                </el-select>
                <el-select v-model="dataForm.today">
                    <el-option value="1" label="今日"></el-option>
                </el-select>
            </div>
            <div class="home-container clearfix" :style="{ marginLeft: marginLeft + '%' }">
                <div class="home-warp">
                    <div class="home-card">
                        <div class="sales">今日销售额</div>
                        <div class="money">¥212,223.0元</div>
                        <div class="about">约21万</div>
                        <ul>
                            <li>
                                <span>同比</span>
                                <b class="red">+2%</b>
                                <i class="red iconfont iconup"></i>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>环比</span>
                                <b class="green">-2%</b>
                                <i class="green iconfont iconup"></i>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>全国排名</span>
                                <b>8</b>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="home-warp">
                    <div class="home-card pad0">
                        <div class="name">玩法销售情况</div>
                        <el-table :data="typeList"
                                  style="width:100%"
                                  height="298"
                                  row-key="id"
                                  :header-cell-style="{
                              'background-color': '#DBE9F5',
                              'color':'rgba(51,51,51,1)  '
                             }"
                                  :row-style="tableRowStyle"
                                  :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}">
                            <el-table-column header-align="center" align="center" label="彩票类型" prop="name" width="150"></el-table-column>
                            <el-table-column prop="month" header-align="center" align="center" label="本月" width="70"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年" width="75"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比" width="80"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比" width="80"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table>
                    </div>
                </div>
                <div class="home-warp">
                    <div class="home-card pad0">
                        <div class="name">
                            <el-breadcrumb separator-class="el-icon-arrow-right">
                                <el-breadcrumb-item><a href="javascript:;" @click="cityClick">{{cityLabel}}</a></el-breadcrumb-item>
                                <el-breadcrumb-item v-if="this.isLabel !='' && this.isLabel !=null"><a href="javascript:;" @click="typeClick" >{{isLabel}}</a></el-breadcrumb-item>
                                <el-breadcrumb-item v-if="this.secondLabel != '' && this.secondLabel != null"><a href="javascript:;" >{{secondLabel}}</a></el-breadcrumb-item>
                            </el-breadcrumb>
                        </div>
                        <el-table :data="cityList"
                                  v-if="cityListVisible"
                                  style="width:100%"
                                  height="298"
                                  row-key="id"
                                  :header-cell-style="{
                              'background-color': '#DBE9F5',
                              'color':'rgba(51,51,51,1)  '
                             }"
                                  :row-style="tableRowStyle"
                                  :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}">
                            <el-table-column header-align="center" align="center" label="地域" prop="name" width="150">
                                <template slot-scope="scope">
                                    <el-popover
                                            placement="right"
                                            trigger="click">
                                        <div>
                                            <p class="pointer" @click="handleClick(scope.row.name,scope.row.id,2)">各类型彩票销售情况</p>
                                            <p class="pointer" @click="handleClick2(scope.row.name,scope.row.id,2)">各种经营方式销售情况</p>
                                        </div>
                                        <div slot="reference" class="pointer">{{scope.row.name}}</div>
                                    </el-popover>
                                </template>
                            </el-table-column>
                            <el-table-column prop="month" header-align="center" align="center" label="本月" width="70"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年" width="75"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比" width="80"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比" width="80"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table>
                        <el-table :data="getCityTypeList"
                                  v-if="getCityTypeListVisible"
                                  style="width:100%"
                                  height="298"
                                  row-key="id"
                                  :header-cell-style="{
                              'background-color': '#DBE9F5',
                              'color':'rgba(51,51,51,1)  '
                             }"
                                  :row-style="tableRowStyle"
                                  :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}">
                            <el-table-column header-align="center" align="center" :label="isLabel" prop="name" width="180">
                                <template slot-scope="scope">
                                    <el-popover
                                            placement="right"
                                            trigger="click">
                                        <div>
                                            <p class="pointer" @click="secondClick(scope.row.name,scope.row.id,1)">各种经营方式销售情况</p>
                                        </div>
                                        <div slot="reference" class="pointer">{{scope.row.name}}</div>
                                    </el-popover>
                                </template>
                            </el-table-column>
                            <el-table-column prop="month" header-align="center" align="center" label="本月" width="60"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年" width="60"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比" width="80"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比" width="80"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table>
                        <el-table :data="getCityChanList"
                                  v-if="getCityChanListVisible"
                                  style="width:100%"
                                  height="298"
                                  row-key="id"
                                  :header-cell-style="{
                              'background-color': '#DBE9F5',
                              'color':'rgba(51,51,51,1)  '
                             }"
                                  :row-style="tableRowStyle"
                                  :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}">
                            <el-table-column header-align="center" align="center" :label="isLabel" prop="name" width="180">
                                <template slot-scope="scope">
                                    <el-popover
                                            placement="right"
                                            trigger="click">
                                        <div>
                                            <p class="pointer" @click="secondClick(scope.row.name,scope.row.id,3)">各类型彩票销售情况</p>
                                        </div>
                                        <div slot="reference" class="pointer">{{scope.row.name}}</div>
                                    </el-popover>
                                </template>
                            </el-table-column>
                            <el-table-column prop="month" header-align="center" align="center" label="本月" width="60"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年" width="60"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比" width="80"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比" width="80"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table>
                        <el-table :data="secondList"
                                  v-if="secondListVisible"
                                  style="width:100%"
                                  height="298"
                                  row-key="id"
                                  :header-cell-style="{
                              'background-color': '#DBE9F5',
                              'color':'rgba(51,51,51,1)  '
                             }"
                                  :row-style="tableRowStyle"
                                  :tree-props="{children: 'testSalesDictDO', hasChildren: 'hasChildren'}">
                            <el-table-column header-align="center" align="center" :label="secondLabel" prop="name" width="180">
                                <template slot-scope="scope">
                                    {{scope.row.name}}
                                </template>
                            </el-table-column>
                            <el-table-column prop="month" header-align="center" align="center" label="本月" width="60"></el-table-column>
                            <el-table-column prop="yesteryearMonth" header-align="center" align="center" label="上年" width="60"></el-table-column>
                            <el-table-column prop="monthProportion" header-align="center" align="center" label="本月占比" width="80"></el-table-column>
                            <el-table-column prop="yesteryearProportion" header-align="center" align="center" label="上年占比" width="80"></el-table-column>
                            <el-table-column prop="ringAmount" header-align="center" align="center" label="环比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringAmount > 0" :style="{color:'red'}">{{scope.row.ringAmount}}</p>
                                    <p v-if="scope.row.ringAmount < 0" :style="{color:'green'}">{{scope.row.ringAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="ringRate" header-align="center" align="center" label="环比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.ringRate > 0" :style="{color:'red'}">{{scope.row.ringRateView}}</p>
                                    <p v-if="scope.row.ringRate < 0" :style="{color:'green'}">{{scope.row.ringRateView}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameAmount" header-align="center" align="center" label="同比增长额" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameAmount > 0" :style="{color:'red'}">{{scope.row.sameAmount}}</p>
                                    <p v-if="scope.row.sameAmount < 0" :style="{color:'green'}">{{scope.row.sameAmount}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="sameRate" header-align="center" align="center" label="同比增长率" width="90">
                                <template slot-scope="scope">
                                    <p v-if="scope.row.sameRate > 0" :style="{color:'red'}">{{scope.row.sameRateView}}</p>
                                    <p v-if="scope.row.sameRate < 0" :style="{color:'green'}">{{scope.row.sameRateView}}</p>
                                </template>
                            </el-table-column>
                        </el-table>
                    </div>
                </div>
                <div class="home-warp">
                    <div class="home-card w90">
                        <div class="sales">今日销售额</div>
                        <div class="money">¥35,458,387.0元</div>
                        <div class="about">约3500万</div>
                        <ul>
                            <li>
                                <span>上年</span>
                                <b>1.66亿</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>今日占比</span>
                                <b>7%</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>上年占比</span>
                                <b>1%</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>环比增长额</span>
                                <b class="red">+2213</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>环比增长率</span>
                                <b class="red">+4%</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>同比增长额</span>
                                <b class="green">-1342</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>同比增长率</span>
                                <b class="green">-1%</b>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="home-warp">
                    <div class="home-card w90">
                        <div class="sales">今日销售额</div>
                        <div class="money">¥22,258,915.0元</div>
                        <div class="about">约2200万</div>
                        <ul>
                            <li>
                                <span>上年</span>
                                <b>1.66亿</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>今日占比</span>
                                <b>7%</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>上年占比</span>
                                <b>1%</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>环比增长额</span>
                                <b class="red">+2213</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>环比增长率</span>
                                <b class="red">+4%</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>同比增长额</span>
                                <b class="green">-1342</b>
                            </li>
                            <li>
                                <em class="line"></em>
                            </li>
                            <li>
                                <span>同比增长率</span>
                                <b class="green">-1%</b>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="item">
            <ul>
                <li v-for="(item,index) in items" :key="item.name" :class="{active:index===current}" @click="tab(index)">
                    <span class="iconfont" :class="item.icon"></span>
                    {{item.name}}
                    <em class="active-line"></em>
                </li>
            </ul>
        </div>
        <div class="arrow">
            <span class="left iconfont iconright" @click="prev"></span>
            <span class="right iconfont iconright" @click="next"></span>
        </div>
    </div>

</template>

<script>
    import apiPage from '@/api'
    import axios from 'axios'
    import {getBaseUrl} from "../../../../util";

    export default {
        data(){
            return{
                cityListVisible:true,
                cityList:[],
                typeList:[],
                cityLabel:'地域销售情况',
                typeNum:0,
                isLabel:'',
                dataForm:{
                    city:'0',
                    today:'1'
                },
                current:0,
                marginLeft:0,
                items:[
                    {
                        name:'彩票销售情况',
                        icon:'iconYUAN'
                    },
                    {
                        name:'玩法销售情况',
                        icon:'iconwanfaxiaoshou'
                    },
                    {
                        name:'地区排名情况',
                        icon:'icondiqupaiming'
                    },
                    {
                        name:'投注站销售情况',
                        icon:'iconshop1'
                    },
                    {
                        name:'渠道销售情况',
                        icon:'iconcluster'
                    }
                ],
                getCityTypeList:[],
                getCityTypeListVisible:false,
                getCityChanList:[],
                getCityChanListVisible:false,
                option:'',
                optionType:'',
                secondList:[],
                secondListVisible:false,
                secondLabel:'',
            }
        },
        mounted() {
            let parent = document.getElementById('home').parentNode;
            parent.style.padding = 0;
            let num=0;
            let fontSize = document.querySelectorAll('.money');
            fontSize.forEach((item) => {
                if(item.innerHTML.length >= 16){
                    num = item.innerHTML.length -16;
                }
                item.style.fontSize = 70 - num*5+'px';
            })
        },
        methods:{
            tableRowStyle({ row, rowIndex }) {
                return 'background:linear-gradient(270deg,rgba(239,246,253,1) 0%,rgba(242,248,252,1) 100%)'
            },
            tab(index){
                this.current = index;
                this.marginLeft = -100*index;
            },
            prev(){
                this.current --;
                if(this.current == -1){
                    this.current = this.items.length -1;
                }
                this.tab(this.current);
            },
            next(){
                this.current ++;
                if(this.current == this.items.length){
                    this.current = 0;
                }
                this.tab(this.current);
            },
            cityClick(){
                this.getCityTypeListVisible = false;  //彩票类型表格隐藏
                this.getCityChanListVisible = false;  //经营方式表格隐藏
                this.secondListVisible = false;       //三级表格隐藏
                this.isLabel = '';                    //第二集导航为空
                this.secondLabel = '';                //第三集导航为空
                this.cityListVisible = true;          //默认地域显示
                this.getCityList();
            },
            typeClick(){
                if(this.typeNum===1){
                    this.secondLabel = '';
                    this.secondListVisible = false;
                    this.getCityTypeListVisible = true;
                }else if(this.typeNum===2){
                    this.secondLabel = '';
                    this.secondListVisible = false;
                    this.getCityChanListVisible = true;
                }
            },
            secondClick(name,id,type){
                if(this.typeNum === 1){
                    axios.get(getBaseUrl()+apiPage.api.listChannel, {
                        params: {option:this.option,optionType: this.optionType,option2: id, optionType2: type,},
                    }).then((data) => {
                        this.getCityTypeListVisible = false;
                        this.secondListVisible = true;
                        this.secondList = data.data;
                        this.secondLabel = name + '经营方式销售情况';
                    })
                }else if(this.typeNum === 2){
                    axios.get(getBaseUrl()+apiPage.api.listType, {
                        params: {option: this.option, optionType: this.optionType,option2: id, optionType2: type,},
                    }).then((data) => {
                        this.getCityChanListVisible = false;
                        this.secondListVisible = true;
                        this.secondList = data.data;
                        this.secondLabel = name + '彩票类型销售情况';
                    })
                }
            },
            handleClick(name,id,type){
                axios.get(getBaseUrl()+apiPage.api.listType, {
                    params: {option: id, optionType: type,},
                }).then((data) => {
                    this.cityListVisible = false;
                    this.getCityTypeListVisible = true;
                    this.getCityTypeList = data.data;
                    this.isLabel = name + '彩票类型销售情况';
                    this.option = data.option;
                    this.optionType = data.optionType;
                    this.typeNum=1;
                })
            },
            handleClick2(name,id,type){
                axios.get(getBaseUrl()+apiPage.api.listChannel, {
                    params: {option: id, optionType: type,},
                }).then((data) => {
                    this.cityListVisible = false;
                    this.getCityChanListVisible = true;
                    this.getCityChanList = data.data;
                    this.isLabel = name + '经营方式销售情况';
                    this.option = data.option;
                    this.optionType = data.optionType;
                    this.typeNum=2;
                })
            },
            getCityList(){
                this.$get(apiPage.api.listCity).then((data) => {
                    if(data.code == 0){
                        this.cityList = data.data;
                    }
                })
            },
            getTypeList(){
                this.$get(apiPage.api.listType).then((data) => {
                    if(data.code == 0){
                        this.typeList = data.data;
                    }
                })
            },
        },
        created() {
            this.getCityList();
            this.getTypeList();
        }
    }
</script>
<style>
    .home .el-select{
        margin-left:20px;
    }
    .home .el-select .el-input .el-input__inner{
        width:82px!important;
        border-radius:18px;
        background-color:#EFF6FD;
    }
    .home .el-table{
        background-color: #eff6fd;
    }
    .home .el-table--enable-row-hover .el-table__body tr:hover>td{
        background-color: #fff;
    }
    .home div::-webkit-scrollbar {/*滚动条整体样式*/
        width: 5px;     /*高宽分别对应横竖滚动条的尺寸*/
        height: 1px;
    }
    div::-webkit-scrollbar-thumb {/*滚动条里面小方块*/
        border-radius: 10px;
        -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
        background: #B0B8D1;
    }
    div::-webkit-scrollbar-track {/*滚动条里面轨道*/
        border-radius: 10px;
        background:linear-gradient(270deg,rgba(239,246,253,1) 0%,rgba(242,248,252,1) 100%);
    }
</style>

<style scoped>
    ul li{
        list-style: none;
    }
    .pad0{
        padding:0!important;
    }
    .item ul{
        display: flex;
        justify-content: center;
        margin:0;
    }
    .item ul li {
        text-align: center;
        margin:0 30px;
        font-size:16px;
        font-family:PingFangSC-Medium,PingFang SC;
        font-weight:500;
        color:#B0B8D1;
        line-height:24px;
        position: relative;
        cursor: pointer;
    }
    .item ul li.active{
        color:#333;
    }
    .item ul li.active .active-line{
        width:40px;
        height:4px;
        display: block;
        background:rgba(255,87,88,1);
        margin-top:5px;
        position: absolute;
        left:50%;
        margin-left:-20%;
    }
    .item ul li span{
        display: block;
        font-size: 24px;
        margin-bottom: 10px;
    }
    .home{
        width:100%;
        height:480px;
        background:rgba(239,246,253,1);
        border-radius:0px 0px 20px 20px;
        position:relative;
    }
    .home-title span{
        font-size:24px;
        color:#333;
        padding:20px;
        display:inline-block;
    }
    .home-container{
        width: 500%;
        transition: all .3s cubic-bezier(.4,0,.2,1);
        margin-left: 0;
    }
    .home-warp{
        width: 20%;
        float: left;
    }
    .home-container .home-card{
        text-align: center;
        border:10px solid #CDDEEF;
        max-width:840px;
        height:374px;
        margin:70px auto 100px;
        background:linear-gradient(270deg,rgba(239,246,253,1) 0%,rgba(242,248,252,1) 100%);
        padding:0 100px;
        box-shadow:50px 0px 70px 0px rgba(191,210,228,1),-50px 0px 70px 0px rgba(255,255,255,1),50px 0px 100px 0px rgba(191,210,228,1),-15px 0px 10px 0px rgba(255,255,255,1);
        border-radius:10px;
        overflow-y:auto;
    }
    .name{
        margin:20px 0;
        display: flex;
        justify-content: center;
    }
    .sales{
        font-size:16px;
        font-family:PingFangSC-Medium,PingFang SC;
        font-weight:500;
        color:rgba(51,51,51,1);
        line-height:21px;
        margin:40px 0;
    }
    .money{
        font-size:70px;
        font-family:PingFangSC-Medium,PingFang SC;
        font-weight:500;
        color:rgba(51,51,51,1);
        line-height:100px;
        margin-bottom:18px;
    }
    .home-card ul{
        display: flex;
        justify-content: center;
    }
    .home-card ul li span{
        font-size:14px;
        font-family:PingFangSC-Regular,PingFang SC;
        font-weight:400;
        color:rgba(51,51,51,1);
        line-height:21px;
        display: block;
        width:145px;
        margin-bottom: 5px;
    }
    .home-card.w90 ul li span{
        width:90px;
    }
    .home-card ul li b{
        font-size:14px;
        font-family:DIN-Medium,DIN;
        font-weight:500;
        display: inline-block;
    }
    .home-card ul li i{
        font-size:10px;
        display: inline-block;
        margin-left:4px;
    }
    .home-card ul li:nth-child(3) i{
        transform: rotateX(180deg);
    }
    .red{
        color:#FF5758;
    }
    .green{
        color:#52AF67;
    }
    .line{
        width:1px;
        height:25px;
        background:#E6E6E6;
        display: block;
    }
    .about{
        font-size:18px;
        font-family:PingFangSC-Medium,PingFang SC;
        font-weight:500;
        color:rgba(176,184,209,1);
        margin-bottom:50px;
    }
    .arrow{
        color:#B0B8D1
    }
    .arrow .left{
        position:absolute;
        top:40%;
        left:58px;
        transform: rotateY(180deg);
        font-size: 32px;
        cursor: pointer;
    }
    .arrow .right{
        position:absolute;
        top:40%;
        right:58px;
        font-size: 32px;
        cursor: pointer;
    }

</style>