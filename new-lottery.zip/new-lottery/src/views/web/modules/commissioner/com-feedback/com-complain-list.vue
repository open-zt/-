<template>
    <div>
        <el-form :model="dataForm">
            <el-form-item label="订单类型：">
                <el-radio v-model="dataForm.orderType" label="0" @change="getDataList">即开票订单</el-radio>
                <el-radio v-model="dataForm.orderType" label="1" @change="getDataList">耗材订单</el-radio>
                <el-radio v-model="dataForm.orderType" label="2" @change="getDataList">维修订单</el-radio>
            </el-form-item>
        </el-form>
        <el-form :model="dataForm" :inline="true">
            <el-form-item label="专管员">
                <el-input v-model="dataForm.managerParam" placeholder="请输入账号或名称" clearable></el-input>
            </el-form-item>
            <el-form-item label="投注站">
                <el-input v-model="dataForm.agentParam" placeholder="请输入投注站" clearable></el-input>
            </el-form-item>
            <el-form-item label="投诉时间">
                <el-date-picker
                        v-model="dataForm.startTime"
                        type="daterange"
                        value-format="yyyy-MM-dd"
                        range-separator="至"
                        start-placeholder="开始时间"
                        end-placeholder="结束时间">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="text" @click="clear()">清空条件</el-button>
                <el-button type="primary" @click="getDataList()">查询</el-button>
            </el-form-item>
        </el-form>
        <el-table
                border
                style="width:100%"
                :data="dataList">
            <el-table-column
                    header-align="center"
                    align="center"
                    label="专管员">
                <template slot-scope="scope">
                    <p>{{scope.row.managerName}}</p>
                    <p>{{scope.row.managerUsername}}</p>
                </template>
            </el-table-column>
            <el-table-column
                    header-align="center"
                    align="center"
                    label="投注站">
                <template slot-scope="scope">
                    <p>{{scope.row.agentCode}}</p>
                    <p>{{scope.row.agentName}}</p>
                </template>
            </el-table-column>
            <el-table-column
                    prop="orderNo"
                    header-align="center"
                    align="center"
                    width="180"
                    label="订单编号">
                <template slot-scope="scope">
                    <a href="javascript:;"><p @click="detailsHandle(scope.row.orderId)" style="cursor: pointer">{{scope.row.orderNo}}</p></a>
                </template>
            </el-table-column>
            <el-table-column
                    prop="content"
                    header-align="center"
                    align="center"
                    width="300px"
                    :show-overflow-tooltip="true"
                    label="投诉内容">
            </el-table-column>
            <el-table-column
                    prop="imgUrl"
                    header-align="center"
                    align="center"
                    label="图片">
                <template slot-scope="scope">
                    <span v-if="scope.row.imgUrl == ''">无</span>
                    <div v-else>
                        <el-image
                                style="width: 100px; height: 100px"
                                :src="scope.row.imgUrl[0]"
                                :preview-src-list="scope.row.imgUrl">
                        </el-image>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                    prop="createTime"
                    header-align="center"
                    align="center"
                    width="180"
                    label="投诉时间">
            </el-table-column>
        </el-table>
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="pageIndex"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalPage"
                v-if="this.dataList !=''">
        </el-pagination>
        <details-handle ref="detailsHandle"></details-handle>
    </div>
</template>

<script>
    import apiPage from '@/api'
    import detailsHandle from './com-assess-details'
    export default {
        data(){
            return{
                dataList:[],
                dataForm:{
                    orderType:'',
                    managerParam:'',
                    agentParam:'',
                    startTime:'',
                    endTime:''
                },
                pageIndex:1,
                pageSize:10,
                totalPage:0,
            }
        },
        components:{
            detailsHandle
        },
        methods:{
            detailsHandle(id){
                this.$nextTick(() => {
                    this.$refs.detailsHandle.init(id);
                })
            },
            clear(){
                this.dataForm = {
                    orderType:'',
                    managerParam:'',
                    agentParam:'',
                    startTime:'',
                    endTime:''
                };
                this.getDataList();
            },
            getDataList(){
                let request = {
                    'orderType':this.dataForm.orderType,
                    'managerParam':this.dataForm.managerParam,
                    'agentParam':this.dataForm.agentParam,
                    'startTime':this.dataForm.startTime[0],
                    'endTime':this.dataForm.startTime[1],
                    'current': this.pageIndex,
                    'size': this.pageSize,
                };
                this.$get(apiPage.api.comComplainList,request).then((data) => {
                    if(data.code == 0){
                        this.dataList = data.page.data;
                        this.totalPage = data.page.total;
                    }else{
                        this.dataList = [];
                        this.$message.error(data.msg)
                    }
                })
            },
            // 每页数
            handleSizeChange(val){
                this.pageSize = val;
                this.pageIndex = 1;
                this.getDataList();
            },
            // 当前页
            handleCurrentChange(val){
                this.pageIndex = val;
                this.getDataList();
            },
        },
        created() {
            this.getDataList();
        }
    }
</script>

<style scoped>

</style>