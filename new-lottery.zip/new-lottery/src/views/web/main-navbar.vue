<template>
    <nav class="site-navbar" :class="'site-navbar--' + navbarLayoutType">
        <div class="site-navbar__header">
        </div>
        <div class="site-navbar__body clearfix">
            <el-menu
                    class="site-navbar__menu"
                    mode="horizontal">
                    <h1 class="site-navbar__brand" @click="$router.push({ name: 'home-sale-home-list' })">
                        <a class="site-navbar__brand-lg" href="javascript:;">
                            VldTech-lottery</a>
                        <!--<a class="site-navbar__brand-mini" href="javascript:;">人人</a>-->
                    </h1>
<!--                <el-menu-item class="site-navbar__switch" index="0" @click="sidebarFold = !sidebarFold">-->
<!--                <icon-svg name="zhedie"></icon-svg>-->
<!--                </el-menu-item>-->
            </el-menu>
            <el-menu
                    class="site-navbar__menu site-navbar__menu--right"
                    mode="horizontal">
                <el-menu-item class="site-navbar__avatar" index="3">
                    <el-dropdown :show-timeout="0" placement="bottom">
            <span class="el-dropdown-link">
               <img src="../../assets/images/default-head.jpg" height="250" width="250">{{ userName }}
            </span>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item @click.native="updatePasswordHandle()">修改密码</el-dropdown-item>
                            <el-dropdown-item @click.native="logoutHandle()">退出</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </el-menu-item>
            </el-menu>
        </div>
        <!-- 弹窗, 修改密码 -->
        <update-password v-if="updatePassowrdVisible" ref="updatePassowrd"></update-password>
    </nav>
</template>

<script>
    import {clearLoginInfo} from '@/util'
    import UpdatePassword from './main-navbar-update-password'
    import apiPage from './api'

    export default {
        data() {
            return {
                updatePassowrdVisible: false
            }
        },
        components: {
            UpdatePassword
        },
        computed: {
            navbarLayoutType: {
                get() {
                    return this.$store.state.common.navbarLayoutType
                }
            },
            mainTabs: {
                get() {
                    return this.$store.state.common.mainTabs
                },
                set(val) {
                    this.$store.commit('common/updateMainTabs', val)
                }
            },
            userName: {
                get() {
                    return this.$store.state.user.name
                }
            }
        },
        methods: {
            // 修改密码
            updatePasswordHandle() {
                this.updatePassowrdVisible = true;
                this.$nextTick(() => {
                    this.$refs.updatePassowrd.init()
                })
            },
            // 退出
            logoutHandle() {
                this.$confirm(`确定进行[退出]操作?`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$get(apiPage.api.logout).then((data) => {
                        if (data.code === 0) {
                            if(sessionStorage.getItem('isAgent')){
                                this.$router.push({name: 'ologin'})
                            }else{
                                this.$router.push({name: 'login'})
                            }

                            clearLoginInfo();
                        }
                    });
                }).catch(() => {
                })
            }
        }
    }
</script>


<style scoped>
    .site-navbar__header, .site-navbar__body {
        background-color: #D12D26;
    }
</style>
