<template>
    <div class="control-form">
        <ul class="upload-imgs">
            <li v-for='(item, index) in imgs' :key="index" v-dragging="{ item: item, list: imgs, group: 'item' }">
                <div class="img">
                    <img :src="item">
                    <a class="close" @click="delImg(index)">×</a>
                </div>
            </li>
            <li>
                <input type="file" class="upload" @change="addImg" ref="inputer" multiple accept="image/png, image/jpeg, image/gif"/>
                <a class="add"><i class="iconfont icon-plus"></i><p>点击上传</p></a>
            </li>
        </ul>
        <div class="help-block">(注：支持png、jpg、jpeg格式的图片，图片可以通过拖拽调整顺序)</div>
    </div>
</template>

<script>
    import axios from 'axios'
    export default {
        data() {
            return {
                formData: new FormData(),
                imgs: [],
                imgsId:'',
                imgLength: 0,
            }
        },
        methods: {
            addImg() {
                let inputDOM = this.$refs.inputer;
                var files = inputDOM.files;
                let oldLength = this.imgLength;
                let len = files.length + oldLength;
                if(len>5){
                    this.$message.error('最多可上传5张');
                    return false;
                }
                let fd =  new FormData();
                let config = {headers:{'Content-Type':'multipart/form-data'}};
                for(var i = 0; i< files.length;i++){
                    fd.set('file',files[i]);
                    fd.set('imgId',this.imgId);
                    let size = Math.floor(files[i].size / 1024);
                    if (size > 5 * 1024 * 1024) {
                        alert('请选择5M以内的图片！');
                    }else{
                        this.imgLength++;
                        axios.post(this.imgUrl,fd,config).then((data)=>{
                            if(data.code == 0){
                                this.imgs.push(data.fileUrl);
                                this.imgId = data.imgId;
                            }else{
                                this.$message.error('上传图片错误，请重新上传');
                            }
                        })
                    }
                }
                this.imgsChange()
            },
            getObjectURL(file) {
                var url = null;
                if (window.createObjectURL != undefined) { // basic
                    url = window.createObjectURL(file);
                } else if (window.URL != undefined) { // mozilla(firefox)
                    url = window.URL.createObjectURL(file);
                } else if (window.webkitURL != undefined) { // webkit or chrome
                    url = window.webkitURL.createObjectURL(file);
                }
                return url;
            },
            delImg(index) {
                this.$confirm(`您确认要删除选择的图片吗？`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    center: true
                }).then(() => {
                    this.dataForm.imgUrlList.splice(index, 1);
                    this.imgLength--;
                });
                this.imgsChange()
            },
            imgsChange(){
                this.$emit('imgsChange', this.imgs)
            }
        }
    }
</script>

<style>
    .upload-imgs{margin: 10px 0 20px 0;overflow: hidden;font-size: 0;padding-left:0;}
    .upload-imgs li{position: relative;width: 148px;height: 148px;border-radius:4px;font-size: 14px;display: inline-block;margin-right: 25px;margin-bottom: 10px;border:1px dashed #c0ccda;text-align: center;vertical-align: middle;}
    .upload-imgs .add{display: block;background-color: #fbfdff;color:#D12D26;height: 146px;width:146px;padding-top: 40px;}
    .upload-imgs .add .iconfont{padding: 10px 0;font-size: 40px;}
    .upload-imgs li .upload{position: absolute;top: 0;bottom: 0;left: 0;right: 0;width: 148px;height: 148px;opacity: 0;}
    .upload-imgs .img{position: relative;width:146px;height:146px;cursor: pointer;}
    .upload-imgs .img img{vertical-align: middle;width:100%;height:100%}
    .upload-imgs .img .close{display: block;cursor:pointer;font-size:0;}
    .upload-imgs li:hover .img .close{display: block;position: absolute;right: 1px;top: -3px;line-height: 1;font-size: 24px;color: #aaa;}
</style>
