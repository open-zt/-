/**
 * 邮箱
 * @param {*} s
 */
export function isEmail (s) {
  return /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((.[a-zA-Z0-9_-]{2,3}){1,2})$/.test(s)
}

/**
 * 手机号码
 * @param {*} s
 */
export function isMobile (s) {
  return /^1[0-9]{10}$/.test(s)
}

const mobileRule = (rule,value,callback) => {
  var reg = /^1[0-9]{10}$/;
  if (value === '') {
    callback(new Error('手机号必填'));
  } else if(!reg.test(value)) {
    callback(new Error('手机号不符合规则'));
  }else {
    callback();
  }
}
/**
 * 大于0的数字
 * @param {*} s
 */
export function isNumber (s) {
  return /^([1-9]\d*(\.\d*[1-9])?)|(0\.\d*[1-9])$/.test(s)
}

/**
 * 电话号码
 * @param {*} s
 */
export function isPhone (s) {
  return /^([0-9]{3,4}-)?[0-9]{7,8}$/.test(s)
}

/**
 * URL地址
 * @param {*} s
 */
export function isURL (s) {
  return /^http[s]?:\/\/.*/.test(s)
}

/**
 * 身份证号校验
 * @param {*} s
 */
const idCardRule = (rule,value,callback) =>{
  var reg = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
  if (value === '') {
    callback(new Error('身份证号必填'));
  } else if(!reg.test(value)) {
    callback(new Error('请输入合法的身份证号'));
  }else {
    callback();
  }
}
/**
 * 验证期号
 */
const cycleRule = (rule, value, callback) => {
  var myreg = /^[1-9]\d{6}$/;
  if (value === '') {
    callback(new Error('期号必填'));
  } else if(!myreg.test(value)) {
    callback(new Error('期号为7位数字'));
  }else {
    callback();
  }
};
/**
 * 验证只能输入数字
 */
const number = (rule, value, callback) => {
  var myreg = /^[1-9]\d*$|^$/;
  if (value === '') {
    callback(new Error('不能为空'));
  } else if(!myreg.test(value)) {
    callback(new Error('只能输入大于等于0的整数'));
  }else {
    callback();
  }
};

const numberRule = (rule,value,callback) => {
  var myreg = /^[1-9][0-9]{0,1}$/
 if(!myreg.test(value)) {
    callback(new Error('数值大于0小于100,只能输入整数'));
  }else {
    callback();
  }
}


/**
 * 验证只能输入数字可以输入0
 */
const numRule = (rule, value, callback) => {
  var myreg = /^[0-9]*$/;
  if (value === '') {
    callback(new Error('不能为空'));
  } else if(!myreg.test(value)) {
    callback(new Error('只能输入数字'));
  }else {
    callback();
  }
};
export{number,cycleRule,idCardRule,mobileRule,numberRule,numRule}