import axios from 'axios';
import {getToken, clearLoginInfo,getBaseUrl} from '../util/index'
import {Loading } from 'element-ui';
import router from '../views/web/router'
let loading
function startLoading() { //使用Element loading-start 方法
    loading = Loading.service({
        lock: true,
        text: '加载中……',
        background: 'rgba(0, 0, 0, 0.7)'
    })
}
function endLoading() { //使用Element loading-close 方法
    loading.close()
}
//那么 showFullScreenLoading() tryHideFullScreenLoading() 要干的事儿就是将同一时刻的请求合并。
//声明一个变量 needLoadingRequestCount，每次调用showFullScreenLoading方法 needLoadingRequestCount + 1。
//调用tryHideFullScreenLoading()方法，needLoadingRequestCount - 1。needLoadingRequestCount为 0 时，结束 loading。
let needLoadingRequestCount = 0;
export function showFullScreenLoading() {
    if (needLoadingRequestCount === 0) {
        startLoading()
    }
    needLoadingRequestCount++
}

export function tryHideFullScreenLoading() {
    if (needLoadingRequestCount <= 0) return
    needLoadingRequestCount--;
    if (needLoadingRequestCount === 0) {
        endLoading()
    }
}

/*
* axios封装
* */
const instance = axios.create({});
instance.defaults.headers = {'Content-Type' : 'application/json;charset=UTF-8'};
instance.defaults.timeout = 5000;

// 添加请求拦截器
axios.interceptors.request.use(
    config => {

        if (getToken()) {  // 判断是否存在token，如果存在的话，则每个http header都加上token
            config.headers.Authorization = getToken();
        }
        showFullScreenLoading()
        return config;
    },
    err => {
        return Promise.reject(err);
    });

// http response 添加响应拦截器
axios.interceptors.response.use(response => {
    if (response.data && response.data.code === 401) { // 401, token失效
        this.$message({
            message: '登录过期，请重新登录',
            type: 'success',
            duration: 1500,
            onClose: () => {
                clearLoginInfo();
                router.push({ name: 'login' })
            }
        })
    }
    tryHideFullScreenLoading();
    return response.data
}, error => {
    return Promise.reject(error)
});

/**
 * 封装get方法
 * @param url
 * @param data
 * @returns {Promise}
 */

export function GetData(url, params) {
    let timestamp = new Date().getTime();
    if(typeof params == 'object'){
        params['timestamp'] = timestamp;
    }else{
        params = {
            'timestamp':timestamp
        }
    }
    return new Promise((resolve, reject) => {
        var options = {
            method: 'get',
            url:getBaseUrl() + url,
            params: params,
        };
        axios(options).then(response => {
            resolve(response);
        })
        .catch(err => {
            reject(err)
        })
    })
}

/**
 * 封装post请求
 * @param url
 * @param data
 * @returns {Promise}
 */
export function PostData(url, data, query) {
    let timestamp = new Date().getTime();
    if(typeof data == 'object'){
        data['timestamp'] = timestamp;
    }else{
        data = {
            'timestamp':timestamp
        }
    }

    return new Promise((resolve, reject) => {
        let options = {
            method:'post',
            url:getBaseUrl() + url,
            data:data,
            query:query
        };
        axios(options).then(response => {
            resolve(response);
        })
        .catch(err => {
            reject(err)
        })
    })
}

